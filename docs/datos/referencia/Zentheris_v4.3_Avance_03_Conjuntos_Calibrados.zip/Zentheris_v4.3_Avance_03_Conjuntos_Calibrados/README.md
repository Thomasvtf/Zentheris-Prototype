# Zentheris v4.3 · Avance 03: cinco conjuntos calibrados

Contiene los cinco conjuntos de parámetros de `perfiles_simulacion`, calibrados y verificados con una **implementación de referencia** del simulador. No es el módulo de producción. Todos los datos son simulados.

**Estado:**

| Capa | Estado |
|---|---|
| Estructura | aprobado |
| Modelo matemático | aprobado |
| 147 combinaciones | aprobado |
| Calibración | aprobado |
| Validación estadística | aprobado |
| PostgreSQL local | pendiente: script listo, sin ejecutar |
| Módulo real | pendiente |
| Supabase | pendiente |

## Qué abrir primero

1. `parametros_finales/`: los cinco JSON finales y el consolidado. **Esto es lo que se carga en la tabla.**
2. `informes/02_informe_final_calibracion.md`: resultados, límites, tabla final y pendientes.
3. `graficos/`: perfiles horarios, días, meses, zonas, distribución y sensibilidad.
4. `decisiones_adoptadas.md` y `registro_cambios.md`.

## Carpetas

| Carpeta | Contenido |
|---|---|
| `parametros_finales/` | Cinco JSON con exactamente los campos del contrato y `consolidado_perfiles_simulacion.json` |
| `candidatos_descartados/` | Vacía: no hubo candidatos descartados |
| `congelamiento/` | Referencias, objetivos, criterios y semillas congelados antes de calibrar |
| `codigo/zentheris_sim/` | Simulador de referencia: validación, asignación RN-X-04, semillas, simulación, almacén |
| `codigo/calibracion/` | Ventanas horarias, hipótesis, construcción, calibración, validación, sensibilidad y gráficos |
| `codigo/` | Congelamiento, validador por línea de comandos, generador de SQL, prueba PostgreSQL y `ejecutar_todo.py` |
| `pruebas/` | Suite (59 pruebas), mutaciones y datos de prueba mínimos (no son parámetros) |
| `resultados/` | CSV de pruebas, calibración, validación, sensibilidad y trazabilidad |
| `sql/` | DDL de prueba aislado, carga no destructiva y consultas de verificación |
| `informes/` | Escenarios y selección; informe final |
| `insumos/` | v4.3, insumos del Avance 02 y auditoría del Avance 01 (copias sin modificar) |

## Reproducir

Requiere Python 3.12 (probado en 3.12.3); el simulador usa solo la biblioteca estándar y los gráficos usan `matplotlib`. Desde esta carpeta:

```bash
python codigo/ejecutar_todo.py            # todo (unos minutos)
python codigo/ejecutar_todo.py --rapido   # construcción, SQL, validador y suite
python codigo/validar_parametros.py --cinco parametros_finales/consumo_*.json
```

`ejecutar_todo.py` termina con la revisión final:

- reconstruye los JSON y comprueba que salen idénticos byte a byte;
- busca credenciales y datos personales;
- contrasta el informe con los CSV;
- regenera `MANIFEST.sha256`.

## Prueba en PostgreSQL local (pendiente; la ejecuta el equipo)

1. Instalar PostgreSQL 13 o posterior en un equipo de pruebas y crear una base vacía, por ejemplo `zentheris_pruebas`.
2. Ejecutar `pip install "psycopg[binary]==3.2.3"`.
3. Definir la conexión en una variable de entorno, sin escribir contraseñas en archivos:

   ```bash
   export ZENTHERIS_PG_DSN="postgresql://localhost/zentheris_pruebas"
   ```

4. Ejecutar `python codigo/prueba_postgres_local.py`. El script:
   - crea el esquema aislado `zentheris_prueba`;
   - carga los perfiles dos veces para comprobar que la carga no destructiva conserva los `id`;
   - los lee de vuelta y los compara con los JSON;
   - genera el backfill de cada hogar de referencia;
   - guarda las lecturas y comprueba 720 por zona y que los valores son iguales antes y después de guardar;
   - termina con `ROLLBACK`, así que no deja datos.

   El resultado queda en `resultados/prueba_postgres_local.csv`.

Esto **no** es una prueba de Supabase. No se ha escrito en ningún servicio externo.

## Convenciones clave

- Franjas `[desde, hasta)` y lecturas etiquetadas por el inicio de su hora, en America/Bogota.
- Semilla SHA-256 de hogar, fecha, versión, zona y dominio. Versión del modelo: `zentheris-4.3-ref-1`.
- El backfill no incluye eventos iniciados antes de su primera hora y descarta la cola posterior. La generación hora a hora suma esa cola en la hora siguiente.
