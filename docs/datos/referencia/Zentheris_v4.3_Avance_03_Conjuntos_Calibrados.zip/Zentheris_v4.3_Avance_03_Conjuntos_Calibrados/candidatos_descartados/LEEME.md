Sin candidatos descartados: los conjuntos derivados del balance aprobaron la calibración sin ajustes (ver registro_cambios.md).
