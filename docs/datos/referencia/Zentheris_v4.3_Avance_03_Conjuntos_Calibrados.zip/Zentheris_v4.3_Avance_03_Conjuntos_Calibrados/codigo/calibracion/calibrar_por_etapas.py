"""Etapa D: evalúa los conjuntos activando un componente a la vez sobre el grupo de
calibración (50 semillas, 2026-09-01..2026-10-01). No toca el grupo de validación.

Etapas: 1 plano · 2 forma · 3 humor · 4 fin de semana · 5 ruido · 6 eventos (= conjunto final).
En cada etapa se compara con la esperanza analítica de ESA etapa, para atribuir un
defecto a su componente. Uso: python codigo/calibracion/calibrar_por_etapas.py
"""
import copy
import math

from comun import (CONG, RAIZ, VENTANAS, cargar_perfiles, escribir_csv, esperanza_eventos,
                   esperanza_regular, hogar_referencia, resumen, simular)
from zentheris_sim.constantes import PERSONALIDADES

SEMILLAS = 50


def etapa(p, n):
    q = copy.deepcopy(p)
    if n < 2:
        q["curva_horaria"] = {k: [1 / 24] * 24 for k in q["curva_horaria"]}
    if n < 3:
        q["humor_min"] = q["humor_max"] = 1.0
    if n < 4:
        q["factor_fin_semana"] = 1.0
    if n < 5:
        q["ruido_config"] = {"memoria": q["ruido_config"]["memoria"], "intensidad": 0.0}
    if n < 6:
        q["picos_config"] = {}
    return q


NOMBRES = {1: "plano", 2: "forma", 3: "humor", 4: "fin_semana", 5: "ruido", 6: "eventos_final"}


def main():
    perfiles = cargar_perfiles()
    ini, fin = VENTANAS["calibracion"]
    filas, forma = [], []
    for nombre in PERSONALIDADES:
        hogares = [hogar_referencia(nombre, "cal", f"cal-{i:03d}") for i in range(SEMILLAS)]
        zonas = sorted(hogares[0]["zonas"])
        totales_prev = None
        for n in range(1, 7):
            q = etapa(perfiles[nombre], n)
            esp_r = esperanza_regular(q, zonas, ini, fin)
            esp_e = esperanza_eventos(q, zonas, ini, fin)
            esp = math.fsum(esp_r.values()) + math.fsum(esp_e.values())
            tot, reg_por_semilla, perfil_h = [], [], [0.0] * 24
            for h in hogares:
                s = simular(h, q, ini, fin)
                tot.append(math.fsum(f[3] for fz in s.values() for f in fz))
                reg_por_semilla.append([f[1] for fz in s.values() for f in fz])
                for fz in s.values():
                    for k, _, _, L in fz:
                        perfil_h[k % 24] += L
            r = resumen(tot)
            se = r["desv"] / math.sqrt(SEMILLAS)
            fila = {"personalidad": nombre, "etapa": n, "componente": NOMBRES[n],
                    "esperanza_kwh": esp, "media_kwh": r["media"], "error_rel": r["media"] / esp - 1,
                    "error_estandar_mc": se, "z": (r["media"] - esp) / se if se > 0 else 0.0,
                    "desv": r["desv"], "cv": r["cv"], "min": r["min"], "max": r["max"]}
            if n == 5:  # el ruido no debe cambiar el total regular de ninguna semilla
                fila["dif_max_total_vs_etapa4"] = max(abs(a - b) for a, b in zip(tot, totales_prev))
            if n == 6:
                obj = float(CONG["referencias"][nombre]["ventanas"]["calibracion"]["objetivo_kwh_sin_recorte_eventos"])
                fila["objetivo_congelado_kwh"] = obj
                fila["error_rel_vs_objetivo"] = r["media"] / obj - 1
                fila["semillas_en_banda_10pct"] = sum(abs(t / obj - 1) <= 0.10 for t in tot)
            filas.append(fila)
            totales_prev = tot
            if n in (2, 5, 6):
                s_ = math.fsum(perfil_h)
                forma.append({"personalidad": nombre, "etapa": NOMBRES[n],
                              **{f"h{t:02d}": perfil_h[t] / s_ for t in range(24)}})
        print(nombre, [(f["componente"], round(f["error_rel"], 5), round(f["z"], 2))
                       for f in filas if f["personalidad"] == nombre])
    escribir_csv(RAIZ / "resultados" / "calibracion_por_etapas.csv", filas)
    escribir_csv(RAIZ / "resultados" / "calibracion_forma_horaria.csv", forma)


if __name__ == "__main__":
    main()
