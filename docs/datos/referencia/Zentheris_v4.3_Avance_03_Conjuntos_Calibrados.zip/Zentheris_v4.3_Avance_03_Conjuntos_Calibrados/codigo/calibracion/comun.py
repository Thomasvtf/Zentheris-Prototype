"""Utilidades compartidas por calibración, validación, sensibilidad y gráficos."""
import csv
import json
import math
import sys
from datetime import date, timedelta
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ / "codigo"))

from zentheris_sim.almacen import crear_hogar  # noqa: E402
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES  # noqa: E402
from zentheris_sim.simulador import simular_zona  # noqa: E402
from zentheris_sim.validacion import leer_archivo, probabilidades_efectivas, validar_o_fallar  # noqa: E402

PARAM = RAIZ / "parametros_finales"
CONG = json.loads((RAIZ / "congelamiento" / "congelamiento.json").read_text(encoding="utf-8"))
VENTANAS = {"calibracion": (date(2026, 9, 1), date(2026, 10, 1)),
            "validacion": (date(2026, 11, 1), date(2026, 12, 1)),
            "anual": (date(2025, 1, 1), date(2026, 1, 1))}


def archivo(nombre):
    return PARAM / f"{nombre.lower().replace(' ', '_')}.json"


def cargar_perfiles(carpeta=PARAM):
    return {n: validar_o_fallar(leer_archivo(Path(carpeta) / archivo(n).name)) for n in PERSONALIDADES}


def hogar_referencia(nombre, grupo, etiqueta):
    r = CONG["referencias"][nombre]
    return crear_hogar(f"{grupo}|{nombre}|{etiqueta}", r["vivienda"], tuple(r["zonas"]))


def simular(hogar, perfil, ini: date, fin: date):
    """Devuelve {zona: [(k, regular, eventos, L), ...]} con frontera al inicio de la ventana
    (mismo modo que un backfill: sin cola izquierda, cola derecha descartada)."""
    a, b = ini.toordinal() * 24, fin.toordinal() * 24
    return {z: simular_zona(hogar["id"], perfil, z, a, b, a) for z in sorted(hogar["zonas"])}


def dias_tipo(ini: date, fin: date):
    nl = nf = 0
    d = ini
    while d < fin:
        nf += d.weekday() >= 5; nl += d.weekday() < 5
        d += timedelta(days=1)
    return nl, nf


def esperanza_eventos(perfil, zonas, ini: date, fin: date):
    """Esperanza analítica de la energía de eventos almacenada en la ventana, incluyendo
    la cola derecha descartada (CE07: mismo modo de muestreo y recorte)."""
    n_dias = (fin - ini).days
    tot = {}
    for z in zonas:
        cfg = perfil["picos_config"].get(z)
        if not cfg:
            continue
        pe = probabilidades_efectivas(cfg)
        P = sum(cfg["potencia_w"]) / 2; f = sum(cfg["fraccion_uso"]) / 2
        D0, D1 = cfg["duracion_min"]; m0, m1 = cfg["minuto_inicio"]
        completo = P * f / 60000 * (D0 + D1) / 2
        e = sum(pe) * completo * (n_dias - 1)
        # último día: el evento puede salir de la ventana
        grid = [D0 + (D1 - D0) * (i + .5) / 400 for i in range(400)] if D1 > D0 else [D0]
        for h in range(24):
            if pe[h] == 0:
                continue
            acc = 0.0
            for m in range(int(m0), int(m1) + 1):
                L = 1440 - (60 * h + m)
                acc += sum(min(D, L) for D in grid) / len(grid)
            e += pe[h] * P * f / 60000 * acc / (m1 - m0 + 1)
        tot[z] = e
    return tot


def esperanza_regular(perfil, zonas, ini, fin):
    nl, nf = dias_tipo(ini, fin)
    hm = (perfil["humor_min"] + perfil["humor_max"]) / 2
    return {z: perfil[COLUMNAS_BASE[z]] * hm * (nl + nf * perfil["factor_fin_semana"]) for z in zonas}


def cuantil(xs, q):
    s = sorted(xs)
    if len(s) == 1:
        return s[0]
    pos = (len(s) - 1) * q
    i = int(math.floor(pos))
    return s[i] + (s[min(i + 1, len(s) - 1)] - s[i]) * (pos - i)


def resumen(xs):
    n = len(xs)
    m = math.fsum(xs) / n
    sd = math.sqrt(math.fsum((x - m) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0
    return {"n": n, "media": m, "mediana": cuantil(xs, .5), "desv": sd, "cv": sd / m if m else float("nan"),
            "p5": cuantil(xs, .05), "p25": cuantil(xs, .25), "p75": cuantil(xs, .75), "p95": cuantil(xs, .95),
            "min": min(xs), "max": max(xs)}


def wilson(k, n, z=1.96):
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(0.0, c - h), min(1.0, c + h)


def escribir_csv(ruta, filas):
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    campos = []
    for f in filas:
        for k in f:
            if k not in campos:
                campos.append(k)
    with open(ruta, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=campos); w.writeheader(); w.writerows(filas)


def fmt(x, d=4):
    return f"{x:.{d}f}" if isinstance(x, float) else x
