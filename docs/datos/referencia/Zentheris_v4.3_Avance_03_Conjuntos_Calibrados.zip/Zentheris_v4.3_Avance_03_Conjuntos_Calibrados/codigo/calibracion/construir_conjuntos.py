"""Construye los cinco conjuntos de parámetros a partir de los balances del Avance 02,
las ventanas horarias narrativas y las hipótesis fijadas (sin mirar semillas).

Uso (desde avance_03): python codigo/calibracion/construir_conjuntos.py [--destino carpeta]
Escribe <destino>/consumo_<x>.json, el consolidado y resultados/trazabilidad_*.csv.
"""
import argparse
import csv
import json
import math
import sys
from fractions import Fraction
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ / "codigo"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from hipotesis import (EVENTOS, EXCLUIR_EQUIPOS, FUENTE_ZONA, HUMOR_SEMIANCHO, REFERENCIA,  # noqa: E402
                       REPARTO_5_2, RUIDO)
from ventanas_spec import V  # noqa: E402
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES, ZONAS  # noqa: E402
from zentheris_sim.validacion import validar_conjunto_de_cinco, validar_perfil  # noqa: E402

A2 = RAIZ / "insumos" / "avance02"


def leer(p):
    with open(p, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def perfil_horario(ventanas):
    """24 fracciones que suman 1 (energía repartida por peso entre ventanas y uniforme dentro)."""
    v = [0.0] * 24
    tot = sum(p for _, _, p in ventanas)
    for d, h, p in ventanas:
        for t in range(d, h):
            v[t] += (p / tot) / (h - d)
    return v


def curva_redondeada(w):
    s = math.fsum(w)
    c = [round(x / s, 10) for x in w]
    i = max(range(24), key=lambda k: c[k])
    c[i] = round(c[i] + (1.0 - math.fsum(c)), 12)
    assert abs(math.fsum(c) - 1.0) <= 1e-12 and min(c) >= 0
    return c


def equipos_zona(eq, escenario_fuente, zona):
    esc = escenario_fuente.rstrip("*")
    excl = EXCLUIR_EQUIPOS.get(escenario_fuente, set())
    return [r for r in eq if r["escenario"] == esc and r["zona"] == zona and r["id"] not in excl]


def reparto(cen, esp, phi_fds):
    """Laboral y fin de semana con fracción phi_fds de usos activos en sábado/domingo; espera constante."""
    act = cen - esp
    return esp + act * 7 * (1 - phi_fds) / 5, esp + act * 7 * phi_fds / 2


def energia_semanal_horaria(filas):
    """Vector de 24 con energía de una semana tipo (5 laborales + 2 fin de semana) y desglose."""
    w = [0.0] * 24
    traza = []
    for r in filas:
        cen, esp = float(r["kwh_dia_central"]), float(r["kwh_dia_espera"])
        lab, fds = float(r["kwh_dia_laboral"]), float(r["kwh_dia_fin_semana"])
        if r["id"] in REPARTO_5_2:
            lab, fds = reparto(cen, esp, REPARTO_5_2[r["id"]])
        spec = V[r["id"]]
        if spec == "C":
            for t in range(24):
                w[t] += (5 * lab + 2 * fds) / 24
            traza.append((r["id"], "continuo", cen, 0.0, 0.0))
            continue
        al, af = max(0.0, lab - esp), max(0.0, fds - esp)
        pl, pf = perfil_horario(spec[0]), perfil_horario(spec[1])
        for t in range(24):
            w[t] += 5 * (al * pl[t] + esp / 24) + 2 * (af * pf[t] + esp / 24)
        traza.append((r["id"], "ventanas", cen, (5 * al + 2 * af) / 7, esp))
    return w, traza


def construir():
    eq = leer(A2 / "balance_por_equipo.csv")
    bz = {(r["escenario"], r["zona"]): r for r in leer(A2 / "balance_por_zona.csv")}
    evs = {r["id"]: r for r in leer(A2 / "eventos_adicionales.csv")}
    cat = json.loads((A2 / "catalogo_equipos.json").read_text(encoding="utf-8"))
    cong = json.loads((RAIZ / "congelamiento" / "congelamiento.json").read_text(encoding="utf-8"))
    perfiles, tz, te, tc = {}, [], [], []
    for nombre in PERSONALIDADES:
        ref = REFERENCIA[nombre]
        fr = cong["referencias"][nombre]
        F = round(float(fr["regular_fin_semana_kwh_dia"]) / float(fr["regular_laboral_kwh_dia"]), 4)
        factor_base = 7 / (5 + 2 * F)
        fuentes = {z: ref for z in fr["zonas"]} | FUENTE_ZONA[nombre]
        p = {"nombre": nombre, "activo": True}
        curvas, w_hogar = {}, [0.0] * 24
        rl = rf = 0.0
        for z in ZONAS:
            fuente = fuentes.get(z)
            if fuente is None:
                p[COLUMNAS_BASE[z]] = 0.0
                tz.append({"personalidad": nombre, "zona": z, "fuente": "", "regular_kwh_dia": 0,
                           "base_kwh_dia": 0, "motivo": "zona que la personalidad nunca recibe (RN-X-04)"})
                continue
            filas = equipos_zona(eq, fuente, z)
            assert filas, (nombre, z, fuente)
            w, traza = energia_semanal_horaria(filas)
            R = math.fsum(float(r["kwh_dia_central"]) for r in filas)
            if fuente == ref:
                assert abs(R - float(bz[(ref, z)]["regular_kwh_dia_central"])) < 1e-9, (nombre, z)
                for r in filas:
                    lab, fds = float(r["kwh_dia_laboral"]), float(r["kwh_dia_fin_semana"])
                    if r["id"] in REPARTO_5_2:
                        lab, fds = reparto(float(r["kwh_dia_central"]), float(r["kwh_dia_espera"]), REPARTO_5_2[r["id"]])
                    rl += lab; rf += fds
                for t in range(24):
                    w_hogar[t] += w[t]
            curvas[z] = curva_redondeada(w)
            B = round(R * factor_base, 4)
            p[COLUMNAS_BASE[z]] = B
            tz.append({"personalidad": nombre, "zona": z, "fuente": fuente, "regular_kwh_dia": f"{R:.6f}",
                       "base_kwh_dia": B, "motivo": "referencia" if fuente == ref else "zona auxiliar de contraste"})
            for eid, tipo, cen, act, esp in traza:
                tc.append({"personalidad": nombre, "zona": z, "equipo_id": eid, "tipo": tipo,
                           "kwh_dia_central": f"{cen:.6f}", "activo_en_ventanas_kwh_dia": f"{act:.6f}",
                           "espera_24h_kwh_dia": f"{esp:.6f}",
                           "ventanas_laboral": "" if V[eid] == "C" else str(V[eid][0]),
                           "ventanas_fin_semana": "" if V[eid] == "C" else str(V[eid][1])})
        assert abs(rl - float(fr["regular_laboral_kwh_dia"])) < 1e-9, (nombre, rl)
        assert abs(rf - float(fr["regular_fin_semana_kwh_dia"])) < 1e-9, (nombre, rf)
        p["curva_horaria"] = {"base": curva_redondeada(w_hogar)} | curvas
        a = HUMOR_SEMIANCHO[nombre]
        p["humor_min"], p["humor_max"] = round(1 - a, 4), round(1 + a, 4)
        phi, sig = RUIDO[nombre]
        p["ruido_config"] = {"memoria": phi, "intensidad": sig}
        p["picos_config"] = {}
        for z, spec in EVENTOS[nombre].items():
            r = evs[spec["id"]]
            c = cat[spec["equipo"]]
            freq = float(r["frecuencia_30dias"].split("|")[1])
            e_net = float(r["kwh_30dias_central"]) / freq
            dmin = [float(x) for x in r["minutos"].split("|")]
            D = [dmin[1] - min(dmin[1] - dmin[0], dmin[2] - dmin[1]), dmin[1] + min(dmin[1] - dmin[0], dmin[2] - dmin[1])]
            fv = [float(x) for x in c["fraccion_uso"]]
            df = min(fv[1] - fv[0], fv[2] - fv[1])
            f = [fv[1] - df, fv[1] + df]
            n = spec.get("cantidad", 1)
            if c["metodo"] == "ciclo":   # potencia media del ciclo = energía/ duración central
                Pc = float(c["valor"][1]) * 60000 / dmin[1]
                P = [Pc, Pc]
            else:
                pv = [float(x) * n for x in c["valor"]]
                dp = min(pv[1] - pv[0], pv[2] - pv[1])
                P = [pv[1] - dp, pv[1] + dp]
            bruta = (sum(P) / 2) * (sum(D) / 2) * (sum(f) / 2) / 60000
            k = e_net / bruta
            assert k <= 1 + 1e-12, (spec["id"], k)
            f = [f[0] * k, f[1] * k]
            d0, d1 = spec["ventana"]
            prob = (freq / 30) / (d1 - d0)
            franjas = ([{"desde": 0, "hasta": d0, "multiplicador": 0.0}] if d0 > 0 else []) + \
                      ([{"desde": d1, "hasta": 24, "multiplicador": 0.0}] if d1 < 24 else [])
            p["picos_config"][z] = {"probabilidad": prob, "franjas": franjas, "potencia_w": P,
                                    "duracion_min": D, "minuto_inicio": [0, 59], "fraccion_uso": f}
            esperada = prob * (d1 - d0) * (sum(P) / 2) * (sum(D) / 2) * (sum(f) / 2) / 60000
            te.append({"personalidad": nombre, "zona": z, "evento_id": spec["id"], "equipo": spec["equipo"],
                       "frecuencia_30dias": freq, "kwh_por_evento_neto": f"{e_net:.6f}",
                       "factor_neto_espera": f"{k:.6f}", "probabilidad_hora": f"{prob:.8f}",
                       "ventana_inicio": f"[{d0},{d1})", "potencia_w": P, "duracion_min": D,
                       "fraccion_uso": [round(x, 6) for x in f],
                       "kwh_30dias_esperado": f"{esperada * 30:.6f}", "kwh_30dias_avance02": r["kwh_30dias_central"]})
        p["factor_fin_semana"] = F
        perfiles[nombre] = p
    return perfiles, tz, te, tc


def escribir_csv(ruta, filas):
    with open(ruta, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(filas[0])); w.writeheader(); w.writerows(filas)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--destino", default=str(RAIZ / "parametros_finales"))
    a = ap.parse_args()
    perfiles, tz, te, tc = construir()
    errores = validar_conjunto_de_cinco(list(perfiles.values()))
    if errores:
        raise SystemExit(f"conjuntos inválidos: {errores}")
    dst = Path(a.destino); dst.mkdir(parents=True, exist_ok=True)
    for n, p in perfiles.items():
        (dst / f"{n.lower().replace(' ', '_')}.json").write_text(
            json.dumps(p, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (dst / "consolidado_perfiles_simulacion.json").write_text(
        json.dumps([perfiles[n] for n in PERSONALIDADES], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    escribir_csv(RAIZ / "resultados" / "trazabilidad_bases.csv", tz)
    escribir_csv(RAIZ / "resultados" / "trazabilidad_eventos.csv", te)
    escribir_csv(RAIZ / "resultados" / "trazabilidad_curvas_equipos.csv", tc)
    for n, p in perfiles.items():
        bases = {z: p[COLUMNAS_BASE[z]] for z in ZONAS}
        print(n, "F=", p["factor_fin_semana"], "humor", p["humor_min"], p["humor_max"], bases)


if __name__ == "__main__":
    main()
