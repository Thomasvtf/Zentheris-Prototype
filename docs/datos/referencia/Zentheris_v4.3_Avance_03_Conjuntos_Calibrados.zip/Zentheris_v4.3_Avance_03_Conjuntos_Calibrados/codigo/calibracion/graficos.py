"""Gráficos de consumo horario, diario, mensual, por zona y distribución mensual.
Todos con datos SIMULADOS. Uso: python codigo/calibracion/graficos.py
"""
import csv
import math
from datetime import date, timedelta

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from comun import CONG, RAIZ, VENTANAS, cargar_perfiles, hogar_referencia, simular  # noqa: E402
from zentheris_sim.constantes import PERSONALIDADES  # noqa: E402

G = RAIZ / "graficos"
R = RAIZ / "resultados"
COL = dict(zip(PERSONALIDADES, ["#4C78A8", "#59A14F", "#F28E2B", "#B07AA1", "#E15759"]))
CORTO = {n: n.replace("Consumo ", "").capitalize() for n in PERSONALIDADES}
NOTA = "Datos simulados (implementación de referencia v4.3), no mediciones."


def leer(n):
    with open(R / n, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def pie(fig):
    fig.text(0.01, 0.005, NOTA, fontsize=8, color="#555")


def horario():
    filas = leer("validacion_perfil_horario.csv")
    fig, ax = plt.subplots(1, 5, figsize=(17, 4), sharex=True)
    for i, n in enumerate(PERSONALIDADES):
        for f in filas:
            if f["personalidad"] == n:
                y = [float(f[f"h{t:02d}_kwh"]) for t in range(24)]
                ax[i].step(range(25), y + [y[-1]], where="post", label="Laboral" if f["tipo_dia"] == "laboral" else "Fin de semana",
                           color=COL[n], ls="-" if f["tipo_dia"] == "laboral" else "--")
        ax[i].set_title(CORTO[n]); ax[i].set_xticks(range(0, 25, 6)); ax[i].set_xlabel("Hora (Bogotá)")
        ax[i].grid(alpha=.3)
    ax[0].set_ylabel("kWh por hora (media del hogar)")
    ax[0].legend(fontsize=8)
    fig.suptitle("Perfil horario medio del hogar de referencia — validación nov-2026, 100 semillas")
    pie(fig); fig.tight_layout(rect=(0, 0.03, 1, 0.95)); fig.savefig(G / "01_perfil_horario.png", dpi=130); plt.close(fig)


def diario(perfiles):
    ini, fin = VENTANAS["validacion"]
    fig, ax = plt.subplots(figsize=(12, 5))
    d = ini
    while d < fin:
        if d.weekday() >= 5:
            ax.axvspan(d, d + timedelta(days=1), color="#ddd", alpha=.6, lw=0)
        d += timedelta(days=1)
    for n in PERSONALIDADES:
        h = hogar_referencia(n, "val", "val-000")
        s = simular(h, perfiles[n], ini, fin)
        dia = {}
        for fz in s.values():
            for k, _, _, L in fz:
                dia[k // 24] = dia.get(k // 24, 0.0) + L
        xs = sorted(dia)
        ax.plot([date.fromordinal(o) for o in xs], [dia[o] for o in xs], marker="o", ms=3, color=COL[n], label=CORTO[n])
    ax.set_ylabel("kWh por día"); ax.grid(alpha=.3); ax.legend(ncol=5, fontsize=9, loc="upper center", bbox_to_anchor=(0.5, -0.32))
    ax.set_title("Consumo diario simulado, semilla val-000 (sombreado: sábado y domingo)")
    fig.autofmt_xdate(); pie(fig); fig.subplots_adjust(bottom=0.32); fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(G / "02_consumo_diario.png", dpi=130)
    plt.close(fig)


def mensual():
    filas = [f for f in leer("validacion_anual.csv") if f["mes"] != "total"]
    meses = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
    fig, ax = plt.subplots(figsize=(12, 5))
    for n in PERSONALIDADES:
        f = [x for x in filas if x["personalidad"] == n]
        ax.plot(range(12), [float(x["kwh"]) for x in f], marker="o", color=COL[n], label=f"{CORTO[n]} simulado")
        ax.plot(range(12), [float(x["esperanza_kwh"]) for x in f], ls=":", color=COL[n])
    ax.set_xticks(range(12)); ax.set_xticklabels(meses); ax.set_ylabel("kWh por mes calendario")
    ax.set_title("Consumo mensual simulado 2025 (una semilla por personalidad; punteado = esperanza analítica)")
    ax.grid(alpha=.3); ax.legend(ncol=5, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.08))
    pie(fig); fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(G / "03_consumo_mensual.png", dpi=130); plt.close(fig)


def zonas():
    filas = leer("validacion_zonas.csv")
    orden = ["cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio"]
    paleta = ["#4C78A8", "#F28E2B", "#59A14F", "#76B7B2", "#EDC948", "#B07AA1", "#FF9DA7", "#9C755F", "#BAB0AC"]
    fig, ax = plt.subplots(figsize=(12, 4.8))
    for i, n in enumerate(PERSONALIDADES):
        izq = 0.0
        for z, c in zip(orden, paleta):
            v = next((float(f["participacion_total_pct"]) for f in filas if f["personalidad"] == n and f["zona"] == z), 0.0)
            if v:
                ax.barh(i, v, left=izq, color=c, label=z if i == 4 or z not in [x for x in orden[:4]] else None)
                if v >= 4:
                    ax.text(izq + v / 2, i, f"{v:.0f}%", ha="center", va="center", fontsize=8, color="white")
                izq += v
    h, l = ax.get_legend_handles_labels()
    uniq = dict(zip(l, h))
    ax.legend([uniq[z] for z in orden if z in uniq], [z for z in orden if z in uniq], ncol=9, fontsize=8,
              loc="upper center", bbox_to_anchor=(0.5, -0.12))
    ax.set_yticks(range(5)); ax.set_yticklabels([f"{CORTO[n]} ({CONG['referencias'][n]['referencia']})" for n in PERSONALIDADES])
    ax.set_xlim(0, 100); ax.set_xlabel("% del consumo total del hogar de referencia (validación)")
    ax.set_title("Participación por zona — hogares de referencia")
    pie(fig); fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(G / "04_participacion_zonas.png", dpi=130); plt.close(fig)


def distribucion():
    filas = leer("validacion_totales_por_semilla.csv")
    res = {f["personalidad"]: float(f["objetivo_kwh"]) for f in leer("validacion_resumen.csv")}
    fig, ax = plt.subplots(figsize=(11, 5))
    datos = [[100 * (float(f["total_kwh"]) / res[n] - 1) for f in filas if f["personalidad"] == n] for n in PERSONALIDADES]
    ax.axhspan(-10, 10, color="#e8f2e8", label="Banda de realizaciones ±10%")
    ax.axhspan(-3, 3, color="#cfe3cf", label="Banda de la media ±3%")
    bp = ax.boxplot(datos, patch_artist=True, widths=.5)
    for b, n in zip(bp["boxes"], PERSONALIDADES):
        b.set_facecolor(COL[n]); b.set_alpha(.7)
    ax.set_xticks(range(1, 6)); ax.set_xticklabels([CORTO[n] for n in PERSONALIDADES])
    ax.set_ylabel("Error del total de 30 días frente al objetivo (%)"); ax.set_ylim(-12, 12)
    ax.set_title("Totales de la ventana de validación (100 semillas por personalidad)")
    ax.legend(fontsize=8, loc="lower right"); ax.grid(alpha=.3, axis="y")
    pie(fig); fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(G / "05_distribucion_validacion.png", dpi=130); plt.close(fig)


def sensib():
    filas = [f for f in leer("sensibilidad.csv") if f.get("cambio_media_pct")]
    variantes = list(dict.fromkeys(f["variante"] for f in filas))
    fig, ax = plt.subplots(figsize=(12, 6))
    w = 0.16
    for i, n in enumerate(PERSONALIDADES):
        v = [float(next(f["cambio_media_pct"] for f in filas if f["personalidad"] == n and f["variante"] == k)) for k in variantes]
        ax.barh([j + (i - 2) * w for j in range(len(variantes))], v, height=w, color=COL[n], label=CORTO[n])
    ax.set_yticks(range(len(variantes))); ax.set_yticklabels(variantes, fontsize=8); ax.invert_yaxis()
    ax.axvline(0, color="#333", lw=.8); ax.set_xlabel("Cambio de la media de 30 días (%)")
    ax.set_title("Sensibilidad de un parámetro a la vez (20 semillas, calibración)")
    ax.legend(fontsize=8); ax.grid(alpha=.3, axis="x")
    pie(fig); fig.tight_layout(rect=(0, 0.03, 1, 1)); fig.savefig(G / "06_sensibilidad.png", dpi=130); plt.close(fig)


if __name__ == "__main__":
    G.mkdir(exist_ok=True)
    p = cargar_perfiles()
    horario(); diario(p); mensual(); zonas(); distribucion(); sensib()
    print("6 gráficos escritos")
