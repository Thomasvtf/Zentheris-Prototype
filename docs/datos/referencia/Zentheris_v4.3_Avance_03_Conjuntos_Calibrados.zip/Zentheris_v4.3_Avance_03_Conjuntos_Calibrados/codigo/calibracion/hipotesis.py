"""Hipótesis de modelado fijadas ANTES de simular (no ajustadas mirando semillas).

Las bases y curvas se derivan de los balances del Avance 02; aquí solo se fijan
(1) de qué escenario sale cada zona, (2) humor, (3) ruido y (4) familias de
evento. Humor y ruido NO tienen evidencia empírica directa: son supuestos.
"""

REFERENCIA = {"Consumo compacto": "C1", "Consumo eficiente": "E1", "Consumo intermedio": "I1",
              "Consumo familiar": "F1", "Consumo amplio": "A1"}

# Zona -> escenario fuente. Zonas de la referencia salen de la referencia; zonas
# aplicables ausentes en ella salen del contraste más cercano. None = base 0 porque
# la personalidad nunca recibe esa zona por RN-X-04 (ni por respaldo).
FUENTE_ZONA = {
    "Consumo compacto": {"oficina": "C2*", "lavanderia": "E2", "terraza": None, "garaje": None,
                         "cuarto_servicio": None},
    "Consumo eficiente": {"oficina": "C2*", "lavanderia": "E2", "terraza": "A1", "garaje": "A1",
                          "cuarto_servicio": "F2"},
    "Consumo intermedio": {"lavanderia": "I2", "terraza": "A1", "garaje": "A1", "cuarto_servicio": None},
    "Consumo familiar": {"terraza": "A1", "garaje": "A1", "cuarto_servicio": "F2"},
    "Consumo amplio": {"oficina": "A2", "cuarto_servicio": "A2"},
}
# "C2*": oficina de C2 sin su router (el router ya está en la sala de la referencia).
EXCLUIR_EQUIPOS = {"C2*": {"C2_oficina_router"}}

# A1 adopta el reparto proporcional 5/2 (decisión D2) para horno y secadora.
# Fracción de usos en fin de semana que se sustituye (mismo método que el Avance 02:
# la luz de lavandería sigue a lavadora, plancha y secadora ponderadas por minutos).
_NUM = 52.5 * 7 * 2 / 7 + 60 * 1 * 1 + 92.5 * 2 * 2 / 7
_DEN = 52.5 * 7 + 60 * 1 + 92.5 * 2
REPARTO_5_2 = {"A1_cocina_horno": 2 / 7, "A1_lavanderia_secadora": 2 / 7, "A1_lavanderia_led": _NUM / _DEN}

# Humor simétrico alrededor de 1 (E[H] = 1): mitad del ancho.
HUMOR_SEMIANCHO = {"Consumo compacto": 0.10, "Consumo eficiente": 0.10, "Consumo intermedio": 0.12,
                   "Consumo familiar": 0.12, "Consumo amplio": 0.15}
# Ruido común (φ, σ); margen σ/(1−φ) < 1. "Ruido bajo" en eficiente según tabla 12.
RUIDO = {"Consumo compacto": (0.6, 0.10), "Consumo eficiente": (0.6, 0.06), "Consumo intermedio": (0.6, 0.10),
         "Consumo familiar": (0.6, 0.12), "Consumo amplio": (0.6, 0.15)}

# Familias de evento (una por zona, un solo aparato). Energía neta por evento =
# kwh_30dias_central / frecuencia central del Avance 02. Ventanas = horas en que
# puede EMPEZAR el evento (multiplicador 0 fuera de ellas).
EVENTOS = {
    "Consumo compacto": {"sala": {"id": "EV_C1_sala_tv_p", "equipo": "tv_p", "ventana": (21, 23)}},
    "Consumo eficiente": {"cocina": {"id": "EV_E1_cocina_micro", "equipo": "micro", "ventana": (19, 21)}},
    "Consumo intermedio": {"cocina": {"id": "EV_I1_cocina_micro", "equipo": "micro", "ventana": (19, 21)},
                           "oficina": {"id": "EV_I1_oficina_portatil", "equipo": "portatil", "ventana": (17, 19)}},
    "Consumo familiar": {"cocina": {"id": "EV_F1_cocina_freidora", "equipo": "freidora", "ventana": (18, 20)}},
    "Consumo amplio": {"cocina": {"id": "EV_A1_cocina_horno", "equipo": "horno", "ventana": (12, 14)},
                       "lavanderia": {"id": "EV_A1_lavanderia_secadora", "equipo": "secadora", "ventana": (10, 16)},
                       "terraza": {"id": "EV_A1_terraza_led_ext", "equipo": "led_ext", "ventana": (22, 23),
                                   "cantidad": 4}},
}
