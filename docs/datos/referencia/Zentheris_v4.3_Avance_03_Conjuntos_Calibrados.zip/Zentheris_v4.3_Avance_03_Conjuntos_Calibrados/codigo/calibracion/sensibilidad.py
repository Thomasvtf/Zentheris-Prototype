"""CE13: sensibilidad de un parámetro a la vez (20 semillas del grupo de calibración,
hogar de referencia). Informa cambios; no se usa para elegir parámetros.

Uso: python codigo/calibracion/sensibilidad.py
"""
import copy
import math

from comun import RAIZ, VENTANAS, cargar_perfiles, escribir_csv, hogar_referencia, resumen, simular
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES
from zentheris_sim.validacion import validar_perfil

N = 20


def variantes(p):
    out = {"conjunto_final": p}
    for k, fac in (("bases_x0.9", 0.9), ("bases_x1.1", 1.1)):
        q = copy.deepcopy(p)
        for c in COLUMNAS_BASE.values():
            q[c] = round(q[c] * fac, 4)
        out[k] = q
    q = copy.deepcopy(p); q["humor_min"] = q["humor_max"] = 1.0; out["humor_sin_variacion"] = q
    q = copy.deepcopy(p); a = (p["humor_max"] - p["humor_min"]); q["humor_min"], q["humor_max"] = round(1 - a, 4), round(1 + a, 4)
    out["humor_doble_ancho"] = q
    for k, fac in (("F_x0.9", 0.9), ("F_x1.1", 1.1)):
        q = copy.deepcopy(p); q["factor_fin_semana"] = round(p["factor_fin_semana"] * fac, 4); out[k] = q
    for k, phi in (("memoria_0.3", 0.3), ("memoria_0.8", 0.8)):
        q = copy.deepcopy(p); q["ruido_config"]["memoria"] = phi; out[k] = q
    for k, fac in (("intensidad_x0.5", 0.5), ("intensidad_x1.5", 1.5)):
        q = copy.deepcopy(p); q["ruido_config"]["intensidad"] = round(p["ruido_config"]["intensidad"] * fac, 4); out[k] = q
    for k, fac in (("probabilidad_x0.5", 0.5), ("probabilidad_x2", 2.0)):
        q = copy.deepcopy(p)
        for c in q["picos_config"].values():
            c["probabilidad"] *= fac
        out[k] = q
    for k, i in (("eventos_P_D_f_minimos", 0), ("eventos_P_D_f_maximos", 1)):
        q = copy.deepcopy(p)
        for c in q["picos_config"].values():
            for r in ("potencia_w", "duracion_min", "fraccion_uso"):
                c[r] = [c[r][i], c[r][i]]
        out[k] = q
    return out


def main():
    perfiles = cargar_perfiles()
    ini, fin = VENTANAS["calibracion"]
    filas = []
    for nombre in PERSONALIDADES:
        hogares = [hogar_referencia(nombre, "cal", f"cal-{i:03d}") for i in range(N)]
        base = None
        for k, q in variantes(perfiles[nombre]).items():
            if validar_perfil(q):
                filas.append({"personalidad": nombre, "variante": k, "estado": "variante inválida",
                              "detalle": str(validar_perfil(q))})
                continue
            tot, hora, lect = [], [0.0] * 24, []
            for h in hogares:
                s = simular(h, q, ini, fin)
                tot.append(math.fsum(f[3] for fz in s.values() for f in fz))
                th = {}
                for fz in s.values():
                    for kk, _, _, L in fz:
                        th[kk] = th.get(kk, 0.0) + L
                for kk, v in th.items():
                    hora[kk % 24] += v
                lect += th.values()
            r = resumen(tot)
            pico = max(hora) / math.fsum(hora)
            p95 = sorted(lect)[int(0.95 * (len(lect) - 1))]
            fila = {"personalidad": nombre, "variante": k, "media_kwh": r["media"], "cv_mensual": r["cv"],
                    "participacion_hora_pico": pico, "p95_lectura_hogar_kwh": p95, "max_lectura_hogar_kwh": max(lect)}
            if base is None:
                base = fila
            else:
                fila["cambio_media_pct"] = 100 * (r["media"] / base["media_kwh"] - 1)
                fila["cambio_cv_pts"] = 100 * (r["cv"] - base["cv_mensual"])
                fila["cambio_p95_pct"] = 100 * (p95 / base["p95_lectura_hogar_kwh"] - 1)
            filas.append(fila)
        print(nombre, "ok")
    escribir_csv(RAIZ / "resultados" / "sensibilidad.csv", filas)


if __name__ == "__main__":
    main()
