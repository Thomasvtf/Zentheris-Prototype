"""Etapa E: validación con el grupo reservado (100 semillas, 2026-11-01..2026-12-01),
365 días (2025) y otras combinaciones válidas. Criterios congelados (CE01–CE16).

Uso: python codigo/calibracion/validar.py
"""
import math
import sys
from datetime import date
from pathlib import Path

from comun import (CONG, RAIZ, VENTANAS, cargar_perfiles, dias_tipo, escribir_csv, esperanza_eventos,
                   esperanza_regular, hogar_referencia, resumen, simular, wilson)
from zentheris_sim.almacen import crear_hogar
from zentheris_sim.constantes import PERSONALIDADES
from zentheris_sim.simulador import regular_dia, simular_zona
from zentheris_sim.validacion import probabilidades_efectivas

sys.path.insert(0, str(Path(__file__).resolve().parent))
from construir_conjuntos import A2, equipos_zona, leer, reparto  # noqa: E402
from hipotesis import REFERENCIA, REPARTO_5_2  # noqa: E402

N_VAL = 100
B4 = ("cocina", "sala", "dormitorio", "bano")
COMBINACIONES = {
    "Consumo compacto": [("apartaestudio", ("cocina", "sala", "dormitorio")),
                         ("apartaestudio", ("cocina", "dormitorio", "bano", "oficina")),
                         ("apartaestudio", ("cocina", "sala", "bano", "lavanderia"))],
    "Consumo eficiente": [("apartaestudio", B4 + ("lavanderia",)), ("apartaestudio", B4 + ("oficina",)),
                          ("casa", B4)],
    "Consumo intermedio": [("casa", B4 + ("lavanderia",)), ("casa_campestre", B4), ("apartamento", B4 + ("garaje",))],
    "Consumo familiar": [("casa", B4 + ("cuarto_servicio",)), ("apartamento", B4 + ("terraza", "garaje")),
                         ("casa_campestre", B4 + ("terraza",))],
    "Consumo amplio": [("casa_campestre", B4 + ("oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio")),
                       ("duplex", B4 + ("oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio")),
                       ("casa", B4 + ("oficina", "terraza", "garaje"))],
}


def razon_narrativa_zona(nombre, zona):
    eq = leer(A2 / "balance_por_equipo.csv")
    lab = fds = 0.0
    for r in equipos_zona(eq, REFERENCIA[nombre], zona):
        l, f = float(r["kwh_dia_laboral"]), float(r["kwh_dia_fin_semana"])
        if r["id"] in REPARTO_5_2:
            l, f = reparto(float(r["kwh_dia_central"]), float(r["kwh_dia_espera"]), REPARTO_5_2[r["id"]])
        lab += l; fds += f
    return fds / lab if lab else float("nan")


def por_dia(filas, campo):
    d = {}
    for f in filas:
        d[f[0] // 24] = d.get(f[0] // 24, 0.0) + f[campo]
    return d


def main():
    perfiles = cargar_perfiles()
    ini, fin = VENTANAS["validacion"]
    resumen_f, zonas_f, ev_f, fds_f, hor_f, crit, dist_f = [], [], [], [], [], [], []
    medias = {}
    for nombre in PERSONALIDADES:
        p = perfiles[nombre]
        ref = CONG["referencias"][nombre]
        obj = float(ref["ventanas"]["validacion"]["objetivo_kwh_sin_recorte_eventos"])
        hogares = [hogar_referencia(nombre, "val", f"val-{i:03d}") for i in range(N_VAL)]
        zonas = sorted(hogares[0]["zonas"])
        tot, ev_tot, n_ev = [], [], 0
        zona_eq_reg = {z: [] for z in zonas}
        zona_tot = {z: 0.0 for z in zonas}
        lab_dias, fds_dias = [], []
        hor = {"laboral": [0.0] * 24, "fin_semana": [0.0] * 24}
        nd = {"laboral": 0, "fin_semana": 0}
        for h in hogares:
            s = {z: simular_zona(h["id"], p, z, ini.toordinal() * 24, fin.toordinal() * 24, ini.toordinal() * 24,
                                 detalle=True) for z in zonas}
            tot.append(math.fsum(f[3] for z in zonas for f in s[z][0]))
            ev_tot.append(math.fsum(f[2] for z in zonas for f in s[z][0]))
            n_ev += sum(1 for z in zonas for e in s[z][2] if e.inicio_min >= ini.toordinal() * 1440)
            reg_dia_hogar = {}
            for z in zonas:
                filas = s[z][0]
                rd = por_dia(filas, 1)
                wd = [v for o, v in rd.items() if date.fromordinal(o).weekday() < 5]
                we = [v for o, v in rd.items() if date.fromordinal(o).weekday() >= 5]
                zona_eq_reg[z].append(30 * (5 / 7 * sum(wd) / len(wd) + 2 / 7 * sum(we) / len(we)))
                zona_tot[z] += math.fsum(f[3] for f in filas)
                for o, v in rd.items():
                    reg_dia_hogar[o] = reg_dia_hogar.get(o, 0.0) + v
                for k, _, _, L in filas:
                    tipo = "fin_semana" if date.fromordinal(k // 24).weekday() >= 5 else "laboral"
                    hor[tipo][k % 24] += L
            for o, v in reg_dia_hogar.items():
                (fds_dias if date.fromordinal(o).weekday() >= 5 else lab_dias).append(v)
        nl, nf = dias_tipo(ini, fin)
        nd["laboral"], nd["fin_semana"] = nl * N_VAL, nf * N_VAL
        r = resumen(tot)
        medias[nombre] = r["media"]
        k = sum(abs(t / obj - 1) <= 0.10 for t in tot)
        wl, wh = wilson(k, N_VAL)
        err = r["media"] / obj - 1
        resumen_f.append({"personalidad": nombre, "referencia": ref["referencia"], "objetivo_kwh": obj, **r,
                          "error_rel_media": err, "banda_10pct": f"[{obj * .9:.4f}, {obj * 1.1:.4f}]",
                          "semillas_en_banda": k, "proporcion": k / N_VAL, "wilson_95_bajo": wl, "wilson_95_alto": wh})
        crit.append({"personalidad": nombre, "criterio": "CE01 media ±3%", "valor": f"{err * 100:+.3f}%",
                     "estado": "aprobado" if abs(err) <= 0.03 else "fallido"})
        crit.append({"personalidad": nombre, "criterio": "CE03 >=95/100 en ±10%", "valor": f"{k}/100 (Wilson {wl:.3f}–{wh:.3f})",
                     "estado": "aprobado" if k >= 95 else "fallido"})
        dist_f += [{"personalidad": nombre, "semilla": f"val-{i:03d}", "total_kwh": t} for i, t in enumerate(tot)]
        # CE02 por zona (regular, 30 días equivalentes)
        peor = "aprobado"
        tot_h = math.fsum(zona_tot.values())
        for z in zonas:
            objz = 30 * sum(float(x) for x in [ref["zonas_balance"][z]["regular_kwh_dia_central"]])
            m = sum(zona_eq_reg[z]) / N_VAL
            tol = max(0.05 * objz, 0.02)
            est = "aprobado" if abs(m - objz) <= tol else "fallido"
            peor = "fallido" if est == "fallido" else peor
            rn = razon_narrativa_zona(nombre, z)
            zonas_f.append({"personalidad": nombre, "zona": z, "objetivo_regular_30d": objz, "media_regular_30d_eq": m,
                            "error_abs": m - objz, "tolerancia": tol, "estado_CE02": est,
                            "participacion_total_pct": 100 * zona_tot[z] / tot_h,
                            "razon_fds_lab_narrativa": rn, "razon_fds_lab_modelo": p["factor_fin_semana"],
                            "residuo_rel_CE16": p["factor_fin_semana"] / rn - 1 if rn == rn else float("nan")})
        crit.append({"personalidad": nombre, "criterio": "CE02 energía regular por zona", "valor": f"{len(zonas)} zonas",
                     "estado": peor})
        # CE06 y CE07 eventos
        mu = var = 0.0
        for z in zonas:
            cfg = p["picos_config"].get(z)
            if cfg:
                pe = probabilidades_efectivas(cfg)
                mu += sum(pe) * (fin - ini).days * N_VAL
                var += sum(x * (1 - x) for x in pe) * (fin - ini).days * N_VAL
        e_esp = math.fsum(esperanza_eventos(p, zonas, ini, fin).values())
        re = resumen(ev_tot)
        se = re["desv"] / math.sqrt(N_VAL)
        tol7 = max(0.05 * e_esp, 4 * se)
        ok6 = abs(n_ev - mu) <= 4 * math.sqrt(var) + 1
        ok7 = abs(re["media"] - e_esp) <= tol7
        ev_f.append({"personalidad": nombre, "eventos_observados": n_ev, "eventos_esperados": mu,
                     "limite_CE06": 4 * math.sqrt(var) + 1, "estado_CE06": "aprobado" if ok6 else "fallido",
                     "energia_eventos_media_kwh": re["media"], "energia_eventos_esperada_kwh": e_esp,
                     "tolerancia_CE07": tol7, "estado_CE07": "aprobado" if ok7 else "fallido",
                     "participacion_eventos_pct": 100 * re["media"] / r["media"]})
        crit.append({"personalidad": nombre, "criterio": "CE06 frecuencia de eventos",
                     "valor": f"{n_ev} vs {mu:.1f}", "estado": "aprobado" if ok6 else "fallido"})
        crit.append({"personalidad": nombre, "criterio": "CE07 energía de eventos",
                     "valor": f"{re['media']:.4f} vs {e_esp:.4f} kWh", "estado": "aprobado" if ok7 else "fallido"})
        # CE15 razón agregada fin de semana / laboral (regular)
        rz = (sum(fds_dias) / len(fds_dias)) / (sum(lab_dias) / len(lab_dias))
        robj = float(ref["razon_fin_semana_laboral_objetivo"])
        ok15 = abs(rz / robj - 1) <= 0.05
        fds_f.append({"personalidad": nombre, "razon_objetivo": robj, "razon_simulada": rz, "error_rel": rz / robj - 1,
                      "estado_CE15": "aprobado" if ok15 else "fallido"})
        crit.append({"personalidad": nombre, "criterio": "CE15 razón fin de semana/laboral",
                     "valor": f"{rz:.4f} vs {robj:.4f}", "estado": "aprobado" if ok15 else "fallido"})
        for tipo in hor:
            pico = max(range(24), key=lambda t: hor[tipo][t])
            hor_f.append({"personalidad": nombre, "tipo_dia": tipo, "hora_pico": pico,
                          **{f"h{t:02d}_kwh": hor[tipo][t] / nd[tipo] for t in range(24)}})
        print(nombre, f"media {r['media']:.3f} obj {obj:.3f} err {err * 100:+.2f}% banda {k}/100 cv {r['cv']:.4f}")
    orden = [medias[n] for n in PERSONALIDADES]
    ok11 = all(a < b for a, b in zip(orden, orden[1:]))
    crit.append({"personalidad": "todas", "criterio": "CE11 orden de medias",
                 "valor": " < ".join(f"{m:.2f}" for m in orden), "estado": "aprobado" if ok11 else "fallido"})
    escribir_csv(RAIZ / "resultados" / "validacion_resumen.csv", resumen_f)
    escribir_csv(RAIZ / "resultados" / "validacion_totales_por_semilla.csv", dist_f)
    escribir_csv(RAIZ / "resultados" / "validacion_zonas.csv", zonas_f)
    escribir_csv(RAIZ / "resultados" / "validacion_eventos.csv", ev_f)
    escribir_csv(RAIZ / "resultados" / "validacion_fin_semana.csv", fds_f)
    escribir_csv(RAIZ / "resultados" / "validacion_perfil_horario.csv", hor_f)
    anual(perfiles, crit)
    combinaciones(perfiles, crit)
    ruido(perfiles, crit)
    escribir_csv(RAIZ / "resultados" / "criterios_validacion.csv", crit)
    fallos = [c for c in crit if c["estado"] == "fallido"]
    print(f"{len(crit)} criterios evaluados; fallidos: {len(fallos)}")
    for c in fallos:
        print("  FALLIDO", c)


def anual(perfiles, crit):
    ini, fin = VENTANAS["anual"]
    filas = []
    for nombre in PERSONALIDADES:
        p = perfiles[nombre]
        h = hogar_referencia(nombre, "anual", "anual-val")
        s = simular(h, p, ini, fin)
        mes = {}
        for fz in s.values():
            for k, _, _, L in fz:
                m = date.fromordinal(k // 24).month
                mes[m] = mes.get(m, 0.0) + L
        total = math.fsum(mes.values())
        obj = float(CONG["referencias"][nombre]["ventanas"]["anual"]["objetivo_kwh_sin_recorte_eventos"])
        esp_mes = {}
        for m in range(1, 13):
            a = date(2025, m, 1); b = date(2025 + (m == 12), m % 12 + 1, 1)
            esp_mes[m] = math.fsum(esperanza_regular(p, h["zonas"], a, b).values()) + \
                math.fsum(esperanza_eventos(p, h["zonas"], a, b).values())
        primera = sum(mes[m] for m in range(1, 7)) / sum(esp_mes[m] for m in range(1, 7))
        segunda = sum(mes[m] for m in range(7, 13)) / sum(esp_mes[m] for m in range(7, 13))
        for m in range(1, 13):
            filas.append({"personalidad": nombre, "mes": m, "kwh": mes[m], "esperanza_kwh": esp_mes[m],
                          "error_rel": mes[m] / esp_mes[m] - 1})
        filas.append({"personalidad": nombre, "mes": "total", "kwh": total, "esperanza_kwh": obj,
                      "error_rel": total / obj - 1, "deriva_semestre2_vs_1": segunda - primera})
        crit.append({"personalidad": nombre, "criterio": "CE14 año completo (diagnóstico ±3%)",
                     "valor": f"{total:.1f} vs {obj:.1f} kWh ({(total / obj - 1) * 100:+.2f}%), deriva {segunda - primera:+.4f}",
                     "estado": "aprobado" if abs(total / obj - 1) <= 0.03 else "fallido"})
    escribir_csv(RAIZ / "resultados" / "validacion_anual.csv", filas)


def combinaciones(perfiles, crit):
    ini, fin = VENTANAS["validacion"]
    filas = []
    for nombre, lista in COMBINACIONES.items():
        for j, (viv, zs) in enumerate(lista):
            tot = []
            for i in range(20):
                h = crear_hogar(f"comb|{nombre}|{j}|{i:03d}", viv, zs)
                assert h["personalidad"] == nombre, (viv, zs, h["personalidad"])
                s = simular(h, perfiles[nombre], ini, fin)
                assert set(s) == set(zs)
                tot.append(math.fsum(f[3] for fz in s.values() for f in fz))
            p = perfiles[nombre]
            esp = math.fsum(esperanza_regular(p, zs, ini, fin).values()) + \
                math.fsum(esperanza_eventos(p, zs, ini, fin).values())
            r = resumen(tot)
            z = (r["media"] - esp) / (r["desv"] / math.sqrt(20))
            filas.append({"personalidad": nombre, "vivienda": viv, "zonas": "|".join(zs), "semillas": 20,
                          "media_kwh": r["media"], "esperanza_kwh": esp, "error_rel": r["media"] / esp - 1, "z": z,
                          "min": r["min"], "max": r["max"]})
        ok = all(abs(f["z"]) <= 4 for f in filas if f["personalidad"] == nombre)
        crit.append({"personalidad": nombre, "criterio": "Otras combinaciones (3 hogares × 20 semillas)",
                     "valor": "media coherente con su esperanza (|z|<=4)", "estado": "aprobado" if ok else "fallido"})
    # respaldo: dúplex de 9 zonas con eficiente
    zs = ("cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio")
    act = {n: True for n in PERSONALIDADES}; act["Consumo amplio"] = False
    h = crear_hogar("comb|respaldo|duplex9", "duplex", zs, act)
    s = simular(h, perfiles[h["personalidad"]], ini, fin)
    ok = set(s) == set(zs) and all(math.fsum(f[3] for f in fz) > 0 for fz in s.values())
    filas.append({"personalidad": "Consumo eficiente (respaldo)", "vivienda": "duplex", "zonas": "|".join(zs),
                  "semillas": 1, "media_kwh": math.fsum(f[3] for fz in s.values() for f in fz)})
    crit.append({"personalidad": "Consumo eficiente", "criterio": "Respaldo RN-X-04 con 9 zonas",
                 "valor": "9 zonas con consumo > 0", "estado": "aprobado" if ok else "fallido"})
    escribir_csv(RAIZ / "resultados" / "validacion_combinaciones.csv", filas)


def ruido(perfiles, crit):
    """CE10: el ruido conserva el total (probado en etapa 5) y su autocorrelación sigue a φ."""
    filas = []
    for nombre in PERSONALIDADES:
        p = perfiles[nombre]
        h = hogar_referencia(nombre, "val", "val-000")
        xs, ys = [], []
        for o in range(date(2026, 11, 1).toordinal(), date(2026, 12, 1).toordinal()):
            for z in h["zonas"]:
                n = regular_dia(h["id"], date.fromordinal(o), z, p)["n"]
                xs += n[4:23]; ys += n[5:24]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        c = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        rho = c / math.sqrt(sum((a - mx) ** 2 for a in xs) * sum((b - my) ** 2 for b in ys))
        phi, sig = p["ruido_config"]["memoria"], p["ruido_config"]["intensidad"]
        filas.append({"personalidad": nombre, "memoria": phi, "intensidad": sig, "margen": sig / (1 - phi),
                      "autocorrelacion_lag1_observada": rho})
        crit.append({"personalidad": nombre, "criterio": "CE10 ruido (autocorrelación ≈ φ, diagnóstico ±0,1)",
                     "valor": f"{rho:.3f} vs φ={phi}", "estado": "aprobado" if abs(rho - phi) <= 0.1 else "fallido"})
    escribir_csv(RAIZ / "resultados" / "validacion_ruido.csv", filas)


if __name__ == "__main__":
    main()
