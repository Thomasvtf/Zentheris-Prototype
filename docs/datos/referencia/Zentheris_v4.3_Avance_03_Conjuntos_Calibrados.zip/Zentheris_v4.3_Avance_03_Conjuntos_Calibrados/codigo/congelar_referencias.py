"""Etapa A: congela referencias, objetivos, criterios, convenciones y grupos de semillas
ANTES de calibrar. Escribe congelamiento/congelamiento.json.

Uso (desde avance_03): python codigo/congelar_referencias.py
"""
import csv
import hashlib
import json
from datetime import date, timedelta
from decimal import Decimal, getcontext
from pathlib import Path

getcontext().prec = 40
RAIZ = Path(__file__).resolve().parents[1]
INS = RAIZ / "insumos"
A2 = INS / "avance02"


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def leer(p):
    with open(p, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def dias(inicio: date, fin: date):
    n_l = n_f = 0
    d = inicio
    while d < fin:
        n_f += d.weekday() >= 5
        n_l += d.weekday() < 5
        d += timedelta(days=1)
    return n_l, n_f


VENTANAS = {"calibracion": (date(2026, 9, 1), date(2026, 10, 1)),
            "validacion": (date(2026, 11, 1), date(2026, 12, 1)),
            "anual": (date(2025, 1, 1), date(2026, 1, 1))}
REPARTO_A1 = "reparto_proporcional_5_2"


def main():
    obj = {r["escenario"]: r for r in leer(A2 / "objetivos_propuestos.csv")}
    comp = {r["escenario"]: r for r in leer(A2 / "comparativa_diez_balances.csv")}
    rep = {(r["escenario"], r["reparto"]): r for r in leer(A2 / "sensibilidad_reparto_semanal.csv")}
    zonas = {}
    for r in leer(A2 / "balance_por_zona.csv"):
        zonas.setdefault(r["escenario"], {})[r["zona"]] = {
            "regular_kwh_dia_central": r["regular_kwh_dia_central"],
            "eventos_kwh_dia_central": r["eventos_kwh_dia_central"],
            "regular_kwh_dia_laboral": r["regular_kwh_dia_laboral"],
            "regular_kwh_dia_fin_semana": r["regular_kwh_dia_fin_semana"]}
    refs, controles = {}, []
    for esc in ("C1", "E1", "I1", "F1", "A1"):
        o, c = obj[esc], comp[esc]
        if esc == "A1":
            r = rep[("A1", REPARTO_A1)]
            Rl, Rf, origen = Decimal(r["regular_laboral_kwh_dia"]), Decimal(r["regular_fin_semana_kwh_dia"]), REPARTO_A1
        else:
            Rl, Rf, origen = Decimal(c["regular_laboral_kwh_dia"]), Decimal(c["regular_fin_semana_kwh_dia"]), "balance_avance02"
        ev_dia = Decimal(o["eventos_30dias"]) / 30
        reg30 = Decimal(o["regular_30dias"])
        chk = (Rl * 5 + Rf * 2) / 7 * 30
        controles.append({"escenario": esc, "regular_30d_desde_Rl_Rf": str(chk), "regular_30d_avance02": str(reg30),
                          "diferencia": str(chk - reg30)})
        objetivo = Decimal(o["objetivo_30dias_equivalente"])
        ventanas = {}
        for nombre, (ini, fin) in VENTANAS.items():
            nl, nf = dias(ini, fin)
            M = nl * Rl + nf * Rf + (nl + nf) * ev_dia
            v = {"inicio": ini.isoformat(), "fin_excluido": fin.isoformat(), "dias_laborales": nl,
                 "dias_fin_semana": nf, "objetivo_kwh_sin_recorte_eventos": str(M)}
            if nombre != "anual":
                v |= {"media_min_3pct": str(M * Decimal("0.97")), "media_max_3pct": str(M * Decimal("1.03")),
                      "realizacion_min_10pct": str(M * Decimal("0.90")),
                      "realizacion_max_10pct": str(M * Decimal("1.10"))}
            clave_a2 = {"calibracion": "calibracion", "validacion": "validacion", "anual": "anual_validacion"}[nombre]
            v["avance02_objetivo_kwh"] = o[f"{clave_a2}_objetivo_kwh_sin_recorte_eventos"]
            v["avance02_dias"] = [int(o[f"{clave_a2}_dias_laborales"]), int(o[f"{clave_a2}_dias_fin_semana"])]
            ventanas[nombre] = v
        refs[o["personalidad"]] = {
            "referencia": esc, "vivienda": o["vivienda"], "zonas": o["zonas"].split("|"),
            "objetivo_30d_equivalente_kwh": o["objetivo_30dias_equivalente"],
            "regular_30d_kwh": o["regular_30dias"], "eventos_30d_kwh": o["eventos_30dias"],
            "media_aceptable_3pct": [o["media_aceptable_baja"], o["media_aceptable_alta"]],
            "banda_realizaciones_10pct": [o["banda_operativa_baja"], o["banda_operativa_alta"]],
            "regular_laboral_kwh_dia": str(Rl), "regular_fin_semana_kwh_dia": str(Rf),
            "razon_fin_semana_laboral_objetivo": str(Rf / Rl), "origen_reparto_semanal": origen,
            "zonas_balance": zonas[esc], "ventanas": ventanas}
    out = {
        "version_congelamiento": "1.0", "fecha": "2026-10-28",
        "estado": "congelado antes de calibrar; no modificar tras ver semillas de validación",
        "fuente_principal": {"archivo": "insumos/Reglas-de-Negocio-y-Modelo-de-Datos-Zentheris-v4_3.md",
                             "sha256": sha(INS / "Reglas-de-Negocio-y-Modelo-de-Datos-Zentheris-v4_3.md")},
        "criterios": {"archivo": "insumos/avance02/03_criterios_aceptacion_propuestos.md",
                      "sha256": sha(A2 / "03_criterios_aceptacion_propuestos.md"),
                      "adopcion": "tal cual (decisión D1)",
                      "media": "error relativo <= 3% frente a objetivo de la ventana (CE01)",
                      "realizaciones": ">= 95 de 100 semillas de validación dentro de ±10% (CE03)",
                      "zona": "media por zona dentro de max(5% del regular de zona, 0,02 kWh) (CE02)",
                      "razon_fin_semana": "error de media <= 5% de la razón objetivo (CE15)"},
        "convenciones_adoptadas": ["A05", "A06", "A07", "A08", "A09", "A10", "A11", "A12", "A13", "A14", "A15"],
        "grupos_semillas": {"calibracion": "cal-000..cal-049 (50), 2026-09-01..2026-10-01",
                            "validacion": "val-000..val-099 (100), 2026-11-01..2026-12-01, ciega",
                            "anual": "anual-val (1), 2025-01-01..2026-01-01",
                            "hogar_id": "uuid5(espacio de pruebas, 'grupo|personalidad|etiqueta')"},
        "referencias": refs, "controles": controles}
    destino = RAIZ / "congelamiento" / "congelamiento.json"
    destino.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for c in controles:
        print(c["escenario"], "dif regular 30d (Rl,Rf vs avance02):", c["diferencia"][:12])
    for p, r in refs.items():
        v = r["ventanas"]
        print(p, r["referencia"], "cal", v["calibracion"]["objetivo_kwh_sin_recorte_eventos"][:9],
              "a2", v["calibracion"]["avance02_objetivo_kwh"][:9], "| val", v["validacion"]["objetivo_kwh_sin_recorte_eventos"][:9],
              "a2", v["validacion"]["avance02_objetivo_kwh"][:9], "| dias", v["calibracion"]["dias_laborales"],
              v["calibracion"]["dias_fin_semana"], v["validacion"]["dias_laborales"], v["validacion"]["dias_fin_semana"],
              v["anual"]["dias_laborales"], v["anual"]["dias_fin_semana"])


if __name__ == "__main__":
    main()
