"""Reejecuta la cadena completa en orden y hace la revisión final (etapa G).

Uso (desde avance_03): python codigo/ejecutar_todo.py [--rapido]
--rapido omite calibración, validación, sensibilidad y gráficos (unos minutos).
"""
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
PASOS = [
    ["codigo/congelar_referencias.py"],
    ["codigo/calibracion/construir_conjuntos.py"],
    ["codigo/generar_sql_carga.py"],
    ["codigo/validar_parametros.py", "--cinco", *[f"parametros_finales/consumo_{n}.json" for n in
                                                  ("compacto", "eficiente", "intermedio", "familiar", "amplio")]],
    ["pruebas/ejecutar_pruebas.py", "final"],
]
AUTOEXCLUIDOS = {"validacion.py", "test_estructura.py", "ejecutar_todo.py"}
LARGOS = [["codigo/calibracion/calibrar_por_etapas.py"], ["codigo/calibracion/validar.py"],
          ["codigo/calibracion/sensibilidad.py"], ["codigo/calibracion/graficos.py"], ["pruebas/mutaciones.py"]]


def correr(args):
    print(">>", " ".join(args), flush=True)
    r = subprocess.run([sys.executable, *args], cwd=RAIZ, capture_output=True, text=True)
    print((r.stdout + r.stderr).strip().splitlines()[-1] if (r.stdout + r.stderr).strip() else "")
    if r.returncode:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise SystemExit(f"falló {args[0]}")


def revision():
    sys.path.insert(0, str(RAIZ / "codigo"))
    from zentheris_sim.validacion import contiene_credencial
    hallazgos = []
    # 1. reconstrucción en carpeta temporal = archivos finales byte a byte
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run([sys.executable, "codigo/calibracion/construir_conjuntos.py", "--destino", tmp],
                       cwd=RAIZ, check=True, capture_output=True)
        for f in (RAIZ / "parametros_finales").glob("*.json"):
            if f.read_bytes() != (Path(tmp) / f.name).read_bytes():
                hallazgos.append(f"{f.name} no se reproduce desde los insumos")
    # 2. credenciales y datos personales (correos, teléfonos colombianos)
    correo = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
    tel = re.compile(r"(?<![\d.])3\d{9}(?!\d)")
    for f in RAIZ.rglob("*"):
        if f.is_file() and f.suffix in {".py", ".json", ".sql", ".md", ".csv", ".txt"} and "insumos" not in f.parts:
            t = f.read_text(encoding="utf-8", errors="ignore")
            if f.name in AUTOEXCLUIDOS:  # contienen los patrones a propósito (detector y su prueba)
                continue
            if contiene_credencial(t) or correo.search(t) or tel.search(t):
                hallazgos.append(f"posible dato sensible en {f.relative_to(RAIZ)}")
    # 3. los resultados citados en el informe salen de los CSV actuales
    inf = (RAIZ / "informes" / "02_informe_final_calibracion.md").read_text(encoding="utf-8")
    import csv
    for r in csv.DictReader(open(RAIZ / "resultados" / "validacion_resumen.csv", encoding="utf-8")):
        cifra = f"{abs(float(r['error_rel_media'])) * 100:.2f}".replace(".", ",") + " %"
        if cifra not in inf:
            hallazgos.append(f"informe no coincide con validacion_resumen.csv para {r['personalidad']} ({cifra})")
    print("Revisión final:", "sin hallazgos" if not hallazgos else hallazgos)
    return hallazgos


def manifiesto():
    lineas = []
    for f in sorted(RAIZ.rglob("*")):
        if f.is_file() and f.name != "MANIFEST.sha256" and "__pycache__" not in f.parts:
            lineas.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(RAIZ).as_posix()}")
    (RAIZ / "MANIFEST.sha256").write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("MANIFEST.sha256:", len(lineas), "archivos")


if __name__ == "__main__":
    for p in PASOS + ([] if "--rapido" in sys.argv else LARGOS):
        correr(p)
    h = revision()
    manifiesto()
    sys.exit(1 if h else 0)
