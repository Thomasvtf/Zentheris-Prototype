"""Genera sql/01_carga_perfiles_simulacion.sql desde parametros_finales/*.json (los mismos
archivos validados). Carga NO destructiva: INSERT ... ON CONFLICT (nombre) DO UPDATE,
sin DELETE, conservando id y created_at existentes.

Uso (desde avance_03): python codigo/generar_sql_carga.py
"""
import hashlib
import json
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "codigo"))
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES, VERSION_MODELO  # noqa: E402
from zentheris_sim.validacion import leer_archivo, validar_conjunto_de_cinco  # noqa: E402

COLS = (["nombre", "activo"] + list(COLUMNAS_BASE.values()) +
        ["curva_horaria", "humor_min", "humor_max", "ruido_config", "picos_config", "factor_fin_semana"])
JSONB = {"curva_horaria", "ruido_config", "picos_config"}


def literal(col, v):
    if col in JSONB:
        t = json.dumps(v, ensure_ascii=False, separators=(",", ":"))
        assert "$zj$" not in t
        return f"$zj${t}$zj$::jsonb"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, str):
        return "'" + v.replace("'", "''") + "'"
    return repr(float(v)) if not float(v).is_integer() else f"{v}"


def main():
    rutas = [RAIZ / "parametros_finales" / f"{n.lower().replace(' ', '_')}.json" for n in PERSONALIDADES]
    perfiles = [leer_archivo(r) for r in rutas]
    err = validar_conjunto_de_cinco(perfiles)
    if err:
        raise SystemExit(err)
    lineas = ["-- Zentheris v4.3 · carga NO destructiva de perfiles_simulacion (generado).",
              f"-- Versión del modelo de referencia: {VERSION_MODELO}",
              "-- Fuente: parametros_finales/*.json; SHA-256:"]
    lineas += [f"--   {r.name} {hashlib.sha256(r.read_bytes()).hexdigest()}" for r in rutas]
    lineas += ["-- Requiere la restricción UNIQUE(nombre) de la tabla 12. No borra filas ni cambia id/created_at.",
               "-- Ajuste search_path al esquema destino antes de ejecutar (p. ej. zentheris_prueba).",
               "-- Estado: NO EJECUTADO en esta entrega.", "BEGIN;"]
    for p in perfiles:
        vals = ",\n    ".join(literal(c, p[c]) for c in COLS)
        sets = ",\n    ".join(f"{c} = EXCLUDED.{c}" for c in COLS if c != "nombre")
        lineas.append(f"INSERT INTO perfiles_simulacion ({', '.join(COLS)})\nVALUES (\n    {vals}\n)\n"
                      f"ON CONFLICT (nombre) DO UPDATE SET\n    {sets},\n    updated_at = now();")
    lineas.append("COMMIT;")
    destino = RAIZ / "sql" / "01_carga_perfiles_simulacion.sql"
    destino.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    print("SQL escrito:", destino.name)


if __name__ == "__main__":
    main()
