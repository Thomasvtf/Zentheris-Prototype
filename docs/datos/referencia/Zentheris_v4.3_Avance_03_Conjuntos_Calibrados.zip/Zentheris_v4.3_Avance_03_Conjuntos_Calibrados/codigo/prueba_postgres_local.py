"""Prueba punta a punta en PostgreSQL LOCAL aislado (no Supabase):
archivo final -> validación -> carga no destructiva -> lectura desde base -> simulador ->
almacenamiento de lecturas -> consultas de comprobación.

Requisitos: PostgreSQL >= 13 local y `pip install "psycopg[binary]==3.2.3"`.
La conexión se toma de la variable de entorno ZENTHERIS_PG_DSN (nunca escriba
credenciales en este archivo), por ejemplo: postgresql://localhost/zentheris_pruebas
Uso (desde avance_03): python codigo/prueba_postgres_local.py
Estado en esta entrega: ESCRITO, NO EJECUTADO (el entorno no tenía PostgreSQL).
"""
import csv
import json
import os
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "codigo"))
from zentheris_sim.almacen import crear_hogar, id_estable  # noqa: E402
from calibracion.comun import CONG  # noqa: E402
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES, ZONA_HORARIA  # noqa: E402
from zentheris_sim.simulador import a_filas_lectura, backfill  # noqa: E402
from zentheris_sim.validacion import leer_archivo, validar_conjunto_de_cinco  # noqa: E402

AHORA = datetime(2026, 11, 30, 23, 30, tzinfo=ZONA_HORARIA)


def main():
    import psycopg  # import tardío: el resto del paquete no depende de él
    dsn = os.environ.get("ZENTHERIS_PG_DSN")
    if not dsn:
        raise SystemExit("Defina ZENTHERIS_PG_DSN (PostgreSQL local de pruebas).")
    perfiles = {n: leer_archivo(RAIZ / "parametros_finales" / f"{n.lower().replace(' ', '_')}.json") for n in PERSONALIDADES}
    assert not validar_conjunto_de_cinco(list(perfiles.values()))
    res = []
    with psycopg.connect(dsn, autocommit=False) as con, con.cursor() as cur:
        cur.execute((RAIZ / "sql" / "00_esquema_prueba_aislado.sql").read_text(encoding="utf-8"))
        cur.execute("SET search_path TO zentheris_prueba")
        carga = (RAIZ / "sql" / "01_carga_perfiles_simulacion.sql").read_text(encoding="utf-8")
        carga = carga.replace("BEGIN;", "").replace("COMMIT;", "")
        cur.execute(carga)
        cur.execute("SELECT id, nombre FROM perfiles_simulacion")
        ids1 = dict((n, i) for i, n in cur.fetchall())
        cur.execute(carga)  # segunda carga: debe conservar los id (no destructiva)
        cur.execute("SELECT id, nombre FROM perfiles_simulacion")
        ids2 = dict((n, i) for i, n in cur.fetchall())
        res.append(("carga_idempotente_conserva_id", ids1 == ids2 and len(ids1) == 5))
        for n, p in perfiles.items():
            cur.execute("SELECT * FROM perfiles_simulacion WHERE nombre = %s", (n,))
            fila = dict(zip([d.name for d in cur.description], cur.fetchone()))
            leido = {c: (float(fila[c]) if isinstance(fila[c], Decimal) else fila[c]) for c in p}
            res.append((f"ida_y_vuelta_{n}", all(leido[c] == p[c] for c in p)))
            # hogar de referencia desde la base -> simulador -> lecturas
            ref = CONG["referencias"][n]
            h = crear_hogar(f"pg|{n}", ref["vivienda"], tuple(ref["zonas"]))
            cur.execute("INSERT INTO hogares VALUES (%s,%s,%s,%s) ON CONFLICT (id) DO NOTHING",
                        (h["id"], f"Prueba {n}", h["vivienda"], ids2[n]))
            cur.execute("INSERT INTO fuentes_principales VALUES (%s,%s,%s,'activa') ON CONFLICT (id) DO NOTHING",
                        (h["fuente_id"], h["id"], f"Fuente principal Prueba {n}"))
            for z, sid in h["sensores"].items():
                zid = id_estable("zona", f"pg|{n}", z)
                cur.execute("INSERT INTO zonas VALUES (%s,%s,%s,%s,'activa') ON CONFLICT (id) DO NOTHING",
                            (zid, h["id"], z.capitalize(), z))
                cur.execute("INSERT INTO sensores_zona VALUES (%s,%s,%s,'activo') ON CONFLICT (id) DO NOTHING",
                            (sid, zid, h["fuente_id"]))
            filas = a_filas_lectura(h["sensores"], backfill(h, leido, AHORA))
            cur.executemany("INSERT INTO lecturas (sensor_id, fecha_hora, consumo_kwh, calidad) VALUES "
                            "(%(sensor_id)s,%(fecha_hora)s,%(consumo_kwh)s,%(calidad)s) "
                            "ON CONFLICT (sensor_id, fecha_hora) DO NOTHING", filas)
            cur.execute("SELECT sensor_id, fecha_hora, consumo_kwh FROM lecturas WHERE sensor_id = ANY(%s)",
                        (list(h["sensores"].values()),))
            guardado = {(str(s), f.astimezone(ZONA_HORARIA)): v for s, f, v in cur.fetchall()}
            iguales = all(guardado.get((f["sensor_id"], f["fecha_hora"])) == f["consumo_kwh"] for f in filas)
            por_sensor = {}
            for (s, _) in guardado:
                por_sensor[s] = por_sensor.get(s, 0) + 1
            res.append((f"lecturas_720_por_zona_{n}", set(por_sensor.values()) == {720}))
            res.append((f"valores_iguales_antes_despues_{n}", iguales))
        con.rollback()  # no deja datos persistentes
    with open(RAIZ / "resultados" / "prueba_postgres_local.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["prueba", "estado"])
        w.writerows((k, "aprobado" if v else "fallido") for k, v in res)
    print(json.dumps(dict(res), ensure_ascii=False, indent=1))
    sys.exit(0 if all(v for _, v in res) else 1)


if __name__ == "__main__":
    main()
