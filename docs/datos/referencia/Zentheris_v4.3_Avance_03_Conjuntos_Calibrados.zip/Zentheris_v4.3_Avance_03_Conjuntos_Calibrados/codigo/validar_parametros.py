"""Valida uno o varios archivos JSON de `perfiles_simulacion`.

Uso:
  python codigo/validar_parametros.py archivo.json [...]        # cada archivo por separado
  python codigo/validar_parametros.py --cinco a.json b.json ...  # además exige los cinco nombres
Código de salida 0 solo si no hay errores. Validez estructural NO implica calibración.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from zentheris_sim.validacion import (ErrorParametros, contiene_credencial, leer_archivo,  # noqa: E402
                                      validar_conjunto_de_cinco, validar_perfil)


def main(args):
    cinco = "--cinco" in args
    rutas = [a for a in args if a != "--cinco"]
    if not rutas:
        print(__doc__); return 2
    perfiles, fallos = [], 0
    for r in rutas:
        texto = Path(r).read_text(encoding="utf-8")
        if contiene_credencial(texto):
            print(f"[RECHAZADO] {r}: patrón de credencial"); fallos += 1; continue
        try:
            p = leer_archivo(r)
        except (ErrorParametros, ValueError) as e:
            print(f"[RECHAZADO] {r}: {e}"); fallos += 1; continue
        err = validar_perfil(p)
        print(f"[{'OK' if not err else 'RECHAZADO'}] {r}" + "".join(f"\n   - {c}: {m}" for c, m in err))
        fallos += bool(err)
        perfiles.append(p)
    if cinco:
        err = [x for x in validar_conjunto_de_cinco(perfiles) if x[0] in ("cinco_nombres", "id_duplicado")]
        print("[OK] cinco nombres exactos" if not err else "\n".join(f"[RECHAZADO] {c}: {m}" for c, m in err))
        fallos += bool(err)
    return 1 if fallos else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
