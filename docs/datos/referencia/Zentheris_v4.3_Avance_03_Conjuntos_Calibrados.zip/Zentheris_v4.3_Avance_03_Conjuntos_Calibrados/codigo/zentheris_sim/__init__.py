"""Implementación de referencia del simulador Zentheris v4.3.

No es el módulo de producción del backend. Sirve para especificar, probar y
calibrar los cinco conjuntos de `perfiles_simulacion` con la fórmula de la
sección 5 del documento v4.3, sin cambiarla.
"""
from .constantes import VERSION_MODELO  # noqa: F401
