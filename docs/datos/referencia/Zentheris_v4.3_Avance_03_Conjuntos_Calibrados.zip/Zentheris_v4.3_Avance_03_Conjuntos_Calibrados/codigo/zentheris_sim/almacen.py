"""Creación de hogares de prueba y almacén en memoria con la restricción
única (sensor_id, fecha_hora) de `lecturas`.

El almacén en memoria solo prueba la lógica de recuperación e idempotencia.
No demuestra compatibilidad con PostgreSQL (eso es otra capa, otra prueba).
"""
from __future__ import annotations

import uuid
from datetime import datetime

from .asignacion import asignar_personalidad, resolver_activa
from .simulador import (hora_desde_indice, indice_hora, redondear_kwh, simular_zona,
                        ultima_hora_completa)

ESPACIO_PRUEBAS = uuid.UUID("6f1d3c3e-0000-4000-8000-7a656e746865")  # solo pruebas


def id_estable(*partes: str) -> str:
    return str(uuid.uuid5(ESPACIO_PRUEBAS, "|".join(partes)))


def crear_hogar(etiqueta: str, vivienda: str, zonas, activos: dict[str, bool] | None = None) -> dict:
    """Equivalente de prueba de RN-X-03: valida, asigna personalidad y crea un sensor por zona."""
    asignada = asignar_personalidad(vivienda, zonas)
    efectiva = resolver_activa(asignada, activos) if activos is not None else asignada
    hid = id_estable("hogar", etiqueta)
    return {"id": hid, "etiqueta": etiqueta, "vivienda": vivienda, "zonas": frozenset(zonas),
            "personalidad_asignada": asignada, "personalidad": efectiva,
            "fuente_id": id_estable("fuente", etiqueta),
            "sensores": {z: id_estable("sensor", etiqueta, z) for z in sorted(zonas)}}


class AlmacenMemoria:
    def __init__(self):
        self.filas: dict[tuple[str, datetime], dict] = {}
        self.rechazos_por_duplicado = 0

    def insertar_si_no_existe(self, fila: dict) -> bool:
        clave = (fila["sensor_id"], fila["fecha_hora"])
        if clave in self.filas:          # equivale a ON CONFLICT DO NOTHING
            self.rechazos_por_duplicado += 1
            return False
        if fila["consumo_kwh"] < 0:
            raise ValueError("consumo_kwh >= 0")
        self.filas[clave] = dict(fila)
        return True

    def horas_de(self, sensor_id: str) -> set[int]:
        return {indice_hora(fh) for (s, fh) in self.filas if s == sensor_id}

    def frontera(self, sensor_id: str) -> int | None:
        h = self.horas_de(sensor_id)
        return min(h) if h else None


def generar_y_guardar(almacen, hogar: dict, perfil: dict, desde: int, hasta: int, frontera: int) -> int:
    n = 0
    for z, sid in hogar["sensores"].items():
        existentes = almacen.horas_de(sid)
        filas = simular_zona(hogar["id"], perfil, z, desde, hasta, frontera)
        for k, _, _, L in filas:
            if k in existentes:
                continue
            n += almacen.insertar_si_no_existe({"sensor_id": sid, "fecha_hora": hora_desde_indice(k),
                                                "consumo_kwh": redondear_kwh(L), "calidad": "simulada"})
    return n


def recuperar(almacen, hogar: dict, perfil: dict, ahora: datetime) -> int:
    """RN-IV-05 + A13: completa huecos internos y horas posteriores hasta la última
    hora completa, sin sobrescribir lo existente. La frontera es la primera lectura
    del sensor (no requiere columna nueva)."""
    fin = ultima_hora_completa(ahora) + 1
    n = 0
    for z, sid in hogar["sensores"].items():
        fr = almacen.frontera(sid)
        if fr is None:
            continue
        faltan = sorted(set(range(fr, fin)) - almacen.horas_de(sid))
        if not faltan:
            continue
        filas = {k: L for k, _, _, L in simular_zona(hogar["id"], perfil, z, faltan[0], fin, fr)}
        for k in faltan:
            n += almacen.insertar_si_no_existe({"sensor_id": sid, "fecha_hora": hora_desde_indice(k),
                                                "consumo_kwh": redondear_kwh(filas[k]), "calidad": "simulada"})
    return n
