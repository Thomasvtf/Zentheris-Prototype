"""Validación del onboarding (RN-X-02) y asignación de personalidad (RN-X-04).

Escrita directamente desde el texto de v4.3 (tabla de condiciones en orden).
Se contrasta en las pruebas con la implementación independiente del Avance 01.
"""
from __future__ import annotations

from itertools import combinations

from .constantes import BASICAS, COMPLEMENTARIAS, EXTRAS, PERSONALIDADES, RESPALDO, VIVIENDAS, ZONAS


class OnboardingInvalido(ValueError):
    pass


def validar_onboarding(vivienda: str, zonas) -> frozenset:
    if vivienda not in VIVIENDAS:
        raise OnboardingInvalido(f"vivienda desconocida: {vivienda!r}")
    if not isinstance(zonas, (list, tuple, set, frozenset)):
        raise OnboardingInvalido("zonas debe ser una colección")
    lista = list(zonas)
    if any(z not in ZONAS for z in lista):
        raise OnboardingInvalido("zona fuera del catálogo")
    if len(set(lista)) != len(lista):
        raise OnboardingInvalido("zona repetida")
    sel = frozenset(lista)
    if vivienda == "apartaestudio":
        if sel & set(EXTRAS):
            raise OnboardingInvalido("apartaestudio no admite extras")
        if not 3 <= len(sel) <= 5:
            raise OnboardingInvalido("apartaestudio: entre 3 y 5 zonas")
        if len(sel & set(BASICAS)) < 3:
            raise OnboardingInvalido("apartaestudio: al menos 3 básicas")
    elif not set(BASICAS) <= sel:
        raise OnboardingInvalido("las 4 básicas son obligatorias")
    return sel


def _como_casa(sel: frozenset) -> str:
    c = len(sel & {"oficina", "lavanderia", "terraza", "garaje"})
    s = 1 if "cuarto_servicio" in sel else 0
    E = len(sel & set(EXTRAS))
    OL = bool(sel & set(COMPLEMENTARIAS))
    if E >= 2 and OL:
        return "Consumo amplio"
    if c >= 2 or s == 1:
        return "Consumo familiar"
    if c == 1 and s == 0:
        return "Consumo intermedio"
    if c == 0 and s == 0:
        return "Consumo eficiente"
    raise AssertionError("condición no cubierta")  # inalcanzable


_SUBIR = {"Consumo eficiente": "Consumo intermedio", "Consumo intermedio": "Consumo familiar",
          "Consumo familiar": "Consumo amplio", "Consumo amplio": "Consumo amplio"}


def asignar_personalidad(vivienda: str, zonas) -> str:
    sel = validar_onboarding(vivienda, zonas)
    if vivienda == "apartaestudio":
        return "Consumo compacto" if len(sel) <= 4 else "Consumo eficiente"
    nombre = _como_casa(sel)
    return _SUBIR[nombre] if vivienda == "casa_campestre" else nombre


def resolver_activa(nombre: str, activos: dict[str, bool]) -> str:
    """Respaldo de RN-X-04: si la asignada no existe o está inactiva, eficiente."""
    if activos.get(nombre) is True:
        return nombre
    if activos.get(RESPALDO) is True:
        return RESPALDO
    raise LookupError("ni la personalidad asignada ni el respaldo eficiente están activos (A20)")


def enumerar_selecciones():
    """Las 5 × 2^9 = 2.560 selecciones posibles; devuelve (vivienda, zonas, válida, personalidad)."""
    for v in VIVIENDAS:
        for k in range(len(ZONAS) + 1):
            for combo in combinations(ZONAS, k):
                try:
                    yield v, combo, True, asignar_personalidad(v, combo)
                except OnboardingInvalido:
                    yield v, combo, False, None


def zonas_aplicables() -> dict[str, frozenset]:
    """Unión de zonas que puede recibir cada personalidad por asignación ordinaria,
    y las nueve para eficiente por el respaldo (A19)."""
    out = {p: set() for p in PERSONALIDADES}
    for _, combo, ok, p in enumerar_selecciones():
        if ok:
            out[p] |= set(combo)
    out[RESPALDO] = set(ZONAS)
    return {p: frozenset(z) for p, z in out.items()}
