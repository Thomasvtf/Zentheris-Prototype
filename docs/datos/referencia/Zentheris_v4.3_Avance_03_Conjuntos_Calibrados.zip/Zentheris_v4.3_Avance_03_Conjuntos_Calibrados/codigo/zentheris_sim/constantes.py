"""Catálogos y constantes del contrato v4.3 (no editar sin cambiar el contrato)."""
from zoneinfo import ZoneInfo

# Entra en la semilla (RN-IV-04). Cambiarla cambia todas las lecturas sintéticas.
VERSION_MODELO = "zentheris-4.3-ref-1"

ZONA_HORARIA = ZoneInfo("America/Bogota")

VIVIENDAS = ("apartamento", "casa", "apartaestudio", "duplex", "casa_campestre")
BASICAS = ("cocina", "sala", "dormitorio", "bano")
COMPLEMENTARIAS = ("oficina", "lavanderia")
EXTRAS = ("terraza", "garaje", "cuarto_servicio")
ZONAS = BASICAS + COMPLEMENTARIAS + EXTRAS

PERSONALIDADES = ("Consumo compacto", "Consumo eficiente", "Consumo intermedio",
                  "Consumo familiar", "Consumo amplio")
RESPALDO = "Consumo eficiente"

COLUMNAS_BASE = {z: f"base_{z}_kwh_dia" for z in ZONAS}

CAMPOS_OBLIGATORIOS = (("nombre", "activo") + tuple(COLUMNAS_BASE.values()) +
                       ("curva_horaria", "humor_min", "humor_max", "ruido_config",
                        "picos_config", "factor_fin_semana"))
# Gestionados por la base de datos: se aceptan en el archivo, no son obligatorios.
CAMPOS_OPCIONALES = ("id", "created_at", "updated_at")

CLAVES_RUIDO = ("memoria", "intensidad")
CLAVES_PICO = ("probabilidad", "franjas", "potencia_w", "duracion_min",
               "minuto_inicio", "fraccion_uso")
CLAVES_FRANJA = ("desde", "hasta", "multiplicador")

TOL_SUMA_CURVA = 1e-10      # CT03
TOL_CONSERVACION = 1e-10    # CT06/CT07, relativa a max(1, T)
ESCALA_KWH = 4              # NUMERIC(12,4) en lecturas
