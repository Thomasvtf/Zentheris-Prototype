"""Semillas estables (A14): SHA-256 de una serialización JSON canónica.

semilla = SHA-256({dominio, fecha, hogar_id, version, zona}) como entero de 256 bits.
Nunca se usa hash() de Python (depende de PYTHONHASHSEED).

Dominios de sorteo:
  "humor"   -> 1 uniforme por hogar y día (zona = None)
  "ruido"   -> 24 uniformes por zona y día (épsilon = 2u - 1)
  "eventos" -> 24 × 5 uniformes por zona y día, SIEMPRE los mismos 5 por hora
               (ocurrencia, potencia, duración, minuto, fracción), aunque la
               probabilidad sea 0: así cambiar un parámetro no desplaza los
               demás sorteos (números aleatorios comunes en la calibración).
"""
from __future__ import annotations

import hashlib
import json
import random
import uuid
from datetime import date

DOMINIOS = ("humor", "ruido", "eventos")


def serializacion_canonica(hogar_id, fecha: date, version: str, zona, dominio: str) -> bytes:
    if dominio not in DOMINIOS:
        raise ValueError(f"dominio desconocido: {dominio}")
    datos = {"dominio": dominio, "fecha": fecha.isoformat(),
             "hogar_id": str(uuid.UUID(str(hogar_id))), "version": version, "zona": zona}
    return json.dumps(datos, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def derivar_semilla(hogar_id, fecha: date, version: str, zona, dominio: str) -> int:
    return int.from_bytes(hashlib.sha256(
        serializacion_canonica(hogar_id, fecha, version, zona, dominio)).digest(), "big")


def uniformes(hogar_id, fecha: date, version: str, zona, dominio: str, n: int) -> list[float]:
    """n uniformes en [0, 1) del generador Mersenne Twister sembrado con un entero
    (la secuencia de random() para una semilla entera es estable entre versiones de CPython)."""
    rng = random.Random(derivar_semilla(hogar_id, fecha, version, zona, dominio))
    return [rng.random() for _ in range(n)]
