"""Simulador de referencia fiel a la sección 5 de v4.3.

L = T·Q + ΣE,  T = B·H·F,  n(t) = φ·n(t−1) + σ·ε,  w' = max(0, w·(1+n)),  Q = w'/Σw'
E = P·(D/60)·f/1000 repartida por minutos de solapamiento.

Convenciones adoptadas (Avance 01, A05–A15):
- franjas [desde, hasta); p efectiva = probabilidad × multiplicador (A05)
- P, D y f uniformes continuas; minuto uniforme discreto inclusivo (A06)
- n[−1] = 0 y la hora 0 ya recibe su innovación (A07)
- realización con Σw' <= 0 se rechaza, no se corrige (A08)
- la lectura de una hora se etiqueta por su inicio [h, h+1) (A12)
- frontera izquierda del historial: no se incorporan eventos iniciados antes (A10);
  la cola derecha del backfill no se exporta y la generación posterior la suma (A09)
- Q se calcula con el día completo aunque se exporte una parte (A11)

Representación del tiempo: índice horario absoluto = ordinal_de_fecha × 24 + hora,
en hora local de Bogotá (sin horario de verano), convertido a datetime con
zona America/Bogota solo al exportar.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal

from .constantes import COLUMNAS_BASE, ESCALA_KWH, VERSION_MODELO, ZONA_HORARIA
from .semillas import uniformes
from .validacion import probabilidades_efectivas


class RealizacionDegenerada(ArithmeticError):
    """Σw' <= 0: el ruido anuló toda la curva (A08)."""


@dataclass(frozen=True)
class Evento:
    zona: str
    inicio_min: int        # minutos absolutos enteros (ordinal × 1440 + minuto del día)
    duracion_min: float
    potencia_w: float
    fraccion_uso: float
    energia_kwh: float

    @property
    def fin_min(self) -> float:
        return self.inicio_min + self.duracion_min


# ------------------------------------------------------------ tiempo
def indice_hora(dt: datetime) -> int:
    loc = dt.astimezone(ZONA_HORARIA)
    return loc.date().toordinal() * 24 + loc.hour


def hora_desde_indice(idx: int) -> datetime:
    d = date.fromordinal(idx // 24)
    return datetime(d.year, d.month, d.day, idx % 24, tzinfo=ZONA_HORARIA)


def ultima_hora_completa(ahora: datetime) -> int:
    """Índice de la última hora completa [h, h+1) con h+1 <= ahora (RN-XI-01)."""
    loc = ahora.astimezone(ZONA_HORARIA)
    return loc.date().toordinal() * 24 + loc.hour - 1


# ------------------------------------------------------------ componentes puros
def humor(hogar_id, fecha: date, perfil: dict, version: str = VERSION_MODELO) -> float:
    (u,) = uniformes(hogar_id, fecha, version, None, "humor", 1)
    return perfil["humor_min"] + (perfil["humor_max"] - perfil["humor_min"]) * u


def factor_calendario(fecha: date, perfil: dict) -> float:
    return perfil["factor_fin_semana"] if fecha.weekday() >= 5 else 1.0


def curva_zona(perfil: dict, zona: str) -> list[float]:
    ch = perfil["curva_horaria"]
    return ch.get(zona, ch["base"])


def calcular_q(w: list[float], eps: list[float], memoria: float, intensidad: float):
    """Devuelve (Q, n). Lanza RealizacionDegenerada si Σw' <= 0."""
    n_prev, n, wp = 0.0, [], []
    for t in range(24):
        nt = memoria * n_prev + intensidad * eps[t]
        n.append(nt)
        wp.append(max(0.0, w[t] * (1.0 + nt)))
        n_prev = nt
    s = math.fsum(wp)
    if not s > 0:
        raise RealizacionDegenerada("Σw' <= 0")
    return [x / s for x in wp], n


def epsilones(hogar_id, fecha: date, zona: str, version: str = VERSION_MODELO) -> list[float]:
    return [2.0 * u - 1.0 for u in uniformes(hogar_id, fecha, version, zona, "ruido", 24)]


def regular_dia(hogar_id, fecha: date, zona: str, perfil: dict, version: str = VERSION_MODELO) -> dict:
    B = perfil[COLUMNAS_BASE[zona]]
    H = humor(hogar_id, fecha, perfil, version)
    F = factor_calendario(fecha, perfil)
    T = B * H * F
    r = perfil["ruido_config"]
    Q, n = calcular_q(curva_zona(perfil, zona), epsilones(hogar_id, fecha, zona, version),
                      r["memoria"], r["intensidad"])
    return {"B": B, "H": H, "F": F, "T": T, "Q": Q, "n": n, "regular": [T * q for q in Q]}


def _uniforme(a: float, b: float, u: float) -> float:
    return a + (b - a) * u


def _minuto(a: int, b: int, u: float) -> int:
    a, b = int(a), int(b)
    return min(b, a + int(math.floor(u * (b - a + 1))))


def eventos_dia(hogar_id, fecha: date, zona: str, perfil: dict, version: str = VERSION_MODELO) -> list[Evento]:
    cfg = perfil["picos_config"].get(zona)
    if cfg is None:
        return []
    u = uniformes(hogar_id, fecha, version, zona, "eventos", 24 * 5)
    pe = probabilidades_efectivas(cfg)
    base_min = fecha.toordinal() * 1440
    out = []
    for t in range(24):
        u_occ, u_p, u_d, u_m, u_f = u[5 * t:5 * t + 5]
        if u_occ < pe[t]:
            P = _uniforme(*cfg["potencia_w"], u_p)
            D = _uniforme(*cfg["duracion_min"], u_d)
            m = _minuto(*cfg["minuto_inicio"], u_m)
            f = _uniforme(*cfg["fraccion_uso"], u_f)
            out.append(Evento(zona, base_min + 60 * t + m, D, P, f, P * (D / 60.0) * f / 1000.0))
    return out


def reparto_evento(ev: Evento) -> dict[int, float]:
    """Energía del evento por índice horario, proporcional a minutos de solapamiento."""
    if ev.duracion_min <= 0 or ev.energia_kwh == 0:
        return {}
    # Se trabaja con desplazamientos relativos a la hora de inicio: con minutos
    # absolutos (~1e9) la suma inicio + D pierde precisión (registro_cambios, F01).
    k0 = int(ev.inicio_min) // 60
    off = ev.inicio_min - 60 * k0          # minuto entero dentro de la hora
    fin = off + ev.duracion_min
    out, j = {}, 0
    while 60 * j < fin:
        solape = min(fin, 60.0 * (j + 1)) - max(off, 60.0 * j)
        if solape > 0:
            out[k0 + j] = ev.energia_kwh * solape / ev.duracion_min
        j += 1
    return out


def dias_retroceso(perfil: dict) -> int:
    """Días previos cuyos eventos pueden alcanzar el día actual."""
    dmax = max((c["duracion_min"][1] for c in perfil["picos_config"].values()), default=0)
    return int(math.ceil((59 + dmax) / 1440.0)) if dmax > 0 else 0


# ------------------------------------------------------------ generación
def simular_zona(hogar_id, perfil: dict, zona: str, desde: int, hasta: int, frontera: int,
                 version: str = VERSION_MODELO, detalle: bool = False):
    """Lecturas de una zona para índices horarios [desde, hasta).

    frontera: índice de la primera hora del historial del sensor; no se incorporan
    eventos iniciados antes de ella (A10). La lectura de cada hora es una función
    pura de (hogar, perfil, zona, hora, frontera, versión): backfill, generación
    incremental y recuperación producen el mismo valor.
    """
    if not frontera <= desde <= hasta:
        raise ValueError("se exige frontera <= desde <= hasta")
    reg, evh = {}, {k: 0.0 for k in range(desde, hasta)}
    dias, eventos = {}, []
    d0, d1 = desde // 24, (hasta - 1) // 24
    for o in range(d0, d1 + 1):
        r = regular_dia(hogar_id, date.fromordinal(o), zona, perfil, version)
        dias[o] = r
        for t in range(24):
            k = o * 24 + t
            if desde <= k < hasta:
                reg[k] = r["regular"][t]
    for o in range(max(frontera // 24, d0 - dias_retroceso(perfil)), d1 + 1):
        for ev in eventos_dia(hogar_id, date.fromordinal(o), zona, perfil, version):
            if ev.inicio_min < frontera * 60 or ev.inicio_min >= hasta * 60:
                continue
            for k, v in reparto_evento(ev).items():
                if desde <= k < hasta:
                    evh[k] += v
            eventos.append(ev)
    filas = [(k, reg[k], evh[k], reg[k] + evh[k]) for k in range(desde, hasta)]
    if detalle:
        return filas, dias, eventos
    return filas


def simular_hogar(hogar: dict, perfil: dict, desde: int, hasta: int, frontera: int | None = None,
                  version: str = VERSION_MODELO) -> dict[str, list]:
    """Solo zonas elegidas por el hogar (RN-IV-07): las ausentes no generan filas
    y su base no se reparte."""
    frontera = desde if frontera is None else frontera
    return {z: simular_zona(hogar["id"], perfil, z, desde, hasta, frontera, version)
            for z in sorted(hogar["zonas"])}


def backfill(hogar: dict, perfil: dict, ahora: datetime, horas: int = 720,
             version: str = VERSION_MODELO) -> dict[str, list]:
    """RN-IV-01: 720 horas que terminan en la última hora completa."""
    fin = ultima_hora_completa(ahora) + 1
    ini = fin - horas
    return simular_hogar(hogar, perfil, ini, fin, ini, version)


def total_hogar(series: dict[str, list]) -> dict[int, float]:
    """El total del hogar se deriva de las zonas; no es una lectura almacenada."""
    out: dict[int, float] = {}
    for filas in series.values():
        for k, _, _, L in filas:
            out[k] = out.get(k, 0.0) + L
    return out


def redondear_kwh(x: float) -> Decimal:
    """Valor tal como lo guardaría NUMERIC(12,4) (redondeo mitad hacia arriba, x >= 0)."""
    return Decimal(repr(x)).quantize(Decimal(1).scaleb(-ESCALA_KWH), rounding=ROUND_HALF_UP)


def a_filas_lectura(sensor_por_zona: dict[str, str], series: dict[str, list]) -> list[dict]:
    """Filas para `lecturas` (sin id; calidad = 'simulada')."""
    out = []
    for z, filas in series.items():
        for k, _, _, L in filas:
            out.append({"sensor_id": sensor_por_zona[z], "fecha_hora": hora_desde_indice(k),
                        "consumo_kwh": redondear_kwh(L), "calidad": "simulada"})
    return out


def fin_dia_exclusivo(d: date) -> int:
    return (d + timedelta(days=1)).toordinal() * 24
