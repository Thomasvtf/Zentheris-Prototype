"""Lectura y validación estricta de un conjunto de `perfiles_simulacion`.

Valida estructura y coherencia (sección 5 y tabla 12 de v4.3 más las
convenciones A05–A08 y CT01–CT05). Pasar la validación NO significa que el
conjunto esté calibrado.
"""
from __future__ import annotations

import json
import math
import re
import uuid
from datetime import datetime
from decimal import Decimal, InvalidOperation

from .constantes import (CAMPOS_OBLIGATORIOS, CAMPOS_OPCIONALES, CLAVES_FRANJA,
                         CLAVES_PICO, CLAVES_RUIDO, COLUMNAS_BASE, PERSONALIDADES,
                         TOL_SUMA_CURVA, ZONAS)


class ErrorParametros(ValueError):
    """Conjunto rechazado; `errores` lista (codigo, mensaje)."""

    def __init__(self, errores):
        self.errores = list(errores)
        super().__init__("; ".join(f"{c}: {m}" for c, m in self.errores))


# ---------------------------------------------------------------- lectura JSON
def _sin_duplicados(pares):
    claves = [k for k, _ in pares]
    repetidas = sorted({k for k in claves if claves.count(k) > 1})
    if repetidas:
        raise ErrorParametros([("clave_duplicada", f"claves repetidas: {repetidas}")])
    return dict(pares)


def _constante_invalida(nombre):
    raise ErrorParametros([("no_finito", f"valor no permitido en JSON: {nombre}")])


def cargar_json_estricto(texto: str):
    """json.loads que rechaza claves duplicadas, NaN e Infinity."""
    return json.loads(texto, object_pairs_hook=_sin_duplicados,
                      parse_constant=_constante_invalida)


def leer_archivo(ruta) -> dict:
    with open(ruta, encoding="utf-8") as fh:
        return cargar_json_estricto(fh.read())


# ------------------------------------------------------------------ utilidades
def es_numero(v) -> bool:
    """Número JSON finito; los booleanos no cuentan como número."""
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v))


def _decimales_ok(v, escala: int, enteros: int) -> bool:
    """Cabe en NUMERIC(enteros+escala, escala) sin perder dígitos."""
    try:
        d = Decimal(str(v))
    except InvalidOperation:
        return False
    if d.as_tuple().exponent < -escala:
        return False
    return abs(d) < Decimal(10) ** enteros


def probabilidades_efectivas(cfg: dict) -> list[float]:
    """Probabilidad por hora tras aplicar franjas [desde, hasta) (A05)."""
    p = [float(cfg["probabilidad"])] * 24
    for f in cfg["franjas"]:
        for h in range(int(f["desde"]), int(f["hasta"])):
            p[h] = float(cfg["probabilidad"]) * float(f["multiplicador"])
    return p


def margen_ruido(perfil: dict) -> float:
    """sigma/(1-phi): cota de |n|. < 1 evita denominadores nulos (A08/CT05)."""
    r = perfil["ruido_config"]
    return r["intensidad"] / (1 - r["memoria"])


# ------------------------------------------------------------------ validación
def validar_perfil(p, exigir_margen_ruido: bool = True) -> list[tuple[str, str]]:
    """Devuelve la lista de errores (vacía si el conjunto es estructuralmente válido)."""
    e: list[tuple[str, str]] = []
    if not isinstance(p, dict):
        return [("tipo", "el conjunto debe ser un objeto JSON")]

    desconocidas = sorted(set(p) - set(CAMPOS_OBLIGATORIOS) - set(CAMPOS_OPCIONALES))
    if desconocidas:
        e.append(("clave_desconocida", f"campos fuera del contrato: {desconocidas}"))
    faltan = [c for c in CAMPOS_OBLIGATORIOS if c not in p]
    if faltan:
        e.append(("campo_faltante", f"faltan: {faltan}"))

    # identificación
    if "nombre" in p and p["nombre"] not in PERSONALIDADES:
        e.append(("nombre", f"nombre fuera de los cinco exactos: {p['nombre']!r}"))
    if "activo" in p and not isinstance(p["activo"], bool):
        e.append(("activo", "activo debe ser booleano"))
    if "id" in p:
        try:
            uuid.UUID(str(p["id"]))
            if not isinstance(p["id"], str):
                raise ValueError
        except ValueError:
            e.append(("id", "id debe ser un UUID en texto"))
    for c in ("created_at", "updated_at"):
        if c in p:
            try:
                datetime.fromisoformat(p[c])
            except (TypeError, ValueError):
                e.append((c, f"{c} debe ser fecha ISO 8601"))

    # bases NUMERIC(10,4) >= 0
    for zona, col in COLUMNAS_BASE.items():
        if col not in p:
            continue
        v = p[col]
        if not es_numero(v):
            e.append(("base_tipo", f"{col} debe ser número finito"))
        elif v < 0:
            e.append(("base_negativa", f"{col} < 0"))
        elif not _decimales_ok(v, 4, 6):
            e.append(("base_precision", f"{col} excede NUMERIC(10,4)"))

    # humor y factor NUMERIC(6,4)
    for c in ("humor_min", "humor_max", "factor_fin_semana"):
        if c in p:
            v = p[c]
            if not es_numero(v):
                e.append((f"{c}_tipo", f"{c} debe ser número finito"))
            elif not _decimales_ok(v, 4, 2):
                e.append((f"{c}_precision", f"{c} excede NUMERIC(6,4)"))
    if all(es_numero(p.get(c)) for c in ("humor_min", "humor_max")):
        if p["humor_min"] < 0:
            e.append(("humor_negativo", "humor_min < 0"))
        if p["humor_min"] > p["humor_max"]:
            e.append(("humor_invertido", "humor_min > humor_max"))
    if es_numero(p.get("factor_fin_semana")) and p["factor_fin_semana"] <= 0:
        e.append(("factor_no_positivo", "factor_fin_semana debe ser > 0"))

    # curvas
    ch = p.get("curva_horaria")
    if "curva_horaria" in p:
        if not isinstance(ch, dict):
            e.append(("curva_tipo", "curva_horaria debe ser objeto"))
        else:
            if "base" not in ch:
                e.append(("curva_base", "curva_horaria.base es obligatoria"))
            for k, c in ch.items():
                if k != "base" and k not in ZONAS:
                    e.append(("curva_clave", f"curva_horaria.{k} no es zona del catálogo"))
                    continue
                if not isinstance(c, list) or len(c) != 24:
                    e.append(("curva_longitud", f"curva {k}: exactamente 24 valores"))
                    continue
                if not all(es_numero(x) for x in c):
                    e.append(("curva_valor", f"curva {k}: valores numéricos finitos"))
                    continue
                if any(x < 0 for x in c):
                    e.append(("curva_negativa", f"curva {k}: valores >= 0"))
                    continue
                if abs(math.fsum(c) - 1.0) > TOL_SUMA_CURVA:
                    e.append(("curva_suma", f"curva {k}: suma {math.fsum(c)!r} != 1"))

    # ruido
    r = p.get("ruido_config")
    if "ruido_config" in p:
        if not isinstance(r, dict):
            e.append(("ruido_tipo", "ruido_config debe ser objeto"))
        else:
            extra = sorted(set(r) - set(CLAVES_RUIDO))
            if extra:
                e.append(("ruido_clave", f"ruido_config solo admite memoria e intensidad; sobran {extra}"))
            m, s = r.get("memoria"), r.get("intensidad")
            if not es_numero(m) or not 0 <= m < 1:
                e.append(("ruido_memoria", "memoria debe estar en [0, 1)"))
            if not es_numero(s) or s < 0:
                e.append(("ruido_intensidad", "intensidad debe ser >= 0"))
            if (exigir_margen_ruido and es_numero(m) and es_numero(s)
                    and 0 <= m < 1 and s >= 0 and s / (1 - m) >= 1):
                e.append(("ruido_margen", "se exige intensidad/(1-memoria) < 1 (A08/CT05)"))

    # picos
    pc = p.get("picos_config")
    if "picos_config" in p:
        if not isinstance(pc, dict):
            e.append(("picos_tipo", "picos_config debe ser objeto"))
        else:
            for z, cfg in pc.items():
                e.extend(_validar_pico(z, cfg))
    return e


def _rango(cfg, clave, z, minimo=None, maximo=None, entero=False):
    rg = cfg.get(clave)
    if not (isinstance(rg, list) and len(rg) == 2 and all(es_numero(x) for x in rg)):
        return [("pico_rango", f"picos_config.{z}.{clave}: [min, max] numéricos")]
    a, b = rg
    out = []
    if a > b:
        out.append(("pico_rango_invertido", f"picos_config.{z}.{clave}: min > max"))
    if entero and not all(float(x).is_integer() for x in rg):
        out.append(("pico_rango_entero", f"picos_config.{z}.{clave}: valores enteros"))
    if minimo is not None and min(a, b) < minimo:
        out.append(("pico_rango_limite", f"picos_config.{z}.{clave}: valor < {minimo}"))
    if maximo is not None and max(a, b) > maximo:
        out.append(("pico_rango_limite", f"picos_config.{z}.{clave}: valor > {maximo}"))
    return out


def _validar_pico(z, cfg):
    if z not in ZONAS:
        return [("pico_clave", f"picos_config.{z} no es zona del catálogo")]
    if not isinstance(cfg, dict):
        return [("pico_tipo", f"picos_config.{z} debe ser objeto")]
    e = []
    extra = sorted(set(cfg) - set(CLAVES_PICO))
    faltan = [k for k in CLAVES_PICO if k not in cfg]
    if extra:
        e.append(("pico_clave_desconocida", f"picos_config.{z}: sobran {extra}"))
    if faltan:
        return e + [("pico_campo_faltante", f"picos_config.{z}: faltan {faltan}")]
    pr = cfg["probabilidad"]
    if not es_numero(pr) or not 0 <= pr <= 1:
        e.append(("pico_probabilidad", f"picos_config.{z}.probabilidad en [0, 1]"))
    e += _rango(cfg, "potencia_w", z, minimo=0)
    e += _rango(cfg, "duracion_min", z, minimo=0)
    e += _rango(cfg, "minuto_inicio", z, minimo=0, maximo=59, entero=True)
    e += _rango(cfg, "fraccion_uso", z, minimo=0, maximo=1)
    fr = cfg["franjas"]
    if not isinstance(fr, list):
        return e + [("franja_tipo", f"picos_config.{z}.franjas debe ser lista")]
    horas = set()
    for f in fr:
        if not isinstance(f, dict) or set(f) != set(CLAVES_FRANJA):
            e.append(("franja_claves", f"picos_config.{z}: franja con claves desde/hasta/multiplicador"))
            continue
        d, h, m = f["desde"], f["hasta"], f["multiplicador"]
        if not all(es_numero(x) for x in (d, h, m)) or not (float(d).is_integer() and float(h).is_integer()):
            e.append(("franja_valor", f"picos_config.{z}: desde/hasta enteros, multiplicador numérico"))
            continue
        if not (0 <= d < h <= 24):
            e.append(("franja_limites", f"picos_config.{z}: se exige 0 <= desde < hasta <= 24 ({d}, {h})"))
            continue
        if m < 0:
            e.append(("franja_multiplicador", f"picos_config.{z}: multiplicador >= 0"))
        nuevas = set(range(int(d), int(h)))
        if horas & nuevas:
            e.append(("franja_solapada", f"picos_config.{z}: franjas solapadas en {sorted(horas & nuevas)}"))
        horas |= nuevas
    if not e:
        pe = probabilidades_efectivas(cfg)
        malas = [h for h, v in enumerate(pe) if not 0 <= v <= 1]
        if malas:
            e.append(("pico_probabilidad_efectiva",
                      f"picos_config.{z}: probabilidad efectiva fuera de [0,1] en horas {malas}"))
    return e


def validar_o_fallar(p, exigir_margen_ruido: bool = True) -> dict:
    errores = validar_perfil(p, exigir_margen_ruido)
    if errores:
        raise ErrorParametros(errores)
    return p


def validar_conjunto_de_cinco(perfiles: list[dict]) -> list[tuple[str, str]]:
    """CT01: exactamente cinco conjuntos válidos, nombres exactos y sin colisiones."""
    e = []
    nombres = [x.get("nombre") for x in perfiles]
    if sorted(nombres) != sorted(PERSONALIDADES):
        e.append(("cinco_nombres", f"se esperan los cinco nombres exactos; hay {nombres}"))
    for x in perfiles:
        e += [(c, f"[{x.get('nombre')}] {m}") for c, m in validar_perfil(x)]
    ids = [x["id"] for x in perfiles if "id" in x]
    if len(ids) != len(set(ids)):
        e.append(("id_duplicado", "ids repetidos entre conjuntos"))
    return e


_PATRON_CREDENCIAL = re.compile(
    r"(eyJ[A-Za-z0-9_-]{10,}\.|ghp_[A-Za-z0-9]{20,}|sk-[A-Za-z0-9]{20,}|"
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----|service_role)")


def contiene_credencial(texto: str) -> bool:
    return bool(_PATRON_CREDENCIAL.search(texto))
