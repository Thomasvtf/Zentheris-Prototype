# Decisiones adoptadas (Avance 03)

Una línea por decisión: qué se eligió, por qué y cómo revertirla. Ninguna cambia la fórmula, las tablas, los catálogos ni RN-X-04.

| # | Decisión | Por qué | Cómo revertir |
|---|---|---|---|
| D1 | Criterios del Avance 02 adoptados tal cual (media ±3 %, ≥95/100 en ±10 %, CE02 por zona, CE15 ±5 %) | Opción por defecto; congelados antes de calibrar | Editar `congelamiento/congelamiento.json` y reejecutar `validar.py` con un grupo de semillas nuevo |
| D2 | A1 usa reparto proporcional 5/2 para horno y secadora (razón fin de semana/laboral 1,150) | Es el reparto con menor distorsión por zona bajo un F único; la energía mensual no cambia | Cambiar `REPARTO_5_2` en `hipotesis.py` y `REPARTO_A1` en `congelar_referencias.py`; reconstruir y revalidar |
| D3 | Convenciones A05–A15 del Avance 01 adoptadas | Opción por defecto | Ajustar `simulador.py` y la suite |
| D4 | Sin simulador real: implementación de referencia; módulo real y Supabase pendientes | No se aportó código ni acceso | Repetir la suite contra el módulo real cuando exista |
| D5 | Cada hora sortea siempre 5 uniformes de evento aunque p = 0 | Cambiar un parámetro no desplaza los demás sorteos | Cambiar `eventos_dia` (cambia todas las lecturas: subir `VERSION_MODELO`) |
| D6 | Bases = energía regular media de la zona × 7/(5+2F), con E[H] = 1 | Conserva la energía mensual de cada zona sin contar dos veces el aumento del fin de semana | Fórmula en `construir_conjuntos.py` |
| D7 | F = razón fin de semana/laboral del hogar de referencia (4 decimales) | Única opción coherente con un F global; los residuos por zona se informan (CE16) | Cambiar en `construir_conjuntos.py` |
| D8 | Curvas construidas desde ventanas horarias narrativas por equipo; cargas continuas planas 24 h; espera repartida 24 h | CE08/CE09; ventanas materializadas antes de simular | `ventanas_spec.py` |
| D9 | Zonas auxiliares desde contrastes: oficina C2 sin router (compacto, eficiente), lavandería E2 (compacto, eficiente) e I2 (intermedio), terraza y garaje A1, cuarto de servicio F2 (eficiente, familiar) y A2 (amplio), oficina A2 (amplio) | Completar todas las zonas aplicables sin inventar inventario | `FUENTE_ZONA` en `hipotesis.py` |
| D10 | Base 0 solo en zonas que la personalidad nunca recibe: compacto (terraza, garaje, cuarto de servicio) e intermedio (cuarto de servicio) | RN-X-04 no las asigna, ni por respaldo | — |
| D11 | Humor simétrico alrededor de 1: ±0,10 compacto y eficiente, ±0,12 intermedio y familiar, ±0,15 amplio | Hipótesis sin evidencia empírica; amplio con «mayor variación entre días» (tabla 12) | `HUMOR_SEMIANCHO` |
| D12 | Ruido φ = 0,6 en todas; σ = 0,10 / 0,06 / 0,10 / 0,12 / 0,15; margen σ/(1−φ) ≤ 0,375 | Hipótesis; «ruido bajo» en eficiente; margen < 1 evita denominadores nulos | `RUIDO` |
| D13 | Una familia de evento por zona, igual a los adicionales del Avance 02; inicio solo dentro de una ventana (multiplicador 0 fuera); rangos simétricos alrededor del valor central documentado | Conserva la energía esperada y un aparato interpretable | `EVENTOS` |
| D14 | Secadora: potencia media del ciclo = 3,2 kWh / 92,5 min = 2.075,7 W (no es potencia nominal) | La ficha da energía por ciclo, no potencia | `construir_conjuntos.py` |
| D15 | La fracción de uso del evento descuenta la espera sustituida (factor 0,9889 TV; 0,9993 microondas; 0,99995 secadora) | El objetivo del Avance 02 es energía neta | Quitar el factor `k` |
| D16 | CE02 se evalúa en «30 días equivalentes» reponderando días laborales y de fin de semana 5/7 y 2/7 | Separa el calendario de la energía por zona | `validar.py` |
| D17 | SQL de prueba en esquema aislado `zentheris_prueba`; carga con `ON CONFLICT (nombre) DO UPDATE` | Autorizado por Nicolás para pruebas; no destructivo | No ejecutar `00_esquema_prueba_aislado.sql` |
