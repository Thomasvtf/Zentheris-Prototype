# Escenarios, investigación y selección de los cinco conjuntos

Versión 1.0 · 2026-10-28. Reutiliza y enlaza los Avances 01 y 02. No los reescribe.

## Escenarios e investigación (entregables 1 y 2)

- **Diez escenarios** (C1, C2, E1, E2, I1, I2, F1, F2, A1, A2) con su revisión: `02_diez_escenarios_y_revision.md` del Avance 01, sin cambios.
- **Matriz de investigación:** D01–D23, M01–M20 y K01–K12 en `insumos/avance02/` y en el Avance 01, sin cambios.
- **Evidencia nueva de este avance:** no se incorporaron fuentes nuevas. La única cifra nueva es derivada: la potencia media del ciclo de la secadora (3,2 kWh / 92,5 min = 2.075,7 W), calculada de la ficha ya citada.

## Selección (actualiza el informe 02 del Avance 02)

Se mantienen las referencias C1, E1, I1, F1 y A1. Los contrastes C2, E2, I2, F2 y A2 se conservan como comparación y ahora también **aportan zonas auxiliares** a cada conjunto:

| Personalidad | Zona auxiliar | Fuente | Base kWh/día |
|---|---|---|---:|
| Compacto | oficina / lavandería | C2 sin router / E2 | 0,0933 / 0,0786 |
| Eficiente | oficina / lavandería | C2 sin router / E2 | 0,0892 / 0,0751 |
| Eficiente (solo respaldo) | terraza / garaje / cuarto de servicio | A1 / A1 / F2 | 0,1391 / 0,0865 / 0,1522 |
| Intermedio | lavandería / terraza / garaje | I2 / A1 / A1 | 0,1258 / 0,1439 / 0,0895 |
| Familiar | terraza / garaje / cuarto de servicio | A1 / A1 / F2 | 0,1423 / 0,0885 / 0,1557 |
| Amplio | oficina / cuarto de servicio | A2 / A2 | 0,6009 / 1,0269 |

Las bases en 0 corresponden solo a zonas que la personalidad nunca recibe por RN-X-04: compacto (terraza, garaje, cuarto de servicio) e intermedio (cuarto de servicio).

## Construcción de curvas

Las ventanas horarias por equipo se escribieron **antes** de simular, en `codigo/calibracion/ventanas_spec.py`, y se exportan en `resultados/trazabilidad_curvas_equipos.csv`. La energía activa de cada equipo se reparte en sus ventanas de día laboral y de fin de semana con pesos 5/7 y 2/7. La espera y las cargas continuas se reparten en 24 h. Por construcción, el 100 % de la energía activa no continua cae dentro de su ventana narrativa (CE08).

Los resultados y límites están en `02_informe_final_calibracion.md`.
