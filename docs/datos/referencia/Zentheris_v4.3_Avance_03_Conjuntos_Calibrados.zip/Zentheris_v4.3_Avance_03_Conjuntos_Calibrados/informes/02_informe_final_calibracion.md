# Informe final de calibración — cinco conjuntos de `perfiles_simulacion`

Versión 1.0 · 2026-10-28 · Contrato: Reglas de Negocio y Modelo de Datos v4.3 · Modelo de referencia `zentheris-4.3-ref-1`.
Todos los datos de este informe son **simulados**. Los porcentajes y bandas son criterios de ingeniería del prototipo, no evidencia de hogares reales.

## 1. Resultado en una frase

Los cinco conjuntos están **calibrados contra los objetivos congelados y verificados** con la implementación de referencia: estructura, modelo matemático, 147 combinaciones, calibración por etapas, validación ciega, año completo y sensibilidad. Falta probarlos en PostgreSQL local, en Supabase y con el módulo real del backend.

## 2. Cómo se obtuvieron

| Parámetro | De dónde sale | Naturaleza |
|---|---|---|
| Bases por zona | Energía regular media del balance (Avance 02) × 7/(5+2F) | Derivado de balances documentados |
| `factor_fin_semana` | Razón fin de semana/laboral del hogar de referencia | Derivado; único por hogar (limitación) |
| Curvas por zona | Ventanas horarias de cada equipo leídas de las narrativas; neveras, router y congelador planos 24 h | Interpretación de horarios narrativos |
| Zonas auxiliares | Contrastes C2 (sin router), E2, I2, F2, A1 y A2 | Préstamo documentado (D9) |
| `humor_min/max` | ±0,10 a ±0,15 alrededor de 1 | **Hipótesis** sin evidencia empírica |
| `ruido_config` | φ = 0,6; σ = 0,06 a 0,15 | **Hipótesis** sin evidencia empírica |
| `picos_config` | Eventos adicionales del Avance 02: frecuencia, duración y potencia de ficha | Derivado; probabilidad = eventos por día ÷ horas de la ventana |

Ningún valor se ajustó después de ver semillas. La calibración por etapas confirmó que cada componente produce exactamente lo esperado, así que no hubo iteraciones y no hay candidatos descartados.

## 3. Valores principales

| Personalidad | Ref. | F | Humor | φ / σ | Zonas con base > 0 | Eventos |
|---|---|---:|---|---|---|---|
| Consumo compacto | C1 | 0,9621 | 0,90–1,10 | 0,6 / 0,10 | 4 básicas, oficina, lavandería | TV en sala |
| Consumo eficiente | E1 | 1,1227 | 0,90–1,10 | 0,6 / 0,06 | Las nueve (respaldo RN-X-04) | Microondas |
| Consumo intermedio | I1 | 1,0032 | 0,88–1,12 | 0,6 / 0,10 | Todas menos cuarto de servicio | Microondas, portátil |
| Consumo familiar | F1 | 1,0423 | 0,88–1,12 | 0,6 / 0,12 | Las nueve | Freidora |
| Consumo amplio | A1 | 1,1500 | 0,85–1,15 | 0,6 / 0,15 | Las nueve | Horno, secadora, luces de terraza |

Las bases y los JSON completos están en `parametros_finales/`. La trazabilidad está en `resultados/trazabilidad_*.csv`.

## 4. Calibración por etapas

Grupo de calibración: 50 semillas, 2026-09-01 a 2026-10-01 (`resultados/calibracion_por_etapas.csv`).

| Etapa | Qué se activa | Resultado |
|---|---|---|
| 1 Plano | Solo bases | Error 0 frente a Σ B × días |
| 2 Forma | Curvas | Error 0 (las curvas no cambian el total) |
| 3 Humor | H diario | \|z\| < 2 en las cinco |
| 4 Fin de semana | F | \|z\| < 2 |
| 5 Ruido | φ y σ | Total idéntico al de la etapa 4 por semilla (diferencia ≤ 3 × 10⁻¹⁴ kWh) |
| 6 Eventos | Picos (conjunto final) | Error frente al objetivo congelado entre −0,56 % y +0,20 %; 50/50 semillas en ±10 % |

## 5. Validación ciega

Grupo de validación: 100 semillas, noviembre de 2026. No se modificó nada después de verlo.

| Personalidad | Objetivo kWh | Media | Error | CV | P5–P95 | En ±10 % (Wilson 95 %) |
|---|---:|---:|---:|---:|---|---|
| Compacto | 34,10 | 34,04 | −0,16 % | 1,1 % | 33,5–34,6 | 100/100 (0,963–1) |
| Eficiente | 57,63 | 57,56 | −0,12 % | 1,1 % | 56,4–58,5 | 100/100 (0,963–1) |
| Intermedio | 75,06 | 75,13 | +0,10 % | 1,3 % | 73,8–76,7 | 100/100 (0,963–1) |
| Familiar | 109,83 | 109,87 | +0,04 % | 1,2 % | 107,7–111,8 | 100/100 (0,963–1) |
| Amplio | 152,96 | 152,94 | −0,01 % | 2,9 % | 146,7–160,7 | 100/100 (0,963–1) |

Se aprobaron los 47 criterios de `resultados/criterios_validacion.csv`:

- **CE01** media y **CE03** cobertura.
- **CE02** energía por zona (26 zonas).
- **CE06** frecuencia y **CE07** energía de eventos.
- **CE10** ruido y **CE11** orden compacto < eficiente < intermedio < familiar < amplio.
- **CE14** año 2025, con errores entre −0,68 % y +0,60 %.
- **CE15** razón fin de semana/laboral.
- 15 hogares alternativos más el respaldo de nueve zonas.

Pruebas de software: 59/59 aprobadas (`resultados/pruebas_final.csv`), incluidas las 147 combinaciones con los conjuntos finales, y 8/8 defectos sembrados detectados.

## 6. Límites (no ocultos)

1. **Cocina dominante en compacto (67 %).** Contradice la descripción cualitativa de la tabla 12, pero se conservó porque la nevera está documentada.
2. **F único por hogar.** CE16 informa residuos grandes por zona: oficina +1.222 % en I1 y +2.341 % en F1, porque en la narrativa está casi apagada el fin de semana; lavandería −79 % en F1; baño −50 %. El total del hogar es correcto. Reproducir esas rutinas exactas es **incompatible** con v4.3 (CE17).
3. **Variación mensual baja (CV 1–3 %).** El humor es diario e independiente y se promedia en el mes. Un hogar real varía más. Cumplir la banda de ±10 % no demuestra realismo de la variabilidad.
4. **Humor y ruido** son hipótesis. La sensibilidad muestra que no cambian la media mensual (salvo ruido de muestreo); sí cambian la forma horaria y la dispersión.
5. **Los eventos no distinguen días.** Las visitas dominicales se reparten en todos los días.
6. **Duplicación posible en zonas auxiliares.** Un intermedio con lavandería conserva la lavadora en la base de cocina (I1) y además la tiene en lavandería (I2): unos 0,12 kWh/día. Lo mismo ocurre con los portátiles en amplio con oficina. La personalidad no sabe qué aparatos movió el hogar.
7. **Secadora:** ficha extranjera; la potencia es media de ciclo, no nominal.
8. **El orden se cumple en las referencias, no en todos los hogares posibles.** Por ejemplo, el dúplex de 9 zonas con eficiente de respaldo (75,1 kWh) supera a la casa campestre de 4 básicas con intermedio (65,9 kWh). Es coherente con RN-IV-07 y no se forzó.

## 7. Tabla final obligatoria

| Personalidad | Estructura validada | Calibración evaluada | Pruebas matemáticas | Pruebas estadísticas | Carga y lectura PostgreSQL | Módulo real | Supabase | Limitaciones pendientes |
|---|---|---|---|---|---|---|---|---|
| Compacto | aprobado (F01) | aprobado (−0,16 %) | aprobado (59/59) | aprobado | pendiente: sin PostgreSQL en el entorno; script listo | pendiente: no aportado | pendiente: sin acceso autorizado | Cocina 67 % frente a tabla 12; CV bajo |
| Eficiente | aprobado | aprobado (−0,12 %) | aprobado | aprobado | pendiente | pendiente | pendiente | Extras solo de respaldo; CV bajo |
| Intermedio | aprobado | aprobado (+0,10 %) | aprobado | aprobado | pendiente | pendiente | pendiente | Oficina en fin de semana; posible duplicación de lavadora |
| Familiar | aprobado | aprobado (+0,04 %) | aprobado | aprobado | pendiente | pendiente | pendiente | Oficina y lavandería por día |
| Amplio | aprobado | aprobado (−0,01 %) | aprobado | aprobado | pendiente | pendiente | pendiente | Secadora sin ficha local; fin de semana global |

## 8. Pendientes

- Ejecutar `codigo/prueba_postgres_local.py` en un PostgreSQL local (instrucciones en el README).
- Repetir la suite contra el módulo real del backend cuando exista.
- Cargar en Supabase solo con autorización.
- Ratificar con el equipo los criterios, las hipótesis D11–D12 y los límites anteriores.
- Definir umbrales de estado (RN-XI-07). No se calibraron alertas.
