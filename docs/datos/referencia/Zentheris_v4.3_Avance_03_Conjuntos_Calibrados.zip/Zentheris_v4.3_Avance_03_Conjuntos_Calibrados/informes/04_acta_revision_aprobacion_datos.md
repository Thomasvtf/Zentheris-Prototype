# Acta de revisión y aprobación de datos de `perfiles_simulacion`

- **Proyecto:** Zentheris (SENA), fase de simulación de datos.
- **Versión que se aprueba:** cinco conjuntos finales, versión 1.0, preparados el 29/10/2026.
- **Contrato de referencia:** Reglas de Negocio y Modelo de Datos v4.3 (secciones 5, RN-IV-01, RN-IV-07, RN-X-04).
- **Modelo de referencia:** `zentheris-4.3-ref-1`.
- **Estado de este documento:** **DATOS CERRADOS** por confirmación explícita de Nicolás (responsable del proyecto), registrada en chat el 29/10/2026. Las firmas de revisión técnica y de producto (sección 8) quedan como registro opcional, según lo que el equipo requiera.

## 1. Objeto

Registrar la revisión de los cinco conjuntos de parámetros de simulación que alimentarán la tabla `perfiles_simulacion`, y dejar constancia de qué se verificó, qué limitaciones se aceptan y qué queda pendiente. La aprobación cubre el uso de los conjuntos como **entrada del generador de historial (30 días, 720 horas por zona)** en la fase de backend. No cubre la calibración contra hogares reales, porque no existen datos medidos.

## 2. Archivos aprobados (SHA-256)

| Archivo | SHA-256 |
|---|---|
| `parametros_finales/consumo_compacto.json` | 5b753d74c569ded1be73592bb00089b263ba53029dd9ee4c9baf1c71675ebc12 |
| `parametros_finales/consumo_eficiente.json` | 1b3ee380a4cbf52621830f6f1f27be4b31787e8666babe9735b56dacf8405dcc |
| `parametros_finales/consumo_intermedio.json` | 5bd93608a2c6017097388c2c4b3e51373cf732c8d522cf43dbf5b95d1c3bd1e8 |
| `parametros_finales/consumo_familiar.json` | 2ac80e2772fc62dc55a0e143010d781cbd594c8f6ef8e04a31f839e2f699f452 |
| `parametros_finales/consumo_amplio.json` | 328e44959c38ccc2f9ac9a342b1c1c6734ef0291866d4bb2c878e4bd47cc2ae6 |
| `parametros_finales/consolidado_perfiles_simulacion.json` | 6cfa97152a120edfdfde45921a1382e23025981d4ae1652c5f476e5489a90922 |

Si cualquier archivo cambia, estos códigos dejan de ser válidos y el acta debe rehacerse.

## 3. Qué se verificó

| Verificación | Resultado | Evidencia |
|---|---|---|
| Estructura y tipos del contrato (nombres exactos, NUMERIC, JSONB, rangos) | Cumple | `codigo/validar_parametros.py --cinco`; 59 pruebas de la suite |
| Fórmula del simulador conforme a v4.3: L = T·Q + ΣE; T = B·H·F; n(t) = φ·n(t−1) + σ·ε; w' = máx(0, w·(1+n)); Q = w'/Σw'; E = P·(D/60)·f/1000 | Cumple (revisión línea a línea y pruebas M01–M21) | `codigo/zentheris_sim/simulador.py`; `pruebas/test_modelo.py` |
| Regla de RN-IV-07: zonas ausentes no consumen y su base no se reparte | Cumple | prueba M09 |
| Asignación de personalidad RN-X-04 en las 147 combinaciones válidas | Cumple, con coincidencia con el Avance 01 | prueba K02, K03; `test_conjuntos_finales` F09 |
| Ruido: autocorrelación de una hora a la siguiente frente a φ = 0,6 | Cumple (0,592 a 0,612) | `resultados/validacion_ruido.csv`, criterio CE10 |
| Eventos: frecuencia y energía frente a su esperanza analítica | Cumple (CE06 y CE07 en los cinco conjuntos) | `resultados/validacion_eventos.csv` |
| Calibración contra objetivos congelados (error de la media) | Cumple (−0,16 % a +0,10 %) | `resultados/validacion_resumen.csv`, criterio CE01 |
| Cobertura de realizaciones (100 semillas en ±10 %) | Cumple (100/100 en los cinco) | criterio CE03 |
| Año completo 2025 | Cumple (errores entre −0,68 % y +0,60 %) | `resultados/validacion_anual.csv` |
| Carga, lectura y valores iguales en PostgreSQL local | Cumple (16/16) | `resultados/prueba_postgres_local.csv` |
| Repetibilidad: los JSON se reconstruyen byte a byte desde los insumos | Cumple | `codigo/ejecutar_todo.py` |

**Lo que no se ha verificado:** Supabase, el módulo real del backend, y cualquier comparación con datos medidos de hogares colombianos.

## 4. Limitaciones que el equipo debe aceptar

Estas limitaciones no bloquean la aprobación, pero deben aceptarse por escrito (sección 6).

1. **Eventos pequeños en energía.** Los eventos de sobreconsumo representan entre 0,2 % y 2,9 % del consumo total de cada hogar (2,9 % en amplio). Visualmente aparecen como picos cortos y altos, pero no cambian mucho el total mensual.
2. **Variación mensual baja.** El coeficiente de variación del consumo mensual es de 1 % a 3 %. Los hogares reales suelen variar más. La banda de ±10 % se cumple, pero eso no demuestra realismo de la variabilidad.
3. **Cocina dominante en compacto (≈67 %).** Se conserva por la nevera documentada. Contradice la descripción cualitativa de la tabla 12, que habla de sala y dormitorio.
4. **Factor de fin de semana único por hogar.** Las rutinas que solo ocurren en días laborales (oficina de intermedio y familiar) quedan mal representadas por día: residuos de +1 222 % y +2 341 % en oficina, y −79 % en lavandería de familiar. El total del hogar sí cuadra. Es una limitación de v4.3, no un error de implementación.
5. **Humor y ruido son supuestos.** No hay evidencia empírica directa para φ, σ ni los rangos de humor. Están documentados en `decisiones_adoptadas.md` (D11 y D12).
6. **Eventos sin distinción de día.** Las visitas y los eventos de fin de semana se reparten como los días laborales.
7. **Posible duplicación de equipos** entre zonas en intermedio y amplio (por ejemplo, una lavadora contada en cocina y en lavandería). Se estima en unos 0,12 kWh/día en intermedio.
8. **Semilla con SHA-256.** El contrato v4.3 dice `hash(...)` sin especificar algoritmo. Se usa SHA-256 por ser estable entre ejecuciones (convención A14, registrada en `decisiones_adoptadas.md`). Hay que aceptarlo como precisión del contrato.
9. **Secadora de amplio** con ficha de un equipo extranjero de resistencia; la potencia es la media del ciclo, no la nominal.

## 5. Eventos: qué significan y qué no

Los eventos son **energía adicional** a la base, sorteada dentro de una ventana horaria y con un rango de potencia y duración. Cada personalidad tiene una familia de evento por zona (una sola). La frecuencia y la energía están tomadas de los equipos documentados en el Avance 02. **No son mediciones de hogares reales.** La apariencia de "pico" en las gráficas proviene de estos sorteos.

## 6. Decisiones de aprobación

Marca cada casilla. Si alguna no se acepta, indica la razón en la última columna.

| # | Decisión | Aceptada (sí/no) | Observación |
|---|---|---|---|
| A1 | Los supuestos de humor y ruido (sección 4, puntos 5 y 8) son aceptables para la fase de backend | Sí | Confirmación explícita de Nicolás, 29/10/2026 |
| A2 | Las limitaciones de la sección 4 se aceptan tal como están escritas | Sí | Confirmación explícita de Nicolás, 29/10/2026 |
| A3 | Los eventos de sobreconsumo se aceptan como energía adicional con la frecuencia y la energía del Avance 02 | Sí | Confirmación explícita de Nicolás, 29/10/2026 |
| A4 | Los cinco conjuntos con los SHA-256 de la sección 2 son la versión oficial de `perfiles_simulacion` para el generador de historial | Sí | Confirmación explícita de Nicolás, 29/10/2026 |
| A5 | Cualquier cambio posterior a estos archivos requiere una nueva acta | Sí | Confirmación explícita de Nicolás, 29/10/2026 |

## 7. Condiciones de la aprobación

*Estas condiciones siguen vigentes aunque los datos estén cerrados. No bloquean el cierre, pero no se han resuelto.*

- **Esta aprobación no cierra** la prueba contra Supabase ni contra el módulo real del backend. Quedan como pendientes registrados.
- **Esta aprobación no cierra** los umbrales de alertas (RN-XI-02 y RN-XI-07). Se definen en el desarrollo del backend, junto con el consumo histórico o la meta de cada hogar.
- Si el equipo cambia cualquier supuesto de humor, ruido, eventos o bases, se regeneran los archivos, se repiten las pruebas y se emite una nueva acta.

## 8. Firmas

| Rol | Nombre | Firma | Fecha |
|---|---|---|---|
| Responsable del proyecto | Nicolás | Confirmación explícita por chat (sin firma manuscrita) | 29/10/2026 |
| Revisión técnica | | | |
| Revisión de producto o requisitos | | | |

*Nota: el asistente no firma ni aprueba. La aprobación proviene de la confirmación explícita de Nicolás como responsable del proyecto. Las otras filas quedan en blanco hasta que se firmen.*
