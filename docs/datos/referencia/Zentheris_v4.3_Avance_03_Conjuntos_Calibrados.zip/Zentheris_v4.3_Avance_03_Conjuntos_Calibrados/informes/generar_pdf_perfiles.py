"""Genera informes/03_perfiles_por_personalidad.pdf a partir de los archivos del avance.

Las cifras se leen de parametros_finales/, congelamiento/ y resultados/; no se escriben a mano.
Uso (desde avance_03): python informes/generar_pdf_perfiles.py
"""
import csv
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

RAIZ = Path(__file__).resolve().parents[1]
SALIDA = RAIZ / "informes" / "03_perfiles_por_personalidad.pdf"
FD = Path("/usr/share/fonts/truetype/dejavu")
pdfmetrics.registerFont(TTFont("Sans", FD / "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("Sans-Bold", FD / "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Mono", FD / "DejaVuSansMono.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily  # noqa: E402
registerFontFamily("Sans", normal="Sans", bold="Sans-Bold", italic="Sans", boldItalic="Sans-Bold")

ESTILO = getSampleStyleSheet()
T1 = ParagraphStyle("T1", parent=ESTILO["Title"], fontName="Sans-Bold", fontSize=20, leading=24)
T2 = ParagraphStyle("T2", fontName="Sans-Bold", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6,
                    textColor=colors.HexColor("#1F3A5F"))
T3 = ParagraphStyle("T3", fontName="Sans-Bold", fontSize=10.5, leading=14, spaceBefore=8, spaceAfter=3)
N = ParagraphStyle("N", fontName="Sans", fontSize=9, leading=12.5, alignment=TA_LEFT, spaceAfter=5)
P = ParagraphStyle("P", fontName="Sans", fontSize=8, leading=10.2)
PB = ParagraphStyle("PB", parent=P, fontName="Sans-Bold")
NOTA = ParagraphStyle("NOTA", fontName="Sans", fontSize=7.8, leading=10, textColor=colors.HexColor("#555555"))

NOMBRES = ["Consumo compacto", "Consumo eficiente", "Consumo intermedio", "Consumo familiar", "Consumo amplio"]
ZONAS = ["cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio"]
ETIQUETA = {"cocina": "Cocina", "sala": "Sala", "dormitorio": "Dormitorio", "bano": "Baño", "oficina": "Oficina",
            "lavanderia": "Lavandería", "terraza": "Terraza", "garaje": "Garaje", "cuarto_servicio": "Cuarto de servicio"}

# Texto narrativo: resume tabla 12 de v4.3 y los escenarios del Avance 01 (02_diez_escenarios).
DESCRIPCION = {
    "Consumo compacto": {
        "vivienda": "Apartaestudio de 4 zonas (cocina, sala, dormitorio, baño).",
        "regla": "RN-X-04: apartaestudio con 3 o 4 zonas.",
        "hogar": "Una persona (C1, Teusaquillo) que trabaja fuera de casa de lunes a viernes, llega hacia las 19:00, "
                 "cena en casa tres noches y duerme 23:00–05:45. Fines de semana fuera parte del día.",
        "tipo": "Consumo bajo, concentrado en la noche. Pocos picos y de baja potencia.",
        "servicios": "Nevera pequeña continua, microondas en la noche, TV y portátil de 19:45 a 22:00, router continuo, "
                     "iluminación corta. Lavado externo.",
        "limites": "La cocina pesa ~67 % por la nevera, más que sala y dormitorio (conflicto documentado con tabla 12). "
                   "No representa ausencias de varios días. Oficina y lavandería aparecen en la combinación válida, "
                   "no en la referencia; sus bases vienen de contrastes (C2, E2).",
        "eventos_texto": "Prolongación del TV en sala por visitas.",
    },
    "Consumo eficiente": {
        "vivienda": "Apartamento con las 4 básicas (E1, Engativá); también apartaestudio de 5 zonas y, por respaldo "
                    "de RN-X-04, cualquier hogar sin personalidad activa.",
        "regla": "RN-X-04: apartamento, casa o dúplex sin complementarias ni extras (c = 0, s = 0).",
        "hogar": "Dos adultos que trabajan presencialmente, llegan entre 18:30 y 19:30 y cocinan en casa. "
                 "Cocina a gas, nevera mediana, lavadora fría de tres ciclos semanales.",
        "tipo": "Consumo moderado-bajo con doble pico (mañana y noche). La cocina es la zona de mayor peso. Ruido bajo.",
        "servicios": "Cocina con microondas, arrocera, licuadora y lavado; dos portátiles en dormitorio; TV mediano en sala.",
        "limites": "La cocina pesa ~71 %, por encima de la tabla 12 que habla de sala y dormitorio. La cocina mixta de E2 "
                   "(placa eléctrica) no se usa como referencia. Las nueve zonas se usan solo como respaldo de RN-X-04 "
                   "(sin calibración propia para hogares con extras).",
        "eventos_texto": "Microondas en la noche (recalentado de visitas).",
    },
    "Consumo intermedio": {
        "vivienda": "Apartamento con las 4 básicas y oficina (I1, Suba); casa con lavandería (I2, Soacha) y casa campestre "
                    "con solo básicas, en la tabla 12.",
        "regla": "RN-X-04: apartamento, casa o dúplex con c = 1 y s = 0.",
        "hogar": "Pareja con una hija de 10 años. Una persona trabaja desde casa lunes, miércoles y viernes; la otra "
                 "sale de casa; la niña regresa a las 16:00.",
        "tipo": "Consumo medio, con actividad diurna en la zona adicional (oficina). Picos ocasionales de potencia media.",
        "servicios": "Oficina con portátil y monitor en jornada remota, impresora 10 min/semana y luces; cocina con "
                     "microondas, arrocera, lavadora y plancha; TV y consola en sala.",
        "limites": "Oficina solo en días remotos: el factor de fin de semana no lo representa (CE16: residuo de "
                   "+1 222 % en oficina de I1). Lavadora de I1 y de I2 pueden estar duplicadas en el hogar. La ducha "
                   "eléctrica de I2 no se incluye en la base (queda fuera de la referencia).",
        "eventos_texto": "Microondas en la noche y una prolongación del portátil de oficina por entregas.",
    },
    "Consumo familiar": {
        "vivienda": "Apartamento con 4 básicas, oficina y lavandería (F1, Fontibón); casa con cuarto de servicio (F2, "
                    "Puente Aranda), y casa campestre con una extra.",
        "regla": "RN-X-04: apartamento, casa o dúplex con c ≥ 2 o s = 1; campestre sube un nivel desde intermedio.",
        "hogar": "Dos adultos (uno en remoto) y dos adolescentes. Lavado frío seis ciclos a la semana; freidora de aire "
                 "tres cenas a la semana; TV grande y consola en sala.",
        "tipo": "Consumo alto y sostenido durante el día, con picos en la mañana, la tarde y la noche. Picos más frecuentes.",
        "servicios": "Refrigeración familiar, cocina con microondas y arrocera, oficina con dos portátiles y monitor "
                     "en jornada, lavadora y plancha, TV y consola.",
        "limites": "Oficina y lavandería comparten el mismo factor de fin de semana; en la referencia la oficina baja "
                   "mucho en fin de semana (residuo de +2 341 % frente a la narrativa) y la lavandería de F1 queda "
                   "−79 %. El total del hogar sí cuadra. No distingue calendario escolar ni vacaciones.",
        "eventos_texto": "Freidora de aire en la tarde (visitas).",
    },
    "Consumo amplio": {
        "vivienda": "Dúplex con 4 básicas, lavandería, terraza y garaje (A1, Usaquén); casa campestre con varias extras (A2).",
        "regla": "RN-X-04: apartamento, casa o dúplex con E ≥ 2 y OL; o campestre con dos extras y oficina/lavandería.",
        "hogar": "Cinco residentes: dos adultos, dos jóvenes que estudian fuera y una persona mayor en casa. Horno "
                 "eléctrico dos veces a la semana, freidora, secadora de resistencia dos veces a la semana, lavado frío "
                 "siete ciclos.",
        "tipo": "Consumo más alto, con mayor variación entre días y picos más potentes. El fin de semana se nota con claridad.",
        "servicios": "Cocina con nevera grande, horno, microondas y freidora; sala con TV grande y consola; tres "
                     "portátiles en dormitorio; lavadora, secadora y plancha; luces de terraza y garaje; motor de "
                     "puerta en garaje.",
        "limites": "Factor de fin de semana único (1,15) mientras la razón narrativa de A1 es 2,31; el reparto "
                   "5/2 de horno y secadora (decisión D2) es una aproximación. Secadora con ficha extranjera de "
                   "resistencia; potencia tomada como energía media por ciclo. Fin de semana global.",
        "eventos_texto": "Horno dos veces a la semana, secadora una vez extra al mes, luces de terraza en reuniones.",
    },
}


def leer(ruta):
    with open(ruta, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def f(x, d=2):
    return f"{float(x):,.{d}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def pct(x, d=2):
    return f"{float(x) * 100:+.{d}f} %".replace(".", ",")


def tabla(filas, anchos, cabecera=True, estilo_extra=()):
    data = [[Paragraph(str(c), PB if (cabecera and i == 0) else P) for c in fila] for i, fila in enumerate(filas)]
    t = Table(data, colWidths=anchos, repeatRows=1 if cabecera else 0)
    base = [("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#CCCCCC")),
            ("TOPPADDING", (0, 0), (-1, -1), 2.2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.2),
            ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3)]
    if cabecera:
        base.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E8EEF5")))
    t.setStyle(TableStyle(base + list(estilo_extra)))
    return t


def ventana_legible(txt):
    """'[21,23)' -> '21:00 a 23:00' (inicio incluido, fin excluido)."""
    a, b = txt.strip("[)").split(",")
    return f"{int(float(a)):02d}:00 a {int(float(b)):02d}:00"


def cargar():
    cong = json.loads((RAIZ / "congelamiento" / "congelamiento.json").read_text(encoding="utf-8"))
    perfiles = {n: json.loads((RAIZ / "parametros_finales" / f"consumo_{n.split()[1].lower()}.json")
                              .read_text(encoding="utf-8")) for n in NOMBRES}
    bases = {(r["personalidad"], r["zona"]): r for r in leer(RAIZ / "resultados" / "trazabilidad_bases.csv")}
    eventos = leer(RAIZ / "resultados" / "trazabilidad_eventos.csv")
    resumen = {r["personalidad"]: r for r in leer(RAIZ / "resultados" / "validacion_resumen.csv")}
    zonas = {(r["personalidad"], r["zona"]): r for r in leer(RAIZ / "resultados" / "validacion_zonas.csv")}
    anual = {(r["personalidad"], r["mes"]): r for r in leer(RAIZ / "resultados" / "validacion_anual.csv")}
    return cong, perfiles, bases, eventos, resumen, zonas, anual


def seccion(n, cong, p, bases, eventos, resumen, zonas, anual):
    ref = cong["referencias"][n]
    d = DESCRIPCION[n]
    r = resumen[n]
    hi = [("Referencia", ref["referencia"]), ("Vivienda", d["vivienda"]), ("Zonas del hogar de referencia",
          ", ".join(ETIQUETA[z] for z in ref["zonas"])), ("Regla de asignación", d["regla"])]
    out = [Paragraph(f"{n}", T2)]
    out.append(tabla([[k, v] for k, v in hi], [4.2 * cm, 12.6 * cm], cabecera=False,
                     estilo_extra=[("FONTNAME", (0, 0), (0, -1), "Sans-Bold")]))
    out.append(Paragraph("Hogar de referencia", T3))
    out.append(Paragraph(d["hogar"], N))
    out.append(Paragraph("Tipo de consumo (tabla 12)", T3))
    out.append(Paragraph(d["tipo"], N))
    out.append(Paragraph("Servicios e inventario principal", T3))
    out.append(Paragraph(d["servicios"], N))

    out.append(Paragraph("Parámetros de bases por zona", T3))
    filas = [["Zona", "Base (kWh/día)", "Fuente", "Motivo"]]
    for z in ZONAS:
        b = p[f"base_{z}_kwh_dia"]
        fila = bases.get((n, z), {})
        filas.append([ETIQUETA[z], f"{b:.4f}".replace(".", ","),
                      fila.get("fuente", "") or "—",
                      (fila.get("motivo", "") if b else "No la recibe (RN-X-04)")])
    out.append(tabla(filas, [3.6 * cm, 2.9 * cm, 2.2 * cm, 8.1 * cm]))

    out.append(Paragraph("Parámetros generales", T3))
    gen = [["Parámetro", "Valor", "Significado"],
           ["factor_fin_semana (F)", f(p["factor_fin_semana"], 4), "Multiplica la base en sábado y domingo"],
           ["humor_min / humor_max (H)", f"{p['humor_min']:.2f} / {p['humor_max']:.2f}".replace(".", ","),
            "Variación diaria uniforme del hogar"],
           ["ruido_config.memoria (φ)", f(p["ruido_config"]["memoria"], 2), "Persistencia del ruido horario"],
           ["ruido_config.intensidad (σ)", f(p["ruido_config"]["intensidad"], 2), "Tamaño del empujón horario"],
           ["Razón fin de semana / laboral (referencia)", f(ref["razon_fin_semana_laboral_objetivo"], 4),
            "Razón de la energía regular; el objetivo del modelo"]]
    out.append(tabla(gen, [5.2 * cm, 2.6 * cm, 9.0 * cm]))

    out.append(Paragraph("Eventos de sobreconsumo (picos)", T3))
    ev = [["Zona", "Probabilidad por hora", "Ventana de inicio", "Potencia (W)", "Duración (min)", "Fracción de uso (calibrada)"]]
    for z, cfg in p["picos_config"].items():
        fila_ev = next(e for e in eventos if e["personalidad"] == n and e["zona"] == z)
        ev.append([ETIQUETA[z], f"{cfg['probabilidad']:.4f}".replace(".", ","),
                   ventana_legible(fila_ev["ventana_inicio"]),
                   f"{cfg['potencia_w'][0]:,.0f} – {cfg['potencia_w'][1]:,.0f}".replace(",", "."),
                   f"{cfg['duracion_min'][0]:.0f} – {cfg['duracion_min'][1]:.0f}",
                   f"{cfg['fraccion_uso'][0]:.3f} – {cfg['fraccion_uso'][1]:.3f}".replace(".", ",")])
    out.append(tabla(ev, [3.0 * cm, 2.9 * cm, 3.1 * cm, 2.8 * cm, 2.6 * cm, 2.6 * cm]))
    out.append(Paragraph(f"Eventos: {d['eventos_texto']} Cada evento es energía adicional a la base, no uso habitual. "
                         "La probabilidad es la de que empiece en una hora dentro de la ventana.", NOTA))

    out.append(Paragraph("Curva horaria", T3))
    out.append(Paragraph("Cada zona tiene su propia curva de 24 horas, construida con las ventanas de uso de sus equipos "
                         "(p. ej., dormitorio nocturno, oficina de tarde, cocina en comidas). La curva <i>base</i> del JSON es "
                         "el promedio ponderado del hogar y no se usa como respaldo para ninguna zona del conjunto. Cargas "
                         "continuas (nevera, router, congelador) se reparten en las 24 horas. Los valores numéricos completos "
                         "están en el JSON.", N))

    out.append(Paragraph("Validación con 100 semillas (noviembre de 2026, grupo reservado)", T3))
    val = [["Indicador", "Resultado"],
           ["Objetivo congelado (kWh / 30 días)", f(r["objetivo_kwh"], 2)],
           ["Media simulada (kWh / 30 días)", f(r["media"], 2)],
           ["Error de la media", pct(r["error_rel_media"])],
           ["Desviación estándar / CV", f"{f(r['desv'], 2)} / {f(float(r['cv']) * 100, 1)} %"],
           ["Rango P5 – P95", f"{f(r['p5'], 2)} – {f(r['p95'], 2)}"],
           ["Semillas dentro de ±10 %", f"{r['semillas_en_banda']} de 100 (Wilson 95 %: {f(float(r['wilson_95_bajo']) * 100, 1)} % a 100 %)"]]
    out.append(tabla(val, [6.2 * cm, 10.6 * cm]))
    out.append(Paragraph("Estos resultados son de simulación. Muestran coherencia con los supuestos, no validación con datos "
                         "de hogares reales.", NOTA))

    out.append(Paragraph("Límites conocidos", T3))
    out.append(Paragraph(d["limites"], N))
    return out


def portada(cong):
    return [Spacer(1, 2.2 * cm), Paragraph("Zentheris · Perfiles de consumo por personalidad", T1), Spacer(1, 0.4 * cm),
            Paragraph("Descripción de los cinco perfiles de <i>perfiles_simulacion</i> y de los hogares de referencia "
                      "en los que se basa cada parámetro. Versión 1.0 · 28/10/2026 · Contrato Reglas de Negocio y Modelo "
                      "de Datos v4.3 · Modelo de referencia zentheris-4.3-ref-1.", N),
            Spacer(1, 0.3 * cm),
            Paragraph("<b>Advertencia.</b> Todos los datos son <b>simulados</b>. Los hogares de referencia son descripciones "
                      "narrativas del Avance 01, no hogares medidos. Los horarios, humor, ruido y eventos son supuestos "
                      "de modelado. Las bandas de validación son criterios de ingeniería del prototipo.", N),
            Spacer(1, 0.5 * cm),
            Paragraph("Cómo leer cada perfil", T3),
            Paragraph("1) Qué hogar representa y qué zonas tiene. 2) De dónde sale cada base diaria. 3) Parámetros de "
                      "variación (humor, fin de semana, ruido). 4) Eventos de sobreconsumo. 5) Resultado de validación. "
                      "6) Límites conocidos, sin omitir los que contradicen la descripción cualitativa.", N),
            Spacer(1, 0.3 * cm),
            Paragraph("Resumen comparativo", T3)]


def resumen_comparativo(perfiles, resumen):
    filas = [["Personalidad", "Zonas con base > 0", "Objetivo (kWh/30 d)", "Media simulada", "Error", "Semillas en ±10 %"]]
    for n in NOMBRES:
        p = perfiles[n]
        zs = sum(1 for z in ZONAS if p[f"base_{z}_kwh_dia"] > 0)
        r = resumen[n]
        filas.append([n, str(zs), f(r["objetivo_kwh"], 2), f(r["media"], 2), pct(r["error_rel_media"]),
                      f"{r['semillas_en_banda']} / 100"])
    return [tabla(filas, [3.6 * cm, 2.9 * cm, 3.0 * cm, 2.8 * cm, 2.2 * cm, 2.8 * cm])]


def anexo_metodo():
    return [Paragraph("Anexo · Método y fuentes", T2),
            Paragraph("<b>Bases.</b> Energía regular media por zona del balance del Avance 02, convertida a día base con "
                      "7 / (5 + 2F). <b>Humor.</b> Uniforme entre humor_min y humor_max, un valor por hogar y día. "
                      "<b>Ruido.</b> n(t) = φ·n(t−1) + σ·ε, con ε uniforme en [−1, 1], por zona y hora, reiniciado cada "
                      "día. <b>Eventos.</b> Ocurrencia por hora dentro de la ventana; potencia, duración, minuto y "
                      "fracción uniformes dentro del rango. <b>Semillas.</b> SHA-256 de hogar, fecha, versión, zona y "
                      "dominio del sorteo. <b>Fuentes.</b> Ficha de equipos en el Avance 02 (catálogo_equipos.json) y "
                      "datos del Avance 01 (matriz de evidencia D01–D23). Cada dato está en "
                      "resultados/trazabilidad_*.csv y en decisiones_adoptadas.md.", N),
            Paragraph("Cifras de ejemplo: la energía regular y las bases se redondean a 4 decimales, igual que NUMERIC(10,4).", NOTA)]


def main():
    cong, perfiles, bases, eventos, resumen, zonas, anual = cargar()
    doc = SimpleDocTemplate(str(SALIDA), pagesize=letter, leftMargin=1.9 * cm, rightMargin=1.9 * cm,
                            topMargin=1.7 * cm, bottomMargin=1.7 * cm,
                            title="Zentheris · Perfiles de consumo por personalidad",
                            author="Equipo Zentheris (borrador técnico)")

    def pie(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Sans", 7.5)
        canvas.setFillColor(colors.HexColor("#666666"))
        canvas.drawString(1.9 * cm, 1.0 * cm, "Zentheris · Perfiles por personalidad · Datos simulados")
        canvas.drawRightString(letter[0] - 1.9 * cm, 1.0 * cm, f"Página {doc_.page}")
        canvas.restoreState()

    historia = portada(cong) + resumen_comparativo(perfiles, resumen) + [PageBreak()]
    for i, n in enumerate(NOMBRES):
        historia += seccion(n, cong, perfiles[n], bases, eventos, resumen, zonas, anual)
        if i < len(NOMBRES) - 1:
            historia.append(PageBreak())
    historia += [PageBreak()] + anexo_metodo()
    doc.build(historia, onFirstPage=pie, onLaterPages=pie)
    print("PDF escrito:", SALIDA.name)


if __name__ == "__main__":
    main()
