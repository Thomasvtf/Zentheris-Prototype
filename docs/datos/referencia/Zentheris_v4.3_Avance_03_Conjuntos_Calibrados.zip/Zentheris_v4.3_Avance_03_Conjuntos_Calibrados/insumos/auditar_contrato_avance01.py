"""Auditoría de reglas v4.3. No genera lecturas ni parámetros calibrados.

Ejecutar desde avance_01:
    python codigo/auditar_contrato.py --documento /ruta/Reglas-...-v4.3.md
Sin --documento verifica escenarios y combinaciones, no extrae el diccionario.
Solo biblioteca estándar; salidas en resultados/.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import platform
import re
from collections import Counter
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
BASICAS = frozenset(("cocina", "sala", "dormitorio", "bano"))
COMPLEMENTARIAS = frozenset(("oficina", "lavanderia"))
EXTRAS = frozenset(("terraza", "garaje", "cuarto_servicio"))
ZONAS = ("cocina", "sala", "dormitorio", "bano", "lavanderia",
         "oficina", "terraza", "garaje", "cuarto_servicio")
VIVIENDAS = ("apartaestudio", "apartamento", "casa", "duplex", "casa_campestre")
PERSONALIDADES = tuple("Consumo " + n for n in
                      ("compacto", "eficiente", "intermedio", "familiar", "amplio"))


def asignar(vivienda: str, zonas: list[str] | tuple[str, ...]) -> str:
    """Valida antes de clasificar; rechaza nombres desconocidos y duplicados."""
    if vivienda not in VIVIENDAS:
        raise ValueError("Vivienda desconocida")
    if not isinstance(zonas, (list, tuple)) or any(not isinstance(z, str) for z in zonas):
        raise ValueError("La selección debe ser una lista de nombres")
    conjunto = set(zonas)
    if len(conjunto) != len(zonas) or not conjunto <= set(ZONAS):
        raise ValueError("Zona duplicada o desconocida")
    if vivienda == "apartaestudio":
        if not (3 <= len(conjunto) <= 5 and len(conjunto & BASICAS) >= 3
                and not conjunto & EXTRAS):
            raise ValueError("Selección inválida para apartaestudio")
        return PERSONALIDADES[0 if len(conjunto) <= 4 else 1]
    if not BASICAS <= conjunto:
        raise ValueError("Faltan zonas básicas")
    c = len(conjunto & {"oficina", "lavanderia", "terraza", "garaje"})
    s = "cuarto_servicio" in conjunto
    e = len(conjunto & EXTRAS)
    ol = bool(conjunto & COMPLEMENTARIAS)
    nivel = 4 if e >= 2 and ol else 3 if c >= 2 or s else 2 if c == 1 else 1
    if vivienda == "casa_campestre":
        nivel = min(4, nivel + 1)
    return PERSONALIDADES[nivel]


def resolver_activo(nombre: str, activos: dict[str, bool]) -> str:
    if activos.get(nombre, False):
        return nombre
    if activos.get("Consumo eficiente", False):
        return "Consumo eficiente"
    raise ValueError("No hay personalidad asignada ni respaldo eficiente activo")


def escribir_csv(ruta: Path, filas: list[dict], campos: list[str]) -> None:
    with ruta.open("w", encoding="utf-8", newline="") as f:
        escritor = csv.DictWriter(f, fieldnames=campos)
        escritor.writeheader()
        escritor.writerows(filas)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--documento", type=Path)
    args = parser.parse_args()
    salida = RAIZ / "resultados"
    salida.mkdir(exist_ok=True)
    pruebas = []

    def probar(nombre, condicion, detalle=""):
        pruebas.append({"prueba": nombre, "estado": "aprobado" if condicion else "fallido",
                        "detalle": detalle})
        if not condicion:
            raise AssertionError(nombre + ": " + detalle)

    escenarios = json.loads((RAIZ / "datos/escenarios_identificacion.json").read_text())
    probar("diez_escenarios", len(escenarios) == 10)
    probar("dos_por_personalidad", Counter(e["personalidad"] for e in escenarios)
           == Counter({p: 2 for p in PERSONALIDADES}))
    probar("codigos_unicos", len({e["codigo"] for e in escenarios}) == 10)
    filas = []
    for esc in escenarios:
        calculada = asignar(esc["tipo_vivienda"], esc["zonas"])
        probar("asignacion_" + esc["codigo"], calculada == esc["personalidad"], calculada)
        z = set(esc["zonas"])
        filas.append({"codigo": esc["codigo"], "vivienda": esc["tipo_vivienda"],
                      "zonas": "|".join(esc["zonas"]), "numero_zonas": len(z),
                      "c": len(z & {"oficina", "lavanderia", "terraza", "garaje"}),
                      "s": int("cuarto_servicio" in z), "E": len(z & EXTRAS),
                      "OL": bool(z & COMPLEMENTARIAS), "esperada": esc["personalidad"],
                      "calculada": calculada, "estado": "aprobado"})
    escribir_csv(salida / "revision_asignacion_escenarios.csv", filas, list(filas[0]))

    combinaciones = []
    rechazadas = 0
    for vivienda in VIVIENDAS:
        for mascara in itertools.product((False, True), repeat=len(ZONAS)):
            zs = tuple(z for z, incluir in zip(ZONAS, mascara) if incluir)
            # Oráculo de admisibilidad independiente de la función de asignación.
            admisible = ((3 <= len(zs) <= 5 and sum(z in BASICAS for z in zs) >= 3
                          and all(z not in EXTRAS for z in zs))
                         if vivienda == "apartaestudio" else BASICAS <= set(zs))
            try:
                personalidad = asignar(vivienda, zs)
            except ValueError:
                if admisible:
                    raise AssertionError(f"Se rechazó una selección válida: {vivienda} {zs}")
                rechazadas += 1
            else:
                if not admisible:
                    raise AssertionError(f"Se aceptó una selección inválida: {vivienda} {zs}")
                combinaciones.append({"vivienda": vivienda, "zonas": "|".join(zs),
                                      "cantidad": len(zs), "personalidad": personalidad})
    # Conteo combinatorio independiente: 4*(1+2+1) + (1+2) + 4*2**5.
    probar("enumeracion_completa", len(combinaciones) == 147 and rechazadas == 2413,
           f"{len(combinaciones)} válidas, {rechazadas} inválidas de 2560")
    escribir_csv(salida / "combinaciones_validas.csv", combinaciones, list(combinaciones[0]))

    basicas = list(ZONAS[:4])
    casos = [
        ("apartaestudio", basicas, 0), ("apartaestudio", basicas + ["lavanderia"], 1),
        ("apartamento", basicas, 1), ("apartamento", basicas + ["oficina"], 2),
        ("apartamento", basicas + ["terraza"], 2),
        ("apartamento", basicas + ["oficina", "lavanderia"], 3),
        ("apartamento", basicas + ["terraza", "garaje"], 3),
        ("apartamento", basicas + ["lavanderia", "terraza", "garaje"], 4),
        ("casa", basicas + ["cuarto_servicio"], 3), ("duplex", list(ZONAS), 4),
        ("casa_campestre", basicas, 2), ("casa_campestre", basicas + ["terraza"], 3),
        ("casa_campestre", basicas + ["oficina", "terraza"], 4),
    ]
    for i, (v, z, indice) in enumerate(casos, 1):
        probar(f"ejemplo_documento_{i:02}", asignar(v, z) == PERSONALIDADES[indice])
    for complementaria in COMPLEMENTARIAS:
        probar("compacto_con_" + complementaria,
               asignar("apartaestudio", ["cocina", "dormitorio", "bano", complementaria])
               == PERSONALIDADES[0])
    probar("eficiente_tres_basicas_dos_complementarias",
           asignar("apartaestudio", ["cocina", "dormitorio", "bano", "oficina", "lavanderia"])
           == PERSONALIDADES[1])
    for i, (v, z) in enumerate([
        ("cuarto", basicas), ("apartamento", basicas + ["sala"]),
        ("apartamento", basicas + ["patio"]), ("apartaestudio", basicas + ["garaje"]),
        ("apartaestudio", ["cocina", "bano", "oficina"]), ("casa", []),
    ], 1):
        try:
            asignar(v, z)
        except ValueError:
            probar(f"entrada_invalida_{i}", True)
        else:
            probar(f"entrada_invalida_{i}", False)
    probar("fallback_ausente", resolver_activo("Consumo amplio", {"Consumo eficiente": True})
           == "Consumo eficiente")
    probar("fallback_inactivo", resolver_activo("Consumo amplio",
           {"Consumo amplio": False, "Consumo eficiente": True}) == "Consumo eficiente")
    probar("perfil_activo", resolver_activo("Consumo amplio",
           {"Consumo amplio": True, "Consumo eficiente": True}) == "Consumo amplio")
    try:
        resolver_activo("Consumo amplio", {"Consumo eficiente": False})
    except ValueError:
        probar("fallback_no_disponible", True)
    else:
        probar("fallback_no_disponible", False)

    aplicabilidad = {}
    for p in PERSONALIDADES:
        aplicabilidad[p] = sorted({z for c in combinaciones if c["personalidad"] == p
                                  for z in c["zonas"].split("|")})
    resumen = {"python": platform.python_version(), "selecciones_evaluadas": 2560,
               "validas": len(combinaciones), "invalidas_rechazadas": rechazadas,
               "por_personalidad": dict(Counter(c["personalidad"] for c in combinaciones)),
               "por_vivienda": dict(Counter(c["vivienda"] for c in combinaciones)),
               "zonas_aplicables_asignacion_normal": aplicabilidad,
               "eficiente_fallback": list(ZONAS),
               "alcance": "Auditoría de asignación, no simulación ni calibración"}
    if args.documento:
        documento = args.documento.read_text(encoding="utf-8")
        resumen["sha256_documento"] = hashlib.sha256(args.documento.read_bytes()).hexdigest()
        tabla = None
        campos = []
        for linea in documento.splitlines():
            m = re.match(r"### \*\*(\d+)\. ([^*]+)\*\*", linea)
            if m:
                tabla = m.group(2)
            if linea.startswith("## **Cardenalidades"):
                tabla = None
            if tabla and linea.startswith("| `"):
                celdas = [c.strip() for c in linea.strip("|").split("|")]
                if len(celdas) == 4:
                    campos.append(dict(tabla=tabla, campo=celdas[0], tipo=celdas[1],
                                       restricciones=celdas[2], descripcion=celdas[3]))
        escribir_csv(salida / "diccionario_extraido.csv", campos,
                     ["tabla", "campo", "tipo", "restricciones", "descripcion"])
        probar("dieciocho_tablas_extraidas", len({c["tabla"] for c in campos}) == 18)
        # Normalización estructural no implica calibración energética.
        bloques = re.findall(r"```json\s*(.*?)```", documento, flags=re.S)
        curvas = json.loads(bloques[0])
        resumen["sumas_curvas_ilustrativas_documento"] = {
            k: round(sum(v), 12) for k, v in curvas.items()}
        probar("curvas_ilustrativas_normalizadas",
               all(len(v) == 24 and min(v) >= 0 and abs(sum(v) - 1) <= 1e-10
                   for v in curvas.values()),
               str(resumen["sumas_curvas_ilustrativas_documento"]))
    escribir_csv(salida / "pruebas_auditoria.csv", pruebas, ["prueba", "estado", "detalle"])
    resumen["pruebas_aprobadas"] = len(pruebas)
    (salida / "resumen_auditoria.json").write_text(
        json.dumps(resumen, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(resumen, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
