# Método de los diez balances energéticos

Este segundo avance calcula 186 filas de inventario y 18 usos adicionales para los diez escenarios del avance 01. Se mantienen sus viviendas, zonas, residentes y aparatos; se concretan las duraciones ambiguas como supuestos explícitos, sin generar lecturas ni calibrar perfiles.

## Qué se mide en esta etapa

El resultado es una estimación de energía de un hogar ficticio, no una lectura de un contador. «Mensual» significa aquí equivalente de 30 días a partir del promedio semanal; no significa una factura de un mes calendario particular.

Los archivos `balance_por_equipo.csv` y `balance_por_zona.csv` incluyen energía diaria y de 30 días, baja/central/alta. El segundo conserva por separado consumo habitual, adicionales y total; el anexo Markdown facilita la lectura de los diez desgloses y el CSV mantiene los decimales de cálculo.

Los tres niveles de cada entrada son escenarios de incertidumbre epistémica: desconocimiento del modelo real de aparato, potencia efectiva, carga, tiempo o frecuencia. No son percentiles, no son una distribución uniforme conjunta y no representan la variabilidad aleatoria que tendrá el simulador.

## Fórmulas del balance, distintas del simulador

Para un aparato con potencia nominal:

\[
e_\mathrm{sesion}=\frac{P_\mathrm{W}D_\mathrm{min}f}{60000},\qquad
\bar E_\mathrm{activa,dia}=q\,e_\mathrm{sesion}\frac{u_\mathrm{semana}}7.
\]

`q` es la cantidad de aparatos; `u` es la frecuencia por aparato, salvo una fila expresamente descrita como acumulación de horas. Para el horno y la freidora, `f` es una fracción térmica asumida, no una eficiencia del aparato ni un resultado de laboratorio.

Para equipos con energía documentada por ciclo se usa `q × kWh/ciclo × ciclos/semana ÷ 7`; la duración solo sirve para comprobar ocupación y excluir minutos de espera. No se multiplica otra vez por potencia o por fracción térmica.

Para una nevera con energía diaria se usa directamente `q × kWh/día`. La referencia pequeña consume 0,66 kWh/24 h y la grande consultada publica 30,3 kWh/mes; no se convierten en 24 horas a potencia nominal del compresor ([Haceb 220 L](https://www.haceb.com/nevera-haceb-frost-220-litros-manija-integrada-titanio-9002739/p), [Haceb 404 L](https://www.haceb.com/nevera-haceb-no-frost-404l-manija-integrada-inox-inverter-9003306/p)).

La espera se calcula como:

\[
\bar E_\mathrm{espera,dia}
=q\frac{P_\mathrm{espera}}{1000}
\left(24-\frac{D_\mathrm{min}u_\mathrm{semana}}{420}\right).
\]

Se resta el tiempo activo y se comprueba que no resulte negativo. No se agrega una bolsa genérica de «consumo vampiro» encima de las filas ya contabilizadas.

### Adicionales sin duplicación

Cada adicional apunta al ID de un aparato existente en una zona existente. Su energía es la sesión extra menos la espera que sustituye, si ese estado ya estaba presupuestado:

\[
E_{\mathrm{extra,neta}}=q_e\left(e_\mathrm{sesion}
-P_\mathrm{espera}D/60000\right),\quad
\bar E_{\mathrm{extra,30}}=E_{\mathrm{extra,neta}}\lambda_{30}.
\]

Por ejemplo, en C1 una prolongación de TV de 45 W sustituye una hora de espera supuesta de 0,5 W: el incremento es 0,0445 kWh, no 0,045 más otra hora de espera. Tanto la potencia central de ese TV ficticio como su espera son supuestos del catálogo; no se presentan como medición de un televisor concreto.

`lambda_30` es una frecuencia esperada narrativa, no una probabilidad por hora ni un número de eventos ya sorteados. Los dos planchados mensuales de C2 se cuentan solo como adicionales; las sesiones ordinarias de secadora, lavadora, horno y freidora permanecen en el habitual.

Esta contabilidad neta no cambia la fórmula v4.3. Antes de exportar eventos al simulador deberá fijarse una de dos convenciones equivalentes en expectativa: energía incremental explícita o potencia de aparato íntegra con descuento de la espera sustituida en el balance regular; nunca sumar ambos estados. No se modificará un dato nominal documentado sin conservar su valor y la transformación.

## Investigación reutilizada y dos brechas focalizadas

La matriz de 29 registros del avance 01 se reutiliza íntegramente. Se añadieron dos registros, D22 y D23, sin investigar de nuevo cada personalidad.

| Referencia | Resultado y aplicación | Límite preservado |
|---|---|---|
| D22, secadora Bosch WTE84107EE | 2,27 kWh/carga parcial y 4,13 kWh/completa, 70 y 115 minutos, 2800 W de conexión, 0,10 W apagada ([Bosch](https://media3.bosch-home.com/Documents/specsheet/es-CL/WTE84107EE.pdf)) | Ficha 220–240 V y 50 Hz; dice condensación, no identifica explícitamente calefacción. No es verificación de equipo colombiano |
| D23, placa Sokany SK-5101 | Potencia nominal de 1000 W; se usa en E2 en vez de escoger arbitrariamente una potencia entre 1000 y 1500 W ([Homecenter](https://www.homecenter.com.co/homecenter-co/product/3100313/estufa-electrica-1-puesto-1000w-alta-potencia-sokany-sk-5101/3100313/)) | La ficha dice sin control de temperatura y la descripción menciona termostato; no publica kWh/ciclo. La fracción 0,5–0,9 sigue siendo supuesto |

Para A1/A2, el caso central del secado significa una carga parcial y una completa cada semana. La media de 3,20 kWh por ciclo es una estimación de esa mezcla de cargas, no una interpolación garantizada de consumo para una carga de determinado peso ([Bosch](https://media3.bosch-home.com/Documents/specsheet/es-CL/WTE84107EE.pdf)).

La lavadora conserva 2/14 kWh/ciclo como estimación condicional: la ficha publica 2,0 kWh/mes y el texto normativo consultado define un régimen de 14 ciclos mensuales; no se confirmó la etiqueta particular y por eso se mantiene el rango 0,12–0,30 kWh/ciclo ([Haceb IVY](https://www.haceb.com/lavadora-ivy-14-kilogramos-haceb-digital-negra-9003629/p), [Resolución 40247 de 2020](https://normas.cra.gov.co/gestor/docs/resolucion_minminas_40247_2020.htm)). Esa incertidumbre no se resuelve inventando un dato más preciso.

## Concreciones narrativas que deben revisarse

Estas decisiones son supuestos de balance, no reglas originales ni cambios en las personalidades. Se conservan en cada fila de `inventario_balance.json`.

| Caso | Concreción |
|---|---|
| Rangos de horas ya narrados | Usar extremos y punto medio; si se narró una cifra única, mantenerla salvo sensibilidad explícita |
| C1 microondas | 3/4,5/6 minutos, cuatro usos semanales; iluminación cocina 45/52,5/60 min |
| C2 plancha | Cero habitual; dos sesiones esperadas de diez minutos al mes como adicionales |
| E2 TV | Cuatro noches de 1,5 h más tres horas dominicales: nueve horas semanales |
| E2 portátiles | Por persona: tres noches de una hora más tres horas dominicales |
| E2 lavadora | 2/2,5/3 ciclos semanales; 2,5 es promedio de semanas alternadas, no medio ciclo físico |
| I1 oficina | 24 horas de tres jornadas remotas más dos horas nocturnas laborales; monitor simultáneo, sin duplicar carga del portátil |
| I1 tableta | Una recarga diaria supuesta cubre el uso; no se suma potencia durante uso otra vez |
| F1 oficina | Luces de cuatro horas en cinco jornadas, sin inventar uso remoto de fin de semana |
| F2 dormitorios | Iluminación no precisada: 1/1,5/2 horas por lámpara física |
| A1 tres portátiles | Central de ocho sesiones de dos horas entre los tres equipos, distribuidas como 3+2+2+1 en cuatro noches; rango de seis a doce sesiones totales |
| Lavandería | Iluminación durante los tiempos presupuestados de lavado, planchado y secado, sin solapamiento supuesto; no se añade otra iluminación de zona |
| Espera | TV 0/0,5/1 W es un supuesto nuevo de baja magnitud; microondas, consola, impresora y puerta según catálogo |
| Equipos sin fila de espera | Se supone apagado/desconexión efectiva fuera de uso; esto no demuestra que el equipo real tenga espera nula |
| Gas y servicios externos | Cocción/agua a gas y lavandería fuera del hogar no generan kWh eléctricos domésticos; no se presupone auxiliar eléctrico de gas no inventariado |

Cada referencia nominal reutilizada se mantiene igual entre hogares. Las diferencias energéticas provienen de inventario, tiempos, cantidad y frecuencia, no de asignar artificialmente mayor potencia al mismo aparato por el nombre de la personalidad.

## Incertidumbre y sensibilidad

Los extremos de cada fila se suman para una envolvente conservadora del hogar; se incluyen las cargas adicionales entre cero y su extremo superior. Los extremos simultáneos pueden ser poco plausibles en conjunto, pero no se les atribuye una probabilidad.

`sensibilidad_componentes.csv` cambia una fila habitual a su extremo bajo o alto manteniendo el resto central. Es un diagnóstico determinista de importancia de componentes; no es un Monte Carlo, no incluye correlaciones y no cambia las frecuencias adicionales vinculadas.

Se mantienen las brechas de electrónica antigua, máquina de coser, motor de garaje y potencia eléctrica real de la bomba. La selección favorece referencias menos dependientes de esas brechas, pero no elimina los escenarios de contraste ni oculta su contribución.

## Reparto semanal y límite de F

La columna `fraccion_usos_fds` reparte las sesiones semanales entre cinco días laborales y dos de fin de semana únicamente para analizar el balance. No es una nueva columna de la base ni un calendario que se añadirá al simulador.

Cuando el relato no fija días, el reparto es una hipótesis identificada. El caso principal concentra en fin de semana horno y secadora de A1/A2; la sensibilidad conserva sus ciclos y energías, y cambia solo ese reparto.

Para cualquier fila se verifica:

\[
\bar E_\mathrm{dia}=(5E_\mathrm{laboral}+2E_\mathrm{fds})/7.
\]

La razón agregada `E_fds/E_laboral` se publica como diagnóstico, no como `factor_fin_semana` aprobado. Un solo multiplicador global no puede mantener simultáneamente refrigeración plana, oficina laboral y secado semanal concentrado sin aproximaciones; `limitacion_factor_global.csv` cuantifica los residuos de esa proyección.

## Precisión y alcance de las comprobaciones

Los cálculos usan `Decimal` con 32 dígitos de trabajo para detectar pérdidas y verificar sumas; eso no da 32 dígitos de certeza física. Los informes redondean para lectura y los CSV preservan valores intermedios; aún no se convierten a NUMERIC(10,4) ni a lecturas NUMERIC(12,4).

Las pruebas de esta etapa comprueban estructura de los insumos, conservación, asignación, unidades, rangos, no duplicación y cálculos de referencia. Las pruebas del simulador, las semillas reservadas y PostgreSQL siguen pendientes.
