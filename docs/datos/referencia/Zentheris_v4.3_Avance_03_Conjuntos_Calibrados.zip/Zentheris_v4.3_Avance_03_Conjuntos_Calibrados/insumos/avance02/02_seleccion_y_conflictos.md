# Selección de cinco hogares de referencia y conflictos

Se seleccionan C1, E1, I1, F1 y A1 para desarrollar los cinco conjuntos posteriores. Los otros cinco permanecen como contrastes completos, sin mezclar sus hábitos ni almacenar diez variantes.

## Criterios y puntuación

La compatibilidad con RN-X-04 es una condición de entrada obligatoria, no una puntuación compensable. Los diez escenarios la cumplen y las referencias usan sus propias zonas, nunca la unión de todas las zonas posibles de la personalidad.

La puntuación es una evaluación técnica subjetiva de 1 a 5; no es una probabilidad ni una medida de representatividad estadística. Pesos y puntuaciones quedaron explícitos en `criterios_seleccion.json` antes de calcular los totales; no se premia el orden de consumo.

| Criterio | Peso | Interpretación |
|---|---:|---|
| Evidencia disponible | 25% | Potencia/energía trazable y menor dependencia de equipos sin ficha o transferencia débil |
| Representatividad del prototipo | 25% | Ajuste al propósito residencial y descripción general de la personalidad, no a una población estadística |
| Representabilidad con v4.3 | 25% | Posibilidad de aproximar el hogar con bases, curvas fijas, factor global y eventos por zona |
| Facilidad de calibración | 15% | Menos ambigüedades energéticas importantes y descomposición explicable |
| Diferenciación útil | 10% | Contraste de usos/zonas con los otros hogares de referencia, sin puntuación por kWh |

| Par | Evidencia | Representatividad | Representabilidad | Facilidad | Diferenciación | Total sobre 5 | Selección |
|---|---:|---:|---:|---:|---:|---:|---|
| C1 | 4 | 5 | 4 | 5 | 4 | 4,400 | Referencia |
| C2 | 3,5 | 3 | 3,5 | 4 | 3 | 3,400 | Contraste |
| E1 | 4 | 5 | 4 | 4,5 | 4 | 4,325 | Referencia |
| E2 | 3,5 | 4 | 3,5 | 4 | 4 | 3,750 | Contraste |
| I1 | 3,5 | 5 | 3,5 | 4 | 5 | 4,100 | Referencia |
| I2 | 4 | 4 | 3,5 | 3,5 | 4 | 3,800 | Contraste |
| F1 | 4 | 5 | 3,5 | 4 | 5 | 4,225 | Referencia |
| F2 | 3,5 | 4 | 4 | 3,5 | 3,5 | 3,750 | Contraste |
| A1 | 4 | 4,5 | 4 | 4 | 4,5 | 4,175 | Referencia |
| A2 | 3 | 4 | 3 | 3 | 5 | 3,450 | Contraste |

La representabilidad puntúa una aproximación agregada, no fidelidad exacta por día o encendido. En particular, A1 obtiene 4 y no 5 porque sus días de secado no están fijados en el relato y la concentración semanal exacta no cabe en la fórmula; I1/F1 pierden puntos por actividad laboral de oficina que la curva fija no apaga en fines de semana.

## Referencias seleccionadas

### Consumo compacto: C1

El apartaestudio tiene cocina, sala, dormitorio y baño: cuatro categorías, por lo que RN-X-04 asigna compacto. Su objetivo central propuesto es 34,12 kWh por 30 días equivalentes, formado por 34,05 habituales y 0,07 adicionales.

- **Motivo de selección:** una persona, jornada fuera, pocos aparatos y ausencia de grandes cargas eléctricas térmicas; inventario simple y con una nevera pequeña de referencia.
- **Contraste C2 cubierto parcialmente:** poca cocción eléctrica, refrigeración continua y ocio nocturno; ambos tienen objetivos centrales próximos.
- **Contraste no reproducido fielmente:** C2 tiene dos portátiles en oficina vespertina, no tiene sala y añade planchado ocasional. Sus equipos y sus hábitos no se trasladan a C1 ni se promedian.
- **Conflicto que se conserva:** cocina representa el 66,92% del habitual de C1; sala y dormitorio juntos, 32,67%. No se infla ocio para forzar la frase descriptiva «pesan sobre todo dormitorio y sala» de v4.3.

### Consumo eficiente: E1

El apartamento contiene únicamente las cuatro básicas: `c=0`, `s=0`, por lo que obtiene eficiente. El objetivo central es 57,53 kWh/30 días, con 57,29 habituales y 0,24 adicionales.

- **Motivo de selección:** pareja presencial, cocina cotidiana a gas y cocina como zona principal; el lavado integrado permite probar una configuración válida sin lavandería separada.
- **Evidencia y facilidad:** no depende de una placa cuyo control térmico es incierto; se preserva la advertencia sobre energía por ciclo de lavadora.
- **Contraste E2 cubierto parcialmente:** dos residentes, horarios principalmente fuera y actividad nocturna.
- **Contraste no reproducido fielmente:** placa eléctrica, lavado en zona propia y estudio dominical. E2 consume menos en el caso central (52,90), lo cual no obliga a rechazarlo ni a subirle la potencia.

### Consumo intermedio: I1

El apartamento suma oficina a las cuatro básicas: `c=1`, `s=0`, y recibe intermedio. Su objetivo central es 75,05 kWh/30 días, con 74,74 habituales y 0,32 adicionales; el redondeo individual puede no sumar exactamente la centésima del total.

- **Motivo de selección:** introduce una oficina y actividad diurna, útiles para diferenciar el prototipo, sin añadir calentamiento eléctrico de agua como causa dominante.
- **Criterio explícito:** I2 tiene una referencia nominal clara de ducha y por eso recibe mayor puntuación de evidencia, pero I1 encaja mejor en la referencia diurna prevista y en la progresión de usos del prototipo.
- **Contraste I2 cubierto parcialmente:** presencia diurna, lavado doméstico y diferentes horas de actividad.
- **Contraste no reproducido fielmente:** ducha eléctrica y turnos escalonados; I2 obtiene 96,81 kWh/30 días y no se reduce para acercarlo a I1.

La selección de I1 no elimina la necesidad futura de una base de lavandería para otros hogares intermedios válidos. Tampoco permite trasladar a esa base la energía de la lavadora ya incluida en cocina sin documentar que son configuraciones de aplicación distintas.

### Consumo familiar: F1

El apartamento tiene básicas, oficina y lavandería: `c=2`, sin extras, y recibe familiar. El objetivo central es 109,76 kWh/30 días, con 109,06 habituales y 0,70 adicionales.

- **Motivo de selección:** cuatro residentes, trabajo remoto, estudio, lavado frecuente y cocción repartida entre varios equipos; permite observar simultaneidad entre zonas sin inventar una medición instantánea.
- **Evidencia y facilidad:** no depende de una máquina de coser sin ficha; separar oficina y lavandería facilita la trazabilidad del prototipo.
- **Contraste F2 cubierto parcialmente:** presencia sostenida, preparación de alimentos y múltiples equipos encendidos.
- **Contraste no reproducido fielmente:** cuarto de servicio, costura, lavado integrado a cocina y reparto de cinco residentes. El objetivo de F2 es 89,23 kWh/30 días; su etiqueta familiar no garantiza mayor consumo que cualquier intermedio.

### Consumo amplio: A1

El dúplex tiene básicas, lavandería, terraza y garaje: dos extras y lavandería, por lo que cumple primero la condición de amplio. Su objetivo central es 152,66 kWh/30 días, con 148,33 habituales y 4,32 adicionales.

- **Motivo de selección:** añade secado eléctrico y zonas exteriores/de servicio sin depender de la potencia real de una bomba ni de una referencia comercial de congelador.
- **Evidencia y facilidad:** la secadora mantiene una transferencia extranjera explícita, pero su energía por ciclo está mejor delimitada que el conjunto bomba-congelador de A2.
- **Contraste A2 cubierto parcialmente:** más equipos, presencia diurna y visitas, iluminación exterior y secado.
- **Contraste no reproducido fielmente:** teletrabajo en oficina, bomba, congelador y cuarto de servicio; A2 permanece con 211,07 kWh/30 días, sin recortarlo al objetivo de A1.

No se usa un hogar con nueve zonas para calibrar A1. Oficina y cuarto de servicio siguen siendo aplicables a otros hogares amplios y exigirán parámetros auxiliares antes de los cinco JSON finales, pero no entran en este objetivo.

### Precaución al completar zonas auxiliares

E1 e I1 tienen lavadora en cocina, mientras sus contrastes pueden tenerla en lavandería; los diez balances actuales no duplican ningún aparato. Un único conjunto por personalidad no puede trasladar automáticamente esa carga entre zonas según el inventario físico, porque v4.3 solo conoce vivienda y categorías seleccionadas.

Por eso, completar después las bases de zonas no presentes no consistirá en sumar ciegamente otra lavadora al mismo hogar de referencia ni en redistribuir su cocina. Habrá que documentar el hogar alternativo de aplicación y la aproximación agregada; no se afirmará que el conjunto reproduce exactamente el inventario de E2 o I2, ni se cambiarán tablas para hacerlo.

## Conflictos energéticos y su tratamiento

| Conflicto | Hallazgo | Tratamiento propuesto |
|---|---|---|
| Dominio de cocina en compacto | C1 cocina 66,92% del habitual | Mantener el balance y reportar la discrepancia descriptiva; no imponer cuotas de zona |
| Orden entre escenarios | I2 96,81 > F2 89,23 kWh/30 días | Conservar ambos; asignación por vivienda/zonas no clasifica todos los consumos reales |
| Orden de cinco referencias | 34,12 < 57,53 < 75,05 < 109,76 < 152,66 | Se obtiene en los centrales sin ajustar datos; evaluar nuevamente tras calibrar, sin exigir separación de todas las realizaciones |
| Solapamiento de incertidumbre | Las envolventes de varias personalidades se superponen ampliamente | No recortarlas ni presentarlas como percentiles del futuro simulador |
| Media de Bogotá frente a referencias pequeñas | Las primeras referencias quedan por debajo de la media agregada citada en v4.3 | No elevarlas con un multiplicador arbitrario; población y composición energética no son equivalentes |
| Capacidad temporal | Un F global mueve todas las zonas, aunque oficina, frío y lavandería tengan calendarios distintos | Priorizar balance mensual y forma media; cuantificar la pérdida de fidelidad temporal, sin declarar que desapareció |

La fuente oficial contiene 132,14 y 135,69 kWh/usuario-mes para los estratos 3 y 4 en su tabla 15; son estadísticas agregadas y no una obligación de consumo individual ([UAESP](https://www.uaesp.gov.co/sites/default/files/documentos/version-final-estudio-tecnico-de-referencia-alumbrado-publico-2025-1.pdf?width=800&height=800&iframe=true)). El bajo consumo de C1 se explica por el inventario concreto elegido: agua y cocción a gas, lavado externo y pocos equipos, no por adjudicar hábitos al estrato.

### El fin de semana de amplio no queda cerrado

| Reparto de horno y secadora | A1, razón regular fin de semana/laboral | A2, misma razón | Energía habitual mensual |
|---|---:|---:|---|
| Todas las sesiones en fin de semana | 2,3150 | 1,7791 | Invariable |
| Mitad de sesiones en fin de semana | 1,4356 | 1,2151 | Invariable |
| Reparto proporcional entre cinco y dos días | 1,1500 | 1,0165 | Invariable |

Estos son contrafactuales sobre un detalle no fijado en la narrativa, no tres estilos nuevos ni parámetros a almacenar. La sensibilidad no cambia potencias, cargas, frecuencias semanales, selección ni orden energético.

Si se adopta directamente F=2,315 para A1 y se conserva la energía semanal de cada zona, la lavandería de fin de semana quedaría aproximadamente un 46,73% por debajo de su balance concentrado y la terraza un 68,27% por encima, aunque el total agregado encaje. Esa proyección no es una solución calibrada: muestra por qué no debe exigirse fidelidad simultánea imposible con el modelo actual.

## Recomendación para la revisión

Se propone conservar las cinco referencias y sus balances mensuales, así como una representación horaria promedio del MVP. Antes de calibrar debe quedar aceptado que visitas, días de trabajo remoto y sesiones semanales se aproximan y no se reproducen como calendarios físicos.

Para A1, el intervalo diagnóstico 1,15–2,315 no se propone como rango libre para escoger el F que haga aprobar pruebas. Debe elegirse y documentarse primero un reparto temporal compatible con la narrativa; si se exige reproducir la concentración exacta por zona, esa parte no puede aprobarse con v4.3 sin un cambio de alcance.
