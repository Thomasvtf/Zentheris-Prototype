# Criterios de aceptación propuestos antes de calibrar

Versión de propuesta: 0.1, 2026-10-28. Estos criterios se entregan para revisión antes de generar candidatos calibrados; no son pruebas aprobadas ni nuevas reglas de negocio v4.3.

## Capas de autoridad

| Capa | Contenido | Tratamiento |
|---|---|---|
| Reglas originales | RN-X-02/X-04, fórmula L=TQ+eventos, nueve bases, catálogo, curva base, ruido común, eventos por zona, 720 horas | Invariantes; no se negocian durante el ajuste |
| Convenciones de implementación | Hash estable, serialización, extremos de franjas, inicio de intervalo, reinicio del ruido, fronteras de generación, precisión | Se documentan y versionan; no atribuirlas al texto original si no están fijadas |
| Supuestos energéticos | Inventario, tiempos, duty cycles, cargas, espera y frecuencias de extras | Pueden revisarse con evidencia o una corrección narrativa, con historial y nuevo balance |
| Criterios propuestos aquí | Error de media, cobertura, tolerancias y diagnóstico temporal | Se congelan antes de calibrar; no se relajan después de mirar validación para fabricar aprobación |

No se calibrarán alertas ni se elegirá energía para provocar notificaciones. Los umbrales del motor no forman parte de los balances ni fueron suministrados como código probado.

## Tres rangos que no deben confundirse

- **Envolvente de incertidumbre del balance:** suma de extremos de equipos, uso y adicionales. Es una sensibilidad al desconocimiento de las entradas, no una banda objetivo donde cualquier simulación sea aceptable.
- **Banda de la media simulada:** propuesta de ±3% alrededor del objetivo central, separando regular y adicionales cuando se analicen sus errores.
- **Banda operativa de realizaciones mensuales:** propuesta de ±10% alrededor del objetivo central para al menos 95 de las 100 semillas reservadas. Ese umbral es una decisión de prueba del prototipo, no una cobertura empírica demostrada de hogares.

| Personalidad / referencia válida | Objetivo kWh/30 días equivalentes | Envolvente epistémica | Media propuesta ±3% | Realizaciones propuestas ±10% |
|---|---:|---:|---:|---:|
| Compacto / C1, apartaestudio de cuatro básicas | 34,12 | 25,69–47,36 | 33,09–35,14 | 30,71–37,53 |
| Eficiente / E1, apartamento de cuatro básicas | 57,53 | 43,94–77,86 | 55,81–59,26 | 51,78–63,28 |
| Intermedio / I1, apartamento con oficina | 75,05 | 54,85–106,18 | 72,80–77,31 | 67,55–82,56 |
| Familiar / F1, apartamento con oficina y lavandería | 109,76 | 80,79–152,47 | 106,47–113,05 | 98,79–120,74 |
| Amplio / A1, dúplex con lavandería, terraza y garaje | 152,66 | 109,82–213,03 | 148,08–157,24 | 137,39–167,92 |

Los CSV conservan objetivos sin redondear; esa es la referencia de cálculo de límites. La banda de ±10% es una propuesta independiente de las envolventes amplias: no se usará una envolvente de 109,82–213,03 para ocultar sesgo del modelo amplio respecto de 152,66.

### Ajuste a periodos calendario reales

Un equivalente de 30 días con 5/7 de días laborales no coincide exactamente con cualquier ventana de 30 fechas. Para la validación se propone recalcular la expectativa con los días reales y el reparto temporal que haya quedado explícitamente aceptado:

\[
M(n_l,n_f)=n_lR_l+n_fR_f+(n_l+n_f)\bar E_\mathrm{adicional,dia}.
\]

Los totales de calendario exportados en `objetivos_propuestos.csv` son ilustraciones del reparto principal de este balance. Si se adopta otro reparto semanal antes de calibrar, deben regenerarse esas expectativas sin cambiar el objetivo equivalente ni usar el resultado de semillas para elegirlas.

El recorte de un evento en la frontera derecha del backfill se calculará aparte y se reportará como energía descartada; no se considerará incumplimiento de conservación si coincide exactamente con el solapamiento fuera de la ventana. Para agregados estadísticos se comparará con la expectativa del mismo modo de generación, no con una energía de evento íntegra que nunca se almacenó.

## Criterios técnicos y matemáticos

| ID | Criterio propuesto | Umbral o resultado exigido | Naturaleza |
|---|---|---|---|
| CT01 | Cinco conjuntos y nombres exactos; nueve bases; sin metadatos nuevos en tablas | Cinco conjuntos, campos válidos y ninguna colisión | Regla original + encargo |
| CT02 | JSON y tipos | Rechazar claves desconocidas/duplicadas, NaN, infinito, rangos inversos y booleanos como números | Convención de validación |
| CT03 | Curvas | 24 pesos finitos >=0; base obligatoria; suma con error absoluto <=10^-10 | Regla original; tolerancia propuesta |
| CT04 | Ruido | 0<=memoria<1; intensidad>=0; configuración común y sorteos independientes | Regla original |
| CT05 | Riesgo de renormalización nula | Detectar denominador no positivo; candidatos con sigma/(1-phi)<1 como margen conservador | Convención, no restricción nueva atribuida al documento |
| CT06 | Conservación regular | \|suma diaria−T\| <=10^-10×max(1,T), antes de almacenamiento | Regla original; tolerancia propuesta |
| CT07 | Energía de eventos | Comparar cálculo cerrado y solapamientos con error <=10^-10 kWh por evento | Regla original; tolerancia propuesta |
| CT08 | Horas, medianoche y fronteras | Casos conocidos de cruce de hora/día, backfill, recuperación y continuación sin perder ni duplicar la parte válida | Contrato + convenciones explícitas |
| CT09 | Ausencia de zonas | Cero filas para zonas ausentes; sin redistribución y sin alterar las series de zonas conservadas | Regla original |
| CT10 | Reproducción | Misma entrada/configuración/versión produce igualdad; probar procesos con distinta PYTHONHASHSEED | Regla original + mecanismo propuesto |
| CT11 | Recuperación/idempotencia | Rellenar faltantes; segunda ejecución no agrega duplicados ni reescribe lecturas existentes | Regla original + encargo |
| CT12 | Redondeo NUMERIC(12,4) | Error <=0,00005 kWh por lectura; cota total <=N×0,00005; para 720 lecturas/zona, <=0,036 kWh | Convención aritmética compatible |
| CT13 | Asignación/cobertura | Las 147 combinaciones válidas, inválidas rechazadas, fallback y parámetros para cada zona aplicable | Regla original + encargo |
| CT14 | Identidad/persistencia | Preservar UUID existentes, created_at y referencias; actualizaciones no destructivas | Encargo |

La tolerancia de la prueba de balance con `Decimal` de este avance (10^-25 por componente y 10^-23 por sumas grandes) solo verifica el cálculo de investigación. No se exige esa precisión a un futuro simulador en coma flotante ni a PostgreSQL con cuatro decimales.

## Criterios energéticos y estadísticos

| ID | Criterio propuesto | Evaluación y aceptación |
|---|---|---|
| CE01 | Media total del hogar de referencia | Error relativo <=3% frente a objetivo de la ventana exacta |
| CE02 | Energía habitual por zona | Media mensual por zona dentro de max(5% del objetivo regular de zona, 0,02 kWh), antes de redondeo; no compensar una zona errónea con otra |
| CE03 | Cobertura mensual | Al menos 95/100 semillas dentro de banda ±10%; publicar además proporción, intervalo Wilson, mínimo/máximo y percentiles |
| CE04 | Distribución | Media, mediana, desviación estándar, CV, P5/P25/P75/P95; no inventar una distribución empírica ni imponer percentiles provenientes del balance bajo/alto |
| CE05 | Regular vs adicional | Trazabilidad separada y suma exacta; ninguna rutina habitual duplicada como evento |
| CE06 | Frecuencia de eventos | Para probabilidades no degeneradas, comparar conteos con suma de probabilidades efectivas; diagnóstico \|N−mu\| <=4×sqrt(suma p(1−p))+1 en muestra conjunta. Probabilidad 0 y 1 deben cumplir exactamente sus casos deterministas |
| CE07 | Energía adicional | Comparar con expectativa analítica del mismo muestreo/recorte; tolerancia propuesta max(5% de expectativa, 4 errores estándar Monte Carlo) |
| CE08 | Forma horaria sin ruido | Todas las curvas salen del balance y ventanas de uso; como criterio de diseño, >=80% de energía activa no continua en sus ventanas narrativas o una excepción justificada antes de ajustar |
| CE09 | Cargas continuas | No apagar refrigeración/router fuera de presencia; usar componente repartida durante 24h, no potencia nominal constante ni curva nocturna artificial |
| CE10 | Ruido horario | Renormalización conserva total; evaluar autocorrelación de innovaciones/ruido y distribución Q, sin exigir independencia de lecturas que comparten H |
| CE11 | Orden entre referencias | Orden de objetivos y medias compacta<eficiente<intermedia<familiar<amplia; si se rompe, informar causa, no cambiar datos documentados para recuperarlo |
| CE12 | Contrastes y solapamientos | No exigir que los conjuntos reproduzcan los dos hogares de cada par ni separación absoluta entre realizaciones |
| CE13 | Sensibilidad | Bases, humor, F, memoria, intensidad, probabilidad, P/D/fracción y supuestos dominantes; publicar cambios, no elegir solo la semilla favorable |
| CE14 | Año completo | 365 días por personalidad; comparar con expectativa por calendario, analizar deriva, fin de semana, zonas y extremos |

CE08 aplica a la energía activa no continua de cada zona, no al total del hogar: la nevera y el router impiden exigir que casi toda la energía de C1 ocurra de noche. Antes de calibrar se deberán materializar esas ventanas en una matriz de trazabilidad; no se propone aquí un vector de 24 pesos ni se certifica una curva inexistente.

### Criterio temporal condicionado

La exigencia de conservar simultáneamente el patrón laboral/fin de semana de cada zona sería incompatible con un F común en I1, F1 y A1. Se propone separar el ajuste agregado de la fidelidad física por zona, conservando ambas evaluaciones visibles.

| ID | Criterio | Propuesta y condición |
|---|---|---|
| CE15 | Razón regular agregada fin de semana/laboral | Una vez elegido el reparto narrativo, error de media <=5% de su razón objetivo; F no se usa para compensar errores del balance mensual |
| CE16 | Razón por zona | Reportar el residuo absoluto y relativo, incluso si el total pasa; no hay una tolerancia universal defendible que certifique todas las zonas con v4.3 |
| CE17 | Casos con rutina rígida | Si se exige oficina inactiva en fin de semana o secadora exclusivamente ciertos días, marcar fidelidad exacta como pendiente/incompatible, no como aprobada |

Para A1 queda por decidir el reparto temporal dentro de la incertidumbre demostrada, antes de fijar CE15. Se recomienda aceptar una referencia promedio sin calendario exacto; si el objetivo exige reproducir literalmente los días de uso, es un bloqueo de capacidad del modelo, no un valor que deba «calibrarse» artificialmente.

## Semillas, periodos y cobertura previstos

Estos periodos y grupos se reservan desde ahora, pero no se han ejecutado. Los identificadores de prueba se derivarán de nombres deterministas distintos por grupo y personalidad, sin introducir una variación persistente adicional del hogar.

| Grupo | Tamaño propuesto | Periodo | Uso |
|---|---:|---|---|
| Calibración | 50 semillas por personalidad | 2026-09-01 a 2026-10-01, fin excluido | Ajustar candidatos; 22 días laborales y 8 de fin de semana |
| Validación reservada | 100 semillas por conjunto final | 2026-11-01 a 2026-12-01, fin excluido | Aceptación; 21 laborales y 9 de fin de semana; no retocar sobre este grupo |
| Validación anual | Una semilla adicional por personalidad | 2025-01-01 a 2026-01-01 | 365 días: 261 laborales y 104 de fin de semana |
| Otras combinaciones | Al menos tres hogares distintos por personalidad | 30 días por caso; 20 semillas por caso como propuesta ampliada | Referencia, tamaño extremo y combinación de zonas alternativa; cobertura estructural de todas las 147 |

Los nombres de semillas se reservarán como `cal-000` a `cal-049`, `val-000` a `val-099` y `anual-val`, incorporando personalidad y convirtiéndolos en hogar_id de prueba estable. La semilla efectiva seguirá derivándose de hogar_id, fecha y versión según el contrato; las etiquetas de la suite no se añadirán a tablas.

Si falla la validación reservada y se ajusta el conjunto, ese grupo deja de ser ciego para esa versión. Debe registrarse la reutilización como desarrollo y reservarse un nuevo grupo de confirmación, no presentar una segunda ejecución ajustada sobre el mismo grupo como validación independiente.

## PostgreSQL, Supabase y cierre posterior

La futura integración local deberá cubrir archivo → validación → carga no destructiva → lectura desde PostgreSQL → simulador → lecturas → consulta. Debe comprobar exactamente 720 lecturas por zona en backfill, calidad simulada, zona horaria America/Bogota, referencias, unicidad y precisión.

PostgreSQL local, módulo real y Supabase se reportarán como capas diferentes. En este bloque no se cargaron datos ni se ejecutó ninguna de esas integraciones; si una capa sigue sin acceso autorizado, su estado seguirá pendiente aunque las demás aprueben.

## Qué se debe congelar después de revisar esta propuesta

Antes de calibrar deben congelarse los cinco hogares y sus balances, la interpretación de mes equivalente frente a calendario, el reparto temporal adoptado, la contabilidad de espera/eventos, los criterios anteriores y las convenciones de implementación. La aprobación de un criterio agregado no debe borrar los límites declarados por zona ni convertir una simulación académica en una representación validada de hogares reales.
