# Zentheris v4.3: contrato técnico y requisitos verificables

Fecha de revisión: 2026-10-28, America/Bogota. Fuente principal: documento adjunto `Reglas-de-Negocio-y-Modelo-de-Datos-Zentheris-v4.3.md`, leído íntegramente, secciones 1 a 10. Este archivo es una revisión del contrato, no una migración ni una certificación de integración.

## Alcance del primer avance

Este hito comprende revisión documental, diez escenarios, revisión de coherencia e investigación energética compartida. La traducción completa a parámetros, selección definitiva, calibración, simulación estadística y pruebas PostgreSQL se realizarán después de entregar este avance.

Los escenarios son ficticios y no se almacenarán como diez personalidades. El producto final tendrá exactamente cinco filas lógicas de parámetros; las lecturas generadas son resultados separados, no campos del perfil.

## Contrato invariable

- **Personalidades:** `Consumo compacto`, `Consumo eficiente`, `Consumo intermedio`, `Consumo familiar`, `Consumo amplio`.
- **Viviendas:** `apartamento`, `casa`, `apartaestudio`, `duplex`, `casa_campestre`.
- **Zonas básicas:** `cocina`, `sala`, `dormitorio`, `bano`.
- **Zonas complementarias:** `oficina`, `lavanderia`.
- **Zonas extras:** `terraza`, `garaje`, `cuarto_servicio`.
- **Residencia y cuentas:** habitantes físicos no equivalen a miembros activos de la aplicación. El máximo de cinco se refiere a cuentas activas, no a residentes.
- **Asignación:** únicamente vivienda y selección de zonas intervienen en RN-X-04. Ciudad, estrato, edad, residentes y teletrabajo contextualizan la investigación; no se agregan a la regla del MVP.
- **Infraestructura:** una fuente principal por hogar y un sensor por zona; solo se generan lecturas para zonas presentes. No existe una lectura adicional del total del hogar.
- **Alcance:** sin hardware, IA predictiva, frontend ni cambios de tablas.

### Validación de vivienda y zonas

Un apartaestudio selecciona entre tres y cinco categorías, al menos tres básicas, sin extras. Puede tener oficina o lavandería y conservar la personalidad compacta si el total es tres o cuatro; con cinco obtiene eficiente, incluso con tres básicas más ambas complementarias.

Las otras cuatro viviendas requieren las cuatro básicas y admiten cualquier subconjunto de las otras cinco categorías. «Sin máximo» no significa categorías ilimitadas: el catálogo cerrado y la selección única limitan el total a nueve.

Para apartamento, casa y dúplex se calcula `c = |{oficina, lavanderia, terraza, garaje} ∩ zonas|`, `s = 1[cuarto_servicio ∈ zonas]`, `E = |{terraza, garaje, cuarto_servicio} ∩ zonas|`, `OL = bool({oficina, lavanderia} ∩ zonas)`. Gana la primera condición: `E >= 2 and OL` → amplio; `c >= 2 or s == 1` → familiar; `c == 1 and s == 0` → intermedio; en otro caso eficiente.

Casa campestre se evalúa como casa y sube un nivel, con tope amplio. Si falta o está inactivo el perfil resultante se usa eficiente; si tampoco existe un eficiente activo, se debe informar error de configuración y no inventar un sexto perfil.

## Campos exactos de perfiles_simulacion

| Campo | Tipo PostgreSQL | Contrato |
|---|---|---|
| `id` | UUID | Clave primaria; preservar el ID existente |
| `nombre` | TEXT | NOT NULL, UNIQUE; uno de los cinco nombres exactos |
| `activo` | BOOLEAN | Default true; se explicitará true en los conjuntos finales |
| `base_cocina_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_sala_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_dormitorio_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_bano_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_lavanderia_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_oficina_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_terraza_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_garaje_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `base_cuarto_servicio_kwh_dia` | NUMERIC(10,4) | NOT NULL, >= 0 |
| `curva_horaria` | JSONB | NOT NULL; `base` obligatoria y hasta nueve claves de zona |
| `humor_min` | NUMERIC(6,4) | NOT NULL; límite inferior del factor uniforme |
| `humor_max` | NUMERIC(6,4) | NOT NULL; >= humor_min |
| `ruido_config` | JSONB | NOT NULL; solo `memoria`, `intensidad` |
| `picos_config` | JSONB | NOT NULL; cero a nueve claves de zona |
| `factor_fin_semana` | NUMERIC(6,4) | NOT NULL; > 0 |
| `created_at` | TIMESTAMPTZ | Convención global de las tablas propias |
| `updated_at` | TIMESTAMPTZ | Convención global de las tablas propias |

La tabla agrupa visualmente `humor_min / humor_max`, pero son dos columnas. La convención global agrega los dos timestamps aunque no se repitan en la tabla 12; no se presupone un default SQL no documentado.

Las bases admiten hasta cuatro decimales y valor máximo representable 999999.9999; NUMERIC(6,4) admite hasta 99.9999. Estos máximos de representación no son valores energéticos recomendados.

### Claves JSON exactas

| Ruta | Tipo y unidades | Comprobación |
|---|---|---|
| `curva_horaria.base` | Lista de 24 números, sin unidad | Obligatoria, finitos, >= 0, suma 1 |
| `curva_horaria.<zona>` | Lista de 24 números, sin unidad | Opcional; misma validez; solo catálogo |
| `ruido_config.memoria` | Número, sin unidad | 0 <= valor < 1 |
| `ruido_config.intensidad` | Número, sin unidad | >= 0 |
| `picos_config.<zona>.probabilidad` | Número, probabilidad por hora | 0 a 1, también tras aplicar franja |
| `picos_config.<zona>.franjas` | Lista de objetos | Cada objeto contiene `desde`, `hasta`, `multiplicador` |
| `...franjas[].desde` | Hora entera | Convención conservadora 0 a 23 |
| `...franjas[].hasta` | Hora entera | Convención conservadora 1 a 24, límite excluido |
| `...franjas[].multiplicador` | Factor, sin unidad | >= 0 y probabilidad efectiva <= 1 |
| `picos_config.<zona>.potencia_w` | [mínimo, máximo], W | Finitos, >= 0, ordenados |
| `picos_config.<zona>.duracion_min` | [mínimo, máximo], minutos | Finitos, > 0, ordenados |
| `picos_config.<zona>.minuto_inicio` | [mínimo, máximo], minutos | Enteros de 0 a 59, ordenados |
| `picos_config.<zona>.fraccion_uso` | [mínimo, máximo], sin unidad | 0 a 1, ordenados |

No se permiten `default`, `memoria` por zona, claves explicativas dentro de los JSON ni columnas de fuentes. Una zona sin curva propia usa `base`; una zona sin entrada de eventos no genera eventos.

## Modelo matemático y unidades

\[
T_{z,d}=B_z H_d F_d,\qquad H_d \sim U(humor\_min,humor\_max)
\]
\[
n_{z,d,t}=\phi n_{z,d,t-1}+\sigma\epsilon_{z,d,t},\qquad \epsilon\sim U(-1,1)
\]
\[
w'_{z,d,t}=\max(0,w_{z,t}(1+n_{z,d,t})),\quad Q_{z,d,t}=\frac{w'_{z,d,t}}{\sum_{j=0}^{23}w'_{z,d,j}}
\]
\[
L_{z,d,t}=T_{z,d}Q_{z,d,t}+\sum_e E_{e,t},\qquad
E_{e,t}=\frac{P_e}{1000}\frac{m_{e,t}}{60}f_e
\]

`H` se sortea una vez por hogar y fecha; `F` es el mismo factor para todas sus zonas sábado y domingo, y 1 los otros días. `m` son los minutos de solapamiento del evento con la hora; no toda la duración si el evento cruza una hora.

La renormalización conserva el total regular; no puede usarse el ruido para corregir un objetivo mensual. En una ventana de horas completas, kWh por hora y kW promedio son numéricamente iguales, pero la magnitud almacenada es energía.

### Persistencia y relaciones relevantes

`hogares.perfil_simulacion_id → perfiles_simulacion.id`; `zonas.hogar_id → hogares.id`; `sensores_zona.zona_id → zonas.id`; `sensores_zona.fuente_principal_id → fuentes_principales.id`; `lecturas.sensor_id → sensores_zona.id`.

`lecturas` contiene `id UUID`, `sensor_id UUID`, `fecha_hora TIMESTAMPTZ NOT NULL`, `consumo_kwh NUMERIC(12,4) NOT NULL >= 0`, `calidad TEXT` en `simulada/estimada/real` y los timestamps comunes. La pareja `(sensor_id, fecha_hora)` es única; se preserva al reintentar y no se borran lecturas para volver a insertarlas.

`zonas.estado` usa `activa/inactiva`, `fuentes_principales.estado` usa `activa/inactiva` y `sensores_zona.estado` usa `activo/pausado`. Es importante no intercambiar esos catálogos.

Las 18 tablas son `auth.users`, `usuarios`, `preferencias_usuario`, `hogares`, `perfil_transicion`, `hogar_miembros`, `invitaciones_hogar`, `zonas`, `fuentes_principales`, `sensores_zona`, `lecturas`, `perfiles_simulacion`, `tarifas_hogar`, `metas_consumo`, `alertas`, `alertas_usuario`, `consejos`, `consejos_usuario`. La extracción mecánica del diccionario adjunto se conserva como CSV para evitar transcribir de memoria las columnas ajenas al simulador.

## Ambigüedades, contradicciones y decisiones conservadoras

Las siguientes decisiones de ejecución no cambian fórmulas, tablas ni asignación. Son convenciones explícitas para la implementación de referencia; el módulo real deberá adoptar las mismas o registrar sus diferencias antes de declarar equivalencia.

| ID | Hallazgo | Tratamiento y efecto |
|---|---|---|
| A01 | RN-IV-03 y objetivo de tabla 11 hablan de potencia/kW; columna y fórmula dicen kWh | Guardar energía en `consumo_kwh`; derivar kW promedio dividiendo por 1 h. No renombrar columna |
| A02 | «Todas las zonas que contempla» puede ser la unión de zonas válidas y esa unión no conserva personalidad | Objetivos sobre un hogar de referencia válido, no sobre la unión imposible. Probar cobertura por separado |
| A03 | Compacto describe gran peso de sala/dormitorio, pero nevera puede dominar el balance | Investigar inventario antes de imponer participación; reportar conflicto si persiste. No inflar ocio ni reducir refrigeración artificialmente |
| A04 | Curvas ilustrativas pueden confundirse con parámetros finales | La auditoría confirma 24 pesos no negativos y suma 1 en ambas listas; esa validez estructural no demuestra calibración |
| A05 | No define si `hasta` en franjas se incluye ni cómo combinar solapamientos | Usar intervalos [desde,hasta), sin solapamientos; dividir una franja nocturna en dos. No saturar probabilidades inválidas |
| A06 | No especifica distribuciones de los rangos de evento | Uniforme continua para potencia, duración y fracción; uniforme discreta inclusiva para minuto. Declararlo como supuesto, no hallazgo empírico |
| A07 | Reinicio de ruido a las 00:00 y sorteo en cada hora | Inicializar estado previo a la primera actualización en cero (`n[-1]=0`); calcular también la hora 0 con su innovación. Convención explícita a contrastar con código real |
| A08 | Denominador de Q podría ser cero con ruido extremo | No alterar fórmula: detectar y rechazar la realización degenerada; escoger candidatos con `sigma/(1-phi)<1` para evitarla. Ese margen es criterio de diseño, no límite textual nuevo del contrato |
| A09 | Backfill descarta cola derecha; generación incremental debe recuperarla | Backfill exporta solo sus 720 horas. Al continuar, reconstruir eventos anteriores con semillas estables y sumar solo su solapamiento nuevo; no modificar filas del backfill |
| A10 | Cola izquierda del backfill no está definida | Ventana inicial cerrada por la izquierda: no incorporar eventos iniciados antes del comienzo del historial. Generación incremental sí reconstruye colas de horas históricas; registrar frontera del historial en contexto de ejecución, sin columna nueva |
| A11 | Un día completo es necesario para normalizar Q aunque la consulta sea parcial | Calcular internamente las 24 horas del día y recortar la exportación; no normalizar solo las horas solicitadas |
| A12 | Fecha de lectura no distingue inicio o fin de intervalo | Etiquetar por inicio `[fecha_hora, fecha_hora+1h)`; solo escribir intervalos terminados. Timezone lógica America/Bogota |
| A13 | Recuperación «desde última lectura» no cubre agujeros internos | Además de continuar, comprobar horas faltantes dentro del intervalo solicitado por sensor. Insertar faltantes sin sobrescribir existentes |
| A14 | `hash` no especifica algoritmo | Derivación estable SHA-256 con serialización canónica, hogar, fecha, versión, zona y dominio del sorteo. No usar `hash()` de Python |
| A15 | Cambiar parámetros manteniendo versión rompe reproducción histórica | Versionar configuración en manifiesto y constante del código; cargar sin reescribir lecturas. Registrar hashes de archivos y no afirmar reproducción solo por UUID |
| A16 | Condición «todo pico corresponde a evento» frente a picos por curva/ruido y definición de Historial | Trazar toda energía ADICIONAL a un evento; no afirmar que todo máximo horario observado requiere evento |
| A17 | Sección 8 dice configuración en backend, mientras tabla 12 almacena parámetros | Parámetros de personalidad en tabla 12; umbrales globales en configuración del backend. Copia JSON como archivo de carga, no segundo origen divergente |
| A18 | Diagrama cardinalidad hogar/fuente dice 1:N, tabla 9 exige única | Aplicar restricción específica de una fuente por hogar del MVP |
| A19 | Respaldo eficiente puede recibir hogares con extras no válidas para su asignación ordinaria | Separar cobertura normal y fallback. Preparar bases auxiliares de eficiente para las nueve zonas si se ejercita fallback; no calibrar su hogar normal con esas extras |
| A20 | Eficiente de respaldo también podría faltar | Error controlado de configuración; cinco activos como precondición del sembrado normal |
| A21 | SQL completo, defaults, triggers y RLS no están adjuntos | No afirmar que el esquema está creado; DDL de prueba será aislado y trazable. Supabase y esquema real quedan pendientes |
| A22 | Precisión de cuatro decimales cambia sumas exactas | Conservación exacta antes de almacenar; tras redondeo a 4 decimales, error <= 0.00005 kWh por lectura. No corregir residuos alterando arbitrariamente una hora |
| A23 | RN-VI-02/04 y RN-XIV-06 difieren sobre entrega frente a visibilidad de notificaciones | Registrar conflicto fuera del motor de consumo; no diseñar entrega de alertas en este hito |
| A24 | Sección 8 permite ajustar umbrales de asignación después de calibración | Esta tarea prohíbe cambiar RN-X-04: mantenerlos fijos. Cualquier cambio requeriría nueva aprobación |
| A25 | Descripción abreviada de amplio campestre no menciona todas las combinaciones | Priorizar algoritmo de RN-X-04 sobre descripciones resumidas |
| A26 | No especifica selección de aparatos dentro de una zona | Un único tipo agregado de evento por zona. No mezclar potencias/duraciones de equipos incompatibles como si hubiera un catálogo oculto |
| A27 | Ruido no garantiza causalidad de hábitos ni ciclos discretos | Representación horaria agregada; no afirmar recuperación de encendidos individuales a partir de una curva |

No hay bloqueo para crear escenarios e investigar. Las fronteras temporales y la equivalencia con un ejecutor real requieren pruebas dedicadas en la siguiente etapa; las convenciones anteriores deberán aparecer en su README.

### Contexto anterior que no prevalece

La wiki conserva referencias a v4.1, curvas escritas como `curvahoraria`, datos manuales y propuestas no aprobadas de compacto. En este trabajo prevalecen `curva_horaria`, nueve zonas, asignación determinista, eventos por zona y ausencia de entrada manual, conforme al adjunto v4.3; no se rescatan números de propuestas anteriores.

## Matriz de requisitos verificables

`H1` significa primer avance; `H2` implementación y calibración; `H3` integración y cierre. Una prueba planificada no equivale a una prueba aprobada.

| ID | Regla/origen | Verificación y evidencia exigida | Hito |
|---|---|---|---|
| R01 | RN-II-05, III-02 | Catálogos exactos de 5 viviendas y 9 zonas | H1 |
| R02 | RN-X-02/09 | Enumerar las 512 selecciones por cada vivienda; rechazar inválidas | H1 |
| R03 | RN-X-04 | Calcular personalidad y orden de condiciones; ejemplos de tabla 12 | H1 |
| R04 | RN-X-04 | Campestre sube un nivel y tope amplio | H1 |
| R05 | RN-X-04 | Fallback eficiente y fallo si fallback tampoco activo | H1/H2 |
| R06 | Encargo | Diez escenarios, exactamente dos por personalidad | H1 |
| R07 | Encargo | Identificación, horarios, servicios, inventario, excepciones, espacios integrados | H1 |
| R08 | RN-II-02 | Distinguir habitantes y miembros activos | H1 |
| R09 | RN-III-01 | Equipo único por zona; dormitorios físicos agregados | H1 |
| R10 | Encargo | Investigación reutilizada; unidades, fechas, URLs, incertidumbre y clase de dato | H1 |
| R11 | Encargo | Diez balances previos a selección definitiva | H2 |
| R12 | Encargo | Comparación de candidatos sin promediar hábitos incompatibles | H2 |
| R13 | Tabla 12 | Cinco JSON finales, nombres e IDs únicos, campos exactos | H2 |
| R14 | Tabla 12 | Nueve bases no negativas, escala de cuatro decimales y límites NUMERIC | H2 |
| R15 | Sección 5 | Curva base obligatoria; todas las curvas de 24 pesos finitos >=0 | H2 |
| R16 | Sección 5 | Suma de cada curva 1 con tolerancia absoluta declarada 1e-10 | H2 |
| R17 | Sección 5 | Ruido solo memoria/intensidad; phi en [0,1), sigma >=0 | H2 |
| R18 | Sección 5 | Rango de humor ordenado y no negativo; F positivo | H2 |
| R19 | Sección 5 | Probabilidades por hora efectivas en [0,1], franjas válidas | H2 |
| R20 | Sección 5 | Rangos de potencia/duración/minuto/fracción ordenados y finitos | H2 |
| R21 | Encargo | Rechazar NaN, infinito, bool usado como número, claves desconocidas y duplicadas | H2 |
| R22 | Validez 1 | Todas las lecturas finitas y >=0 | H2 |
| R23 | Validez 2/3 | Sum Q=1; sum regular=T antes de redondeo, tolerancia 1e-10 relativa/absoluta | H2 |
| R24 | Sección 5 | H compartido; innovaciones independientes por zona/día/hora | H2 |
| R25 | RN-IV-07 | Ausencia de zona no consume ni cambia las otras series | H2 |
| R26 | RN-XI-05 | Total hogar igual a suma de zonas, sin fila adicional | H2/H3 |
| R27 | Sección 5 | Energía de evento, solapamiento, medianoche y duraciones multihora | H2 |
| R28 | Sección 5 | Fronteras de backfill y continuación según A09/A10 | H2 |
| R29 | Sección 5 | Fallback de curva y zona sin eventos | H2 |
| R30 | RN-IV-04 | Reproducibilidad entre procesos y distinta PYTHONHASHSEED | H2 |
| R31 | RN-IV-05 | Recuperación de huecos y reintentos idempotentes | H2/H3 |
| R32 | Encargo | Separar energía regular, adicional y final | H2 |
| R33 | Encargo | Congelar criterios antes de ajustar; historial de fallos y correcciones | H2 |
| R34 | Encargo | 100 semillas × 30 días por conjunto final en validación reservada | H2 |
| R35 | Encargo | 365 días por personalidad, además de 100×30 | H2 |
| R36 | Encargo | Semillas/periodos de ajuste separados de validación | H2 |
| R37 | Encargo | Media, mediana, dispersión, percentiles y cobertura del rango objetivo | H2 |
| R38 | Encargo | Por zona, horario, laboral/fin de semana, frecuencia y energía de eventos | H2 |
| R39 | Encargo | Sensibilidad a bases, humor, F, phi, sigma, probabilidad, P/D/fracción | H2 |
| R40 | Validez 6 + encargo | Orden de objetivos en cinco hogares válidos; solapamientos permitidos | H2 |
| R41 | Encargo | Parámetros disponibles para toda zona aplicable, incluidas no presentes en referencia | H2 |
| R42 | Encargo | Cobertura estructural de todas las combinaciones válidas y casos estadísticos límite | H2 |
| R43 | Encargo | Carga no destructiva que preserve ID y referencias | H3 |
| R44 | Encargo | Archivo → PostgreSQL → simulador → lecturas → consulta; comparar ida/vuelta | H3 |
| R45 | RN-IV-01 | 720 lecturas por zona; zona horaria, calidad y precisión | H3 |
| R46 | RN-X-03 | Hogar-zona-sensor-fuente consistentes; un sensor y fuente según contrato | H3 |
| R47 | Encargo | Distinguir PostgreSQL local, módulo real y Supabase; no sustituir por SQLite | H3 |
| R48 | RN-XI-07 | Sin umbrales definitivos no certificar alertas; pruebas controladas separadas | H3 |
| R49 | Encargo | Reabrir JSON finales y repetir suite; hashes coinciden con informes | H3 |
| R50 | Encargo | Sin secretos ni datos personales reales; finales separados de descartados | Todos |
| R51 | Encargo | README, dependencias, resultados tabulares, gráficos y continuidad | Todos |
| R52 | Encargo | Guardar hitos; no estimar créditos ni garantizar techo | Todos |

## Plan de continuación sin omitir pruebas

Primero se derivarán balances de los diez hogares y se seleccionará una referencia por personalidad mediante una matriz explícita. Después se congelarán objetivos/rangos y criterios energéticos, se construirá la implementación de referencia si sigue sin existir un simulador adjunto y se calibrará en el orden bases, curvas, humor, fin de semana, ruido, eventos y evaluación conjunta.

La validación reservada mantendrá como mínimo 100 semillas de 30 días y una serie de 365 días por personalidad. A continuación se ejecutará PostgreSQL local aislado si el entorno lo permite; Supabase y módulo real no se darán por probados sin acceso autorizado y ejecución efectiva.
