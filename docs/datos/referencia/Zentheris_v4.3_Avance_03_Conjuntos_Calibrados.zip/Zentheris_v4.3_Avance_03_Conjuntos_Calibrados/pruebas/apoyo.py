import copy
import json
import sys
from datetime import date, datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "codigo"))

from zentheris_sim.constantes import PERSONALIDADES, ZONA_HORARIA  # noqa: E402
from zentheris_sim.validacion import leer_archivo  # noqa: E402

DATOS = RAIZ / "pruebas" / "datos_prueba"
INSUMOS = RAIZ / "insumos"


def perfiles_prueba() -> dict:
    out = {}
    for n in PERSONALIDADES:
        out[n] = leer_archivo(DATOS / f"prueba_{n.split()[1]}.json")
    return out


def perfil(nombre="Consumo familiar"):
    return copy.deepcopy(perfiles_prueba()[nombre])


def dt(y, m, d, h=0, mi=0):
    return datetime(y, m, d, h, mi, tzinfo=ZONA_HORARIA)


def idx(y, m, d, h=0):
    return date(y, m, d).toordinal() * 24 + h


def a_texto(p):
    return json.dumps(p, ensure_ascii=False)
