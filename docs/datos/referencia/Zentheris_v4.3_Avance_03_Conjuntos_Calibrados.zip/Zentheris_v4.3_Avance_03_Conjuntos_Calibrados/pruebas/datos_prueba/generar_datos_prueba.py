"""Genera los conjuntos de PRUEBA (no calibrados) usados por la suite del bloque 1.

Toman la forma de los ejemplos ilustrativos de v4.3, sección 5. No son parámetros
finales ni candidatos: solo ejercitan estructura, fórmula y cobertura.
"""
import json
from pathlib import Path

AQUI = Path(__file__).resolve().parent
BASE = [0.01, 0.01, 0.01, 0.01, 0.01, 0.02, 0.04, 0.06, 0.04, 0.03, 0.03, 0.04,
        0.06, 0.05, 0.04, 0.03, 0.03, 0.04, 0.07, 0.10, 0.10, 0.09, 0.04, 0.04]
DORM = [0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.06, 0.04, 0.02, 0.01, 0.01, 0.01,
        0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.02, 0.04, 0.07, 0.10, 0.14, 0.12]
OFIC = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.02, 0.08, 0.11, 0.11, 0.11,
        0.08, 0.10, 0.11, 0.11, 0.09, 0.05, 0.02, 0.01, 0.0, 0.0, 0.0, 0.0]
ZONAS = ["cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio"]
BASES = [1.2, 0.6, 0.3, 0.1, 0.4, 0.5, 0.2, 0.15, 0.25]
NOMBRES = ["Consumo compacto", "Consumo eficiente", "Consumo intermedio", "Consumo familiar", "Consumo amplio"]
ESCALA = [0.5, 0.8, 1.0, 1.3, 1.7]


def perfil(i):
    p = {"nombre": NOMBRES[i], "activo": True}
    for z, b in zip(ZONAS, BASES):
        p[f"base_{z}_kwh_dia"] = round(b * ESCALA[i], 4)
    p.update({
        "curva_horaria": {"base": BASE, "dormitorio": DORM, "oficina": OFIC},
        "humor_min": 0.9, "humor_max": 1.1,
        "ruido_config": {"memoria": 0.6, "intensidad": 0.05},
        "picos_config": {
            "cocina": {"probabilidad": 0.02, "franjas": [{"desde": 18, "hasta": 21, "multiplicador": 2.0}],
                       "potencia_w": [1000, 1800], "duracion_min": [10, 30],
                       "minuto_inicio": [0, 59], "fraccion_uso": [0.5, 0.9]},
            "lavanderia": {"probabilidad": 0.01, "franjas": [], "potencia_w": [500, 2000],
                           "duracion_min": [30, 90], "minuto_inicio": [0, 59], "fraccion_uso": [0.6, 1.0]},
            "terraza": {"probabilidad": 0.01,
                        "franjas": [{"desde": 22, "hasta": 24, "multiplicador": 3.0},
                                    {"desde": 0, "hasta": 2, "multiplicador": 3.0}],
                        "potencia_w": [200, 600], "duracion_min": [60, 180],
                        "minuto_inicio": [0, 59], "fraccion_uso": [0.8, 1.0]}},
        "factor_fin_semana": round(1.0 + 0.05 * i, 4),
    })
    return p


if __name__ == "__main__":
    for i in range(5):
        nombre = NOMBRES[i].split()[1]
        (AQUI / f"prueba_{nombre}.json").write_text(
            json.dumps(perfil(i), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("5 conjuntos de prueba escritos")
