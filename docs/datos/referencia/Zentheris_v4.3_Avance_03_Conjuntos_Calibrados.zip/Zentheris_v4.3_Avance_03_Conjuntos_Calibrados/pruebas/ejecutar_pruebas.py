"""Ejecuta la suite y escribe resultados/pruebas_<etiqueta>.csv con el estado de cada prueba.

Uso (desde avance_03):  python pruebas/ejecutar_pruebas.py [etiqueta]
"""
import csv
import platform
import sys
import time
import unittest
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "codigo"))
CATEGORIA = {"test_estructura": "11.1 estructura", "test_modelo": "11.2 modelo matemático",
             "test_combinaciones": "11.4 combinaciones", "test_conjuntos_finales": "conjuntos finales"}


class Registro(unittest.TextTestResult):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.filas, self._t = [], {}

    def startTest(self, test):
        self._t[test.id()] = time.perf_counter()
        super().startTest(test)

    def _fila(self, test, estado, detalle=""):
        mod, _, nombre = test.id().split(".")
        doc = (test.shortDescription() or "").split(" ", 1)
        self.filas.append({"id": doc[0], "categoria": CATEGORIA.get(mod, mod), "prueba": nombre,
                           "descripcion": doc[1] if len(doc) > 1 else "", "estado": estado,
                           "segundos": f"{time.perf_counter() - self._t[test.id()]:.3f}",
                           "detalle": detalle.strip().splitlines()[-1][:300] if detalle else ""})

    def addSuccess(self, test):
        super().addSuccess(test); self._fila(test, "aprobado")

    def addFailure(self, test, err):
        super().addFailure(test, err); self._fila(test, "fallido", self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err); self._fila(test, "fallido", self._exc_info_to_string(err, test))


def main():
    etiqueta = sys.argv[1] if len(sys.argv) > 1 else "bloque1"
    suite = unittest.defaultTestLoader.discover(str(AQUI), pattern="test_*.py")
    res = unittest.TextTestRunner(resultclass=Registro, verbosity=1).run(suite)
    salida = AQUI.parent / "resultados" / f"pruebas_{etiqueta}.csv"
    with open(salida, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(res.filas[0]))
        w.writeheader(); w.writerows(sorted(res.filas, key=lambda f: f["id"]))
    print(f"{len(res.filas)} pruebas; fallidas={len(res.failures) + len(res.errors)}; "
          f"Python {platform.python_version()}; CSV: {salida.name}")
    sys.exit(0 if res.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
