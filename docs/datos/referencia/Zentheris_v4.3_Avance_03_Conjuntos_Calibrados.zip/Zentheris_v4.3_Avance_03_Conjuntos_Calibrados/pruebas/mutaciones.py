"""Siembra defectos en una copia temporal del simulador y comprueba que la suite los detecta.

Uso (desde avance_03): python pruebas/mutaciones.py
Escribe resultados/mutaciones_bloque1.csv. No modifica el código real.
"""
import csv
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
MUTACIONES = [
    ("sin_renormalizar_Q", "return [x / s for x in wp], n", "return [x for x in wp], n"),
    ("incluye_eventos_antes_de_frontera", "if ev.inicio_min < frontera * 60 or", "if False or"),
    ("humor_no_reproducible", '(u,) = uniformes(hogar_id, fecha, version, None, "humor", 1)',
     '(u,) = uniformes(hogar_id, fecha, version, None, "humor", 1); import random as _r; u = _r.random()'),
    ("viernes_como_fin_de_semana", "if fecha.weekday() >= 5 else 1.0", "if fecha.weekday() >= 4 else 1.0"),
    ("ruido_sin_memoria", "n_prev = nt", "n_prev = 0.0"),
    ("evento_sin_reparto_entre_horas", "out[k0 + j] = ev.energia_kwh * solape / ev.duracion_min",
     "out[k0] = out.get(k0, 0) + ev.energia_kwh * solape / ev.duracion_min"),
    ("energia_evento_sin_fraccion", "P * (D / 60.0) * f / 1000.0", "P * (D / 60.0) / 1000.0"),
    ("zona_ausente_simulada", "for z in sorted(hogar[\"zonas\"])}", "for z in sorted(set(hogar[\"zonas\"]) | {\"garaje\"})}"),
]


def main():
    filas = []
    for nombre, viejo, nuevo in MUTACIONES:
        with tempfile.TemporaryDirectory() as tmp:
            dst = Path(tmp) / "a"
            shutil.copytree(RAIZ, dst, ignore=shutil.ignore_patterns("resultados", "__pycache__"))
            (dst / "resultados").mkdir()
            f = dst / "codigo" / "zentheris_sim" / "simulador.py"
            s = f.read_text(encoding="utf-8")
            assert viejo in s, nombre
            f.write_text(s.replace(viejo, nuevo, 1), encoding="utf-8")
            r = subprocess.run([sys.executable, str(dst / "pruebas" / "ejecutar_pruebas.py"), "mut"],
                               capture_output=True, text=True)
            fall = [l.split()[1] for l in (r.stdout + r.stderr).splitlines() if l.startswith(("FAIL:", "ERROR:"))]
            filas.append({"mutacion": nombre, "detectada": "si" if fall else "no",
                          "pruebas_que_fallan": "|".join(sorted(set(fall)))})
    with open(RAIZ / "resultados" / "mutaciones_bloque1.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(filas[0])); w.writeheader(); w.writerows(filas)
    det = sum(f["detectada"] == "si" for f in filas)
    print(f"{det}/{len(filas)} mutaciones detectadas")
    sys.exit(0 if det == len(filas) else 1)


if __name__ == "__main__":
    main()
