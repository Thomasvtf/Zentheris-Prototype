"""11.4 Combinaciones: onboarding, RN-X-04, respaldo y simulación de las 147 selecciones válidas."""
import csv
import importlib.util
import math
import unittest

from apoyo import INSUMOS, idx, perfiles_prueba
from zentheris_sim.almacen import crear_hogar
from zentheris_sim.asignacion import (OnboardingInvalido, asignar_personalidad, enumerar_selecciones,
                                      resolver_activa, validar_onboarding, zonas_aplicables)
from zentheris_sim.constantes import COLUMNAS_BASE, PERSONALIDADES, ZONAS
from zentheris_sim.simulador import simular_hogar

B4 = ("cocina", "sala", "dormitorio", "bano")
EJEMPLOS_TABLA_12 = [
    ("apartaestudio", B4, "Consumo compacto"),
    ("apartaestudio", B4 + ("lavanderia",), "Consumo eficiente"),
    ("apartamento", B4, "Consumo eficiente"),
    ("apartamento", B4 + ("oficina",), "Consumo intermedio"),
    ("apartamento", B4 + ("terraza",), "Consumo intermedio"),
    ("apartamento", B4 + ("oficina", "lavanderia"), "Consumo familiar"),
    ("apartamento", B4 + ("terraza", "garaje"), "Consumo familiar"),
    ("apartamento", B4 + ("lavanderia", "terraza", "garaje"), "Consumo amplio"),
    ("casa", B4 + ("cuarto_servicio",), "Consumo familiar"),
    ("duplex", ZONAS, "Consumo amplio"),
    ("casa_campestre", B4, "Consumo intermedio"),
    ("casa_campestre", B4 + ("terraza",), "Consumo familiar"),
    ("casa_campestre", B4 + ("oficina", "terraza"), "Consumo amplio"),
]


def cobertura_parametros(perfiles: dict) -> list[str]:
    """Zonas aplicables a una personalidad cuya base es 0 (no tendrían consumo regular).
    Se reutilizará con los conjuntos finales."""
    falta = []
    for nombre, zonas in zonas_aplicables().items():
        for z in zonas:
            if not perfiles[nombre][COLUMNAS_BASE[z]] > 0:
                falta.append(f"{nombre}:{z}")
    return falta


class Combinaciones(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.todas = list(enumerar_selecciones())
        cls.validas = [(v, z, p) for v, z, ok, p in cls.todas if ok]
        spec = importlib.util.spec_from_file_location("a01", INSUMOS / "auditar_contrato_avance01.py")
        cls.a01 = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.a01)

    def test_k01_enumeracion(self):
        """K01 2.560 selecciones: 147 válidas y 2.413 rechazadas (R02)."""
        self.assertEqual(len(self.todas), 2560)
        self.assertEqual(len(self.validas), 147)

    def test_k02_coincide_con_avance01(self):
        """K02 Las 147 combinaciones y su personalidad coinciden con combinaciones_validas.csv del Avance 01."""
        with open(INSUMOS / "combinaciones_validas_avance01.csv", encoding="utf-8") as fh:
            ref = {(r["vivienda"], frozenset(r["zonas"].split("|"))): r["personalidad"] for r in csv.DictReader(fh)}
        mio = {(v, frozenset(z)): p for v, z, p in self.validas}
        self.assertEqual(mio, ref)

    def test_k03_diferencial_contra_avance01(self):
        """K03 Prueba diferencial: mismas decisiones que la implementación del Avance 01 en las 2.560."""
        for v, z, ok, p in self.todas:
            try:
                otro = self.a01.asignar(v, list(z))
            except ValueError:
                otro = None
            self.assertEqual(p, otro, (v, z))

    def test_k04_ejemplos_tabla_12(self):
        """K04 Los 13 ejemplos de la tabla 12 (R03)."""
        for v, z, esperado in EJEMPLOS_TABLA_12:
            self.assertEqual(asignar_personalidad(v, z), esperado, (v, z))

    def test_k05_conteos_por_personalidad(self):
        """K05 Combinaciones ordinarias por personalidad: 13, 9, 13, 49, 63."""
        cuenta = {p: 0 for p in PERSONALIDADES}
        for _, _, p in self.validas:
            cuenta[p] += 1
        self.assertEqual([cuenta[p] for p in PERSONALIDADES], [13, 9, 13, 49, 63])

    def test_k06_campestre_sube_un_nivel(self):
        """K06 Casa campestre = casa + 1 nivel, con tope en amplio (R04)."""
        for v, z, p in self.validas:
            if v == "casa_campestre":
                casa = asignar_personalidad("casa", z)
                esperado = {"Consumo eficiente": "Consumo intermedio", "Consumo intermedio": "Consumo familiar",
                            "Consumo familiar": "Consumo amplio", "Consumo amplio": "Consumo amplio"}[casa]
                self.assertEqual(p, esperado)

    def test_k07_respaldo(self):
        """K07 Asignada inactiva/ausente => eficiente; si eficiente falta, error controlado (R05, A20)."""
        act = {p: True for p in PERSONALIDADES}
        self.assertEqual(resolver_activa("Consumo amplio", act), "Consumo amplio")
        self.assertEqual(resolver_activa("Consumo amplio", dict(act, **{"Consumo amplio": False})), "Consumo eficiente")
        self.assertEqual(resolver_activa("Consumo amplio", {"Consumo eficiente": True}), "Consumo eficiente")
        with self.assertRaises(LookupError):
            resolver_activa("Consumo amplio", dict(act, **{"Consumo amplio": False, "Consumo eficiente": False}))

    def test_k08_rechazos_onboarding(self):
        """K08 Rechazos: zona repetida/desconocida, extras en apartaestudio, faltan básicas, vivienda desconocida."""
        malos = [("apartaestudio", B4 + ("terraza",)), ("apartaestudio", ("cocina", "sala", "oficina")),
                 ("apartaestudio", B4 + ("oficina", "lavanderia")), ("apartamento", ("cocina", "sala", "bano")),
                 ("apartamento", B4 + ("cocina",)), ("apartamento", B4 + ("patio",)), ("loft", B4)]
        for v, z in malos:
            with self.assertRaises(OnboardingInvalido, msg=(v, z)):
                validar_onboarding(v, z)

    def test_k09_zonas_aplicables(self):
        """K09 Unión de zonas por personalidad (Avance 01) y nueve para eficiente por respaldo (A19)."""
        za = zonas_aplicables()
        self.assertEqual(za["Consumo compacto"], frozenset(B4 + ("oficina", "lavanderia")))
        self.assertEqual(za["Consumo intermedio"], frozenset(B4 + ("oficina", "lavanderia", "terraza", "garaje")))
        for p in ("Consumo eficiente", "Consumo familiar", "Consumo amplio"):
            self.assertEqual(za[p], frozenset(ZONAS))

    def test_k10_cobertura_parametros_prueba(self):
        """K10 Con los conjuntos de prueba, toda zona aplicable tiene base > 0 (función reutilizable)."""
        self.assertEqual(cobertura_parametros(perfiles_prueba()), [])
        p = perfiles_prueba(); p["Consumo eficiente"]["base_garaje_kwh_dia"] = 0
        self.assertEqual(cobertura_parametros(p), ["Consumo eficiente:garaje"])

    def test_k11_simular_las_147(self):
        """K11 Cada combinación válida se crea, recibe su personalidad y simula 2 días solo de sus zonas."""
        perfiles = perfiles_prueba()
        ini = idx(2026, 9, 5)  # sábado y domingo
        for i, (v, z, p) in enumerate(self.validas):
            h = crear_hogar(f"comb-{i}", v, z)
            self.assertEqual(h["personalidad"], p)
            s = simular_hogar(h, perfiles[p], ini, ini + 48)
            self.assertEqual(set(s), set(z))
            for filas in s.values():
                self.assertEqual(len(filas), 48)
                self.assertTrue(all(math.isfinite(f[3]) and f[3] >= 0 for f in filas))

    def test_k12_respaldo_con_nueve_zonas(self):
        """K12 Dúplex de 9 zonas con amplio inactivo usa eficiente y simula las 9 zonas."""
        act = {p: True for p in PERSONALIDADES}
        act["Consumo amplio"] = False
        h = crear_hogar("respaldo-9", "duplex", ZONAS, act)
        self.assertEqual((h["personalidad_asignada"], h["personalidad"]), ("Consumo amplio", "Consumo eficiente"))
        s = simular_hogar(h, perfiles_prueba()["Consumo eficiente"], idx(2026, 9, 1), idx(2026, 9, 2))
        self.assertEqual(set(s), set(ZONAS))
        self.assertTrue(all(sum(f[3] for f in filas) > 0 for filas in s.values()))


if __name__ == "__main__":
    unittest.main()
