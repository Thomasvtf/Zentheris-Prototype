"""Pruebas sobre los cinco JSON finales (no sobre datos de prueba)."""
import hashlib
import json
import math
import re
import unittest

from apoyo import RAIZ, idx
from test_combinaciones import cobertura_parametros
from zentheris_sim.almacen import crear_hogar
from zentheris_sim.asignacion import enumerar_selecciones
from zentheris_sim.constantes import PERSONALIDADES
from zentheris_sim.simulador import backfill, simular_hogar
from zentheris_sim.validacion import (contiene_credencial, leer_archivo, margen_ruido,
                                      validar_conjunto_de_cinco)

PF = RAIZ / "parametros_finales"


def finales():
    return {n: leer_archivo(PF / f"{n.lower().replace(' ', '_')}.json") for n in PERSONALIDADES}


class ConjuntosFinales(unittest.TestCase):
    def test_f01_estructura(self):
        """F01 Los cinco JSON finales pasan el validador estricto y tienen los cinco nombres (CT01–CT05)."""
        self.assertEqual(validar_conjunto_de_cinco(list(finales().values())), [])

    def test_f02_consolidado_identico(self):
        """F02 El consolidado contiene exactamente los mismos cinco conjuntos."""
        cons = json.loads((PF / "consolidado_perfiles_simulacion.json").read_text(encoding="utf-8"))
        self.assertEqual(cons, [finales()[n] for n in PERSONALIDADES])

    def test_f03_cobertura_zonas_aplicables(self):
        """F03 Toda zona que una personalidad puede recibir (incluido respaldo eficiente) tiene base > 0."""
        self.assertEqual(cobertura_parametros(finales()), [])

    def test_f04_ceros_justificados(self):
        """F04 Solo tienen base 0 las zonas que la personalidad nunca recibe."""
        f = finales()
        self.assertEqual([z for z in ("terraza", "garaje", "cuarto_servicio") if f["Consumo compacto"][f"base_{z}_kwh_dia"] == 0],
                         ["terraza", "garaje", "cuarto_servicio"])
        self.assertEqual(f["Consumo intermedio"]["base_cuarto_servicio_kwh_dia"], 0)

    def test_f05_margen_ruido_y_humor_centrado(self):
        """F05 σ/(1−φ) < 1 y humor simétrico alrededor de 1 (E[H] = 1)."""
        for n, p in finales().items():
            self.assertLess(margen_ruido(p), 1, n)
            self.assertAlmostEqual((p["humor_min"] + p["humor_max"]) / 2, 1.0, places=12)

    def test_f06_sql_generado_de_estos_archivos(self):
        """F06 El SQL de carga declara el SHA-256 de estos mismos archivos y no contiene DELETE."""
        sql = (RAIZ / "sql" / "01_carga_perfiles_simulacion.sql").read_text(encoding="utf-8")
        for n in PERSONALIDADES:
            r = PF / f"{n.lower().replace(' ', '_')}.json"
            self.assertIn(hashlib.sha256(r.read_bytes()).hexdigest(), sql)
        self.assertNotRegex(sql.upper(), r"\b(DELETE|TRUNCATE|DROP)\b")
        self.assertEqual(sql.count("ON CONFLICT (nombre) DO UPDATE"), 5)

    def test_f07_sin_credenciales(self):
        """F07 Ningún archivo final contiene patrones de credenciales."""
        for r in list(PF.glob("*.json")) + list((RAIZ / "sql").glob("*.sql")):
            self.assertFalse(contiene_credencial(r.read_text(encoding="utf-8")), r.name)

    def test_f08_backfill_720_con_finales(self):
        """F08 Backfill de 720 h con cada conjunto final en su hogar de referencia: finito y >= 0."""
        from datetime import datetime
        from zentheris_sim.constantes import ZONA_HORARIA
        cong = json.loads((RAIZ / "congelamiento" / "congelamiento.json").read_text(encoding="utf-8"))
        for n, p in finales().items():
            r = cong["referencias"][n]
            h = crear_hogar(f"f08|{n}", r["vivienda"], tuple(r["zonas"]))
            s = backfill(h, p, datetime(2026, 10, 28, 15, 23, tzinfo=ZONA_HORARIA))
            self.assertEqual(set(s), set(r["zonas"]))
            for filas in s.values():
                self.assertEqual(len(filas), 720)
                self.assertTrue(all(math.isfinite(x[3]) and x[3] >= 0 for x in filas))

    def test_f09_las_147_con_finales(self):
        """F09 Las 147 combinaciones válidas simulan 2 días con su conjunto final, solo con sus zonas."""
        f = finales()
        ini = idx(2026, 11, 7)
        n = 0
        for v, z, ok, p in enumerar_selecciones():
            if not ok:
                continue
            h = crear_hogar(f"f09|{n}", v, z)
            s = simular_hogar(h, f[p], ini, ini + 48)
            self.assertEqual(set(s), set(z))
            self.assertTrue(all(sum(x[3] for x in filas) > 0 for filas in s.values()), (v, z))
            n += 1
        self.assertEqual(n, 147)

    def test_f10_sin_metadatos_en_json(self):
        """F10 Sin claves explicativas, 'default' ni fuentes dentro de los JSON (solo contrato)."""
        for p in finales().values():
            texto = json.dumps(p, ensure_ascii=False)
            self.assertIsNone(re.search(r'"(default|fuente|nota|descripcion|supuesto)"', texto))


if __name__ == "__main__":
    unittest.main()
