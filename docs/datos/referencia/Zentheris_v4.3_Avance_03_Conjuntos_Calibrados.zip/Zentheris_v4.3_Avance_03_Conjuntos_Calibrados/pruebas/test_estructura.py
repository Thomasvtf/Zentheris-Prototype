"""11.1 Estructura: JSON, campos, tipos, bases, curvas, ruido, picos y rechazos."""
import copy
import unittest

from apoyo import a_texto, perfil, perfiles_prueba
from zentheris_sim.validacion import (ErrorParametros, cargar_json_estricto, contiene_credencial,
                                      validar_conjunto_de_cinco, validar_perfil)


def codigos(p, **kw):
    return {c for c, _ in validar_perfil(p, **kw)}


class Estructura(unittest.TestCase):
    def test_e01_datos_prueba_validos(self):
        """E01 Los cinco conjuntos de prueba pasan el validador (CT01–CT05)."""
        for n, p in perfiles_prueba().items():
            self.assertEqual(validar_perfil(p), [], n)

    def test_e02_cinco_nombres_sin_colision(self):
        """E02 Exactamente cinco nombres exactos; duplicado o faltante se rechaza (CT01)."""
        ps = list(perfiles_prueba().values())
        self.assertEqual(validar_conjunto_de_cinco(ps), [])
        malo = ps[:4] + [copy.deepcopy(ps[0])]
        self.assertIn("cinco_nombres", {c for c, _ in validar_conjunto_de_cinco(malo)})
        otro = copy.deepcopy(ps[0]); otro["nombre"] = "Consumo Compacto"
        self.assertIn("nombre", codigos(otro))

    def test_e03_clave_duplicada(self):
        """E03 JSON con clave duplicada se rechaza al leer (CT02)."""
        t = a_texto(perfil()).replace('"activo": true', '"activo": true, "activo": false')
        with self.assertRaises(ErrorParametros):
            cargar_json_estricto(t)

    def test_e04_nan_infinito(self):
        """E04 NaN, Infinity y -Infinity se rechazan al leer (CT02)."""
        for lit in ("NaN", "Infinity", "-Infinity"):
            t = a_texto(perfil()).replace('"humor_min": 0.9', f'"humor_min": {lit}')
            with self.assertRaises(ErrorParametros, msg=lit):
                cargar_json_estricto(t)
        p = perfil(); p["humor_min"] = float("nan")
        self.assertIn("humor_min_tipo", codigos(p))

    def test_e05_campos_desconocidos_y_faltantes(self):
        """E05 Campo fuera del contrato o faltante se rechaza; sin campos explicativos."""
        p = perfil(); p["fuente"] = "narrativa"
        self.assertIn("clave_desconocida", codigos(p))
        p = perfil(); del p["base_garaje_kwh_dia"]
        self.assertIn("campo_faltante", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["nota"] = "x"
        self.assertIn("pico_clave_desconocida", codigos(p))

    def test_e06_booleanos_y_cadenas_no_son_numeros(self):
        """E06 true/false o "1.2" no cuentan como números (CT02)."""
        p = perfil(); p["base_sala_kwh_dia"] = True
        self.assertIn("base_tipo", codigos(p))
        p = perfil(); p["factor_fin_semana"] = "1.1"
        self.assertIn("factor_fin_semana_tipo", codigos(p))
        p = perfil(); p["ruido_config"]["memoria"] = False
        self.assertIn("ruido_memoria", codigos(p))
        p = perfil(); p["activo"] = 1
        self.assertIn("activo", codigos(p))

    def test_e07_bases(self):
        """E07 Bases >= 0 y con máximo 4 decimales (NUMERIC(10,4))."""
        p = perfil(); p["base_bano_kwh_dia"] = -0.0001
        self.assertIn("base_negativa", codigos(p))
        p = perfil(); p["base_bano_kwh_dia"] = 0.12345
        self.assertIn("base_precision", codigos(p))
        p = perfil(); p["base_bano_kwh_dia"] = 0
        self.assertEqual(validar_perfil(p), [])

    def test_e08_humor_y_factor(self):
        """E08 humor ordenado y >= 0; factor > 0; NUMERIC(6,4)."""
        p = perfil(); p["humor_min"], p["humor_max"] = 1.2, 1.1
        self.assertIn("humor_invertido", codigos(p))
        p = perfil(); p["humor_min"] = -0.1
        self.assertIn("humor_negativo", codigos(p))
        p = perfil(); p["factor_fin_semana"] = 0
        self.assertIn("factor_no_positivo", codigos(p))
        p = perfil(); p["humor_max"] = 100.0
        self.assertIn("humor_max_precision", codigos(p))

    def test_e09_curvas(self):
        """E09 base obligatoria; 24 valores finitos >= 0; suma 1 ± 1e-10; claves de zona (CT03)."""
        p = perfil(); del p["curva_horaria"]["base"]
        self.assertIn("curva_base", codigos(p))
        p = perfil(); p["curva_horaria"]["base"] = p["curva_horaria"]["base"][:23]
        self.assertIn("curva_longitud", codigos(p))
        p = perfil(); p["curva_horaria"]["base"][0] = -0.01; p["curva_horaria"]["base"][1] = 0.03
        self.assertIn("curva_negativa", codigos(p))
        p = perfil(); p["curva_horaria"]["base"][0] += 1e-9
        self.assertIn("curva_suma", codigos(p))
        p = perfil(); p["curva_horaria"]["cocinas"] = p["curva_horaria"]["base"]
        self.assertIn("curva_clave", codigos(p))
        p = perfil(); p["curva_horaria"]["sala"] = p["curva_horaria"]["base"]
        self.assertEqual(validar_perfil(p), [])

    def test_e10_ruido(self):
        """E10 ruido solo memoria/intensidad comunes; 0<=φ<1; σ>=0; sin default ni por zona (CT04)."""
        p = perfil(); p["ruido_config"]["memoria"] = 1.0
        self.assertIn("ruido_memoria", codigos(p))
        p = perfil(); p["ruido_config"]["intensidad"] = -0.01
        self.assertIn("ruido_intensidad", codigos(p))
        p = perfil(); p["ruido_config"]["default"] = {"memoria": 0.6, "intensidad": 0.05}
        self.assertIn("ruido_clave", codigos(p))
        p = perfil(); p["ruido_config"]["cocina"] = {"memoria": 0.4, "intensidad": 0.1}
        self.assertIn("ruido_clave", codigos(p))

    def test_e11_margen_ruido(self):
        """E11 σ/(1−φ) >= 1 se rechaza en conjuntos finales; permitido solo en modo contrato (CT05)."""
        p = perfil(); p["ruido_config"] = {"memoria": 0.5, "intensidad": 0.5}
        self.assertIn("ruido_margen", codigos(p))
        self.assertNotIn("ruido_margen", codigos(p, exigir_margen_ruido=False))

    def test_e12_picos_rangos(self):
        """E12 rangos [min,max] ordenados; minuto entero 0–59; fracción 0–1; potencia y duración >= 0."""
        casos = [("potencia_w", [1800, 1000], "pico_rango_invertido"),
                 ("duracion_min", [-5, 10], "pico_rango_limite"),
                 ("minuto_inicio", [0, 60], "pico_rango_limite"),
                 ("minuto_inicio", [0.5, 59], "pico_rango_entero"),
                 ("fraccion_uso", [0.5, 1.2], "pico_rango_limite"),
                 ("potencia_w", [1000], "pico_rango")]
        for clave, valor, cod in casos:
            p = perfil(); p["picos_config"]["cocina"][clave] = valor
            self.assertIn(cod, codigos(p), (clave, valor))

    def test_e13_probabilidades_y_franjas(self):
        """E13 probabilidad en [0,1] antes y después de franja; franjas [desde,hasta) sin solape (A05)."""
        p = perfil(); p["picos_config"]["cocina"]["probabilidad"] = 1.2
        self.assertIn("pico_probabilidad", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["probabilidad"] = 0.6  # ×2 en franja = 1.2
        self.assertIn("pico_probabilidad_efectiva", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["franjas"] = [{"desde": 21, "hasta": 18, "multiplicador": 2}]
        self.assertIn("franja_limites", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["franjas"] = [
            {"desde": 18, "hasta": 21, "multiplicador": 2}, {"desde": 20, "hasta": 22, "multiplicador": 2}]
        self.assertIn("franja_solapada", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["franjas"] = [{"desde": 18, "hasta": 21}]
        self.assertIn("franja_claves", codigos(p))
        p = perfil(); p["picos_config"]["cocina"]["probabilidad"] = 0.5  # ×2 = 1, permitido
        self.assertEqual(validar_perfil(p), [])

    def test_e14_picos_claves(self):
        """E14 picos solo por zona del catálogo; sin 'default'; campos completos."""
        p = perfil(); p["picos_config"]["default"] = copy.deepcopy(p["picos_config"]["cocina"])
        self.assertIn("pico_clave", codigos(p))
        p = perfil(); del p["picos_config"]["cocina"]["franjas"]
        self.assertIn("pico_campo_faltante", codigos(p))
        p = perfil(); p["picos_config"] = {}
        self.assertEqual(validar_perfil(p), [])

    def test_e15_campos_gestionados_por_base(self):
        """E15 id/created_at/updated_at opcionales y con formato válido."""
        p = perfil(); p["id"] = "no-es-uuid"
        self.assertIn("id", codigos(p))
        p = perfil(); p["id"] = "8b6f1c9e-2b1a-4c1e-9a77-0e0f6f1d2c3b"; p["created_at"] = "2026-10-28T10:00:00-05:00"
        self.assertEqual(validar_perfil(p), [])

    def test_e16_escaneo_credenciales(self):
        """E16 el detector de credenciales marca patrones típicos y no los datos de prueba."""
        self.assertTrue(contiene_credencial("x eyJhbGciOiJIUzI1NiIsInR5cCI6.abc"))
        self.assertFalse(contiene_credencial(a_texto(perfil())))


if __name__ == "__main__":
    unittest.main()
