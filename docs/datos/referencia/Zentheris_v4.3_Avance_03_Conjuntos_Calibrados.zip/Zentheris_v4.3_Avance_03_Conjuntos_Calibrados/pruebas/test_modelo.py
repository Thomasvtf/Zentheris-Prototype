"""11.2 Modelo matemático: conservación, eventos, fronteras, zonas ausentes,
reproducibilidad, recuperación e idempotencia."""
import hashlib
import json
import math
import os
import random
import subprocess
import sys
import unittest
from datetime import date, timedelta
from decimal import Decimal

from apoyo import RAIZ, dt, idx, perfil, perfiles_prueba
from zentheris_sim.almacen import AlmacenMemoria, crear_hogar, generar_y_guardar, recuperar
from zentheris_sim.constantes import TOL_CONSERVACION, ZONA_HORARIA
from zentheris_sim.semillas import derivar_semilla, serializacion_canonica
from zentheris_sim.simulador import (Evento, RealizacionDegenerada, a_filas_lectura, backfill,
                                     calcular_q, epsilones, eventos_dia, humor, regular_dia,
                                     reparto_evento, simular_hogar, simular_zona, total_hogar)

TODAS = ("cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia", "terraza", "garaje", "cuarto_servicio")
HOGAR9 = crear_hogar("modelo-9", "duplex", TODAS)
INI = idx(2026, 9, 1)
FIN = idx(2026, 10, 1)


def perfil_medianoche():
    """Un único evento diario de 30 min que empieza a las 23:50 en cocina
    (probabilidad 1 con multiplicador 0 en 0–23 h y 1 en 23–24 h)."""
    p = perfil()
    p["picos_config"] = {"cocina": {"probabilidad": 1.0,
                                    "franjas": [{"desde": 0, "hasta": 23, "multiplicador": 0.0}],
                                    "potencia_w": [1200, 1200], "duracion_min": [30, 30],
                                    "minuto_inicio": [50, 50], "fraccion_uso": [0.5, 0.5]}}
    return p


class Modelo(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.perfiles = perfiles_prueba()
        cls.series = {n: simular_hogar(HOGAR9, p, INI, FIN) for n, p in cls.perfiles.items()}

    def test_m01_finitas_no_negativas(self):
        """M01 Toda lectura es finita y >= 0 (validez 1)."""
        for n, s in self.series.items():
            for z, filas in s.items():
                self.assertEqual(len(filas), 720, (n, z))
                for _, r, e, L in filas:
                    self.assertTrue(math.isfinite(L) and L >= 0 and r >= 0 and e >= 0, (n, z))

    def test_m02_q_suma_uno_y_regular_igual_t(self):
        """M02 Q suma 1 por zona y día y la suma regular diaria es T (validez 2 y 3, CT06)."""
        peor = 0.0
        for n, p in self.perfiles.items():
            for o in range(INI // 24, FIN // 24):
                for z in TODAS:
                    r = regular_dia(HOGAR9["id"], date.fromordinal(o), z, p)
                    self.assertLessEqual(abs(math.fsum(r["Q"]) - 1.0), 1e-12)
                    err = abs(math.fsum(r["regular"]) - r["T"]) / max(1.0, r["T"])
                    peor = max(peor, err)
        self.assertLessEqual(peor, TOL_CONSERVACION)

    def test_m03_humor_y_factor(self):
        """M03 H único por hogar-día dentro del rango; F solo sábado y domingo."""
        p = self.perfiles["Consumo amplio"]
        for o in range(INI // 24, FIN // 24):
            d = date.fromordinal(o)
            hs = {regular_dia(HOGAR9["id"], d, z, p)["H"] for z in TODAS}
            self.assertEqual(len(hs), 1)
            h = hs.pop()
            self.assertTrue(p["humor_min"] <= h <= p["humor_max"])
            F = regular_dia(HOGAR9["id"], d, "sala", p)["F"]
            self.assertEqual(F, p["factor_fin_semana"] if d.weekday() >= 5 else 1.0)

    def test_m04_ruido_reinicia_cada_dia(self):
        """M04 n[0] = σ·ε0 (n[−1]=0, A07) y la recurrencia n(t)=φn(t−1)+σε."""
        p = self.perfiles["Consumo familiar"]
        r = p["ruido_config"]
        d = date(2026, 9, 3)
        eps = epsilones(HOGAR9["id"], d, "cocina")
        n = regular_dia(HOGAR9["id"], d, "cocina", p)["n"]
        self.assertEqual(n[0], r["intensidad"] * eps[0])
        for t in range(1, 24):
            self.assertAlmostEqual(n[t], r["memoria"] * n[t - 1] + r["intensidad"] * eps[t], places=15)

    def test_m05_energia_evento_y_reparto(self):
        """M05 E = P·(D/60)·f/1000 y reparto por minutos entre horas (CT07)."""
        ev = Evento("cocina", 1000 * 1440 + 10 * 60 + 50, 20.0, 1200.0, 0.5, 1200 * (20 / 60) * 0.5 / 1000)
        rep = reparto_evento(ev)
        self.assertAlmostEqual(ev.energia_kwh, 0.2, places=15)
        self.assertEqual(sorted(rep), [1000 * 24 + 10, 1000 * 24 + 11])
        self.assertAlmostEqual(rep[1000 * 24 + 10], 0.1, places=15)
        self.assertAlmostEqual(rep[1000 * 24 + 11], 0.1, places=15)
        peor, n = 0.0, 0
        for p in self.perfiles.values():
            for o in range(INI // 24, FIN // 24):
                for z in TODAS:
                    for e in eventos_dia(HOGAR9["id"], date.fromordinal(o), z, p):
                        n += 1
                        cfg = p["picos_config"][z]
                        self.assertTrue(cfg["potencia_w"][0] <= e.potencia_w <= cfg["potencia_w"][1])
                        self.assertTrue(cfg["duracion_min"][0] <= e.duracion_min <= cfg["duracion_min"][1])
                        m = (e.inicio_min % 1440) % 60
                        self.assertTrue(cfg["minuto_inicio"][0] <= m <= cfg["minuto_inicio"][1] and m == int(m))
                        self.assertTrue(cfg["fraccion_uso"][0] <= e.fraccion_uso <= cfg["fraccion_uso"][1])
                        cerrado = e.potencia_w * (e.duracion_min / 60) * e.fraccion_uso / 1000
                        peor = max(peor, abs(math.fsum(reparto_evento(e).values()) - cerrado))
        self.assertGreater(n, 50)
        self.assertLessEqual(peor, 1e-10)

    def test_m06_medianoche(self):
        """M06 Un evento 23:50 + 30 min aporta 1/3 a las 23 h y 2/3 a las 00 h del día siguiente."""
        p = perfil_medianoche()
        E = 1200 * 0.5 * 0.5 / 1000
        h = idx(2026, 9, 10)
        filas = {k: ev for k, _, ev, _ in simular_zona(HOGAR9["id"], p, "cocina", h - 1, h + 1, INI)}
        self.assertAlmostEqual(filas[h - 1], E / 3, places=14)
        self.assertAlmostEqual(filas[h], 2 * E / 3, places=14)

    def test_m07_fronteras_backfill(self):
        """M07 Backfill: 720 h contiguas; sin cola izquierda (A10); cola derecha descartada
        y recuperada por la hora siguiente (A09); conservación evento exportado + descartado."""
        p = perfil_medianoche()
        hogar = crear_hogar("fronteras", "apartamento", ("cocina", "sala", "dormitorio", "bano"))
        ahora = dt(2026, 11, 1, 0, 30)
        s = backfill(hogar, p, ahora)
        fin = idx(2026, 11, 1)
        ini = fin - 720
        filas = s["cocina"]
        self.assertEqual([k for k, *_ in filas], list(range(ini, fin)))
        self.assertEqual(filas[0][2], 0.0)                 # 00 h del primer día: sin cola previa
        E = 1200 * 0.5 * 0.5 / 1000
        exportado = math.fsum(f[2] for f in filas)
        self.assertAlmostEqual(exportado, 30 * E - 2 * E / 3, places=12)
        sig = simular_zona(hogar["id"], p, "cocina", fin, fin + 1, ini)[0]
        self.assertAlmostEqual(sig[2], 2 * E / 3, places=14)
        self.assertAlmostEqual(exportado + sig[2], 30 * E, places=12)

    def test_m21_frontera_a_mitad_de_dia(self):
        """M21 Backfill que empieza a las 15 h: un evento de las 14:50 del primer día no entra (A10),
        el de los días siguientes sí aporta 2/3 a las 15 h."""
        p = perfil()
        p["picos_config"] = {"sala": {"probabilidad": 1.0,
                                      "franjas": [{"desde": 0, "hasta": 14, "multiplicador": 0.0},
                                                  {"desde": 15, "hasta": 24, "multiplicador": 0.0}],
                                      "potencia_w": [600, 600], "duracion_min": [30, 30],
                                      "minuto_inicio": [50, 50], "fraccion_uso": [1.0, 1.0]}}
        hogar = crear_hogar("frontera-15h", "apartamento", ("cocina", "sala", "dormitorio", "bano"))
        s = backfill(hogar, p, dt(2026, 10, 28, 15, 23))["sala"]
        E = 600 * 0.5 / 1000
        self.assertEqual(s[0][0], idx(2026, 9, 28, 15))
        self.assertEqual(s[0][2], 0.0)
        self.assertAlmostEqual(s[24][2], 2 * E / 3, places=14)
        self.assertAlmostEqual(math.fsum(f[2] for f in s), 29 * E + E / 3, places=12)

    def test_m08_curva_de_respaldo(self):
        """M08 Zona sin curva propia usa base; con σ=0, Q es exactamente la curva."""
        p = perfil(); p["ruido_config"]["intensidad"] = 0.0
        d = date(2026, 9, 5)
        q_sala = regular_dia(HOGAR9["id"], d, "sala", p)["Q"]
        q_dorm = regular_dia(HOGAR9["id"], d, "dormitorio", p)["Q"]
        base, dorm = p["curva_horaria"]["base"], p["curva_horaria"]["dormitorio"]
        for t in range(24):
            self.assertAlmostEqual(q_sala[t], base[t] / math.fsum(base), places=15)
            self.assertAlmostEqual(q_dorm[t], dorm[t] / math.fsum(dorm), places=15)

    def test_m09_zona_ausente(self):
        """M09 Zona ausente: cero filas, sin redistribución, demás zonas idénticas (RN-IV-07, CT09)."""
        p = self.perfiles["Consumo amplio"]
        sin = {"id": HOGAR9["id"], "zonas": frozenset(TODAS) - {"oficina", "garaje"}}
        s2 = simular_hogar(sin, p, INI, FIN)
        self.assertNotIn("oficina", s2)
        self.assertNotIn("garaje", s2)
        for z in s2:
            self.assertEqual(s2[z], self.series["Consumo amplio"][z])
        t9 = math.fsum(total_hogar(self.series["Consumo amplio"]).values())
        t7 = math.fsum(total_hogar(s2).values())
        quitado = math.fsum(f[3] for z in ("oficina", "garaje") for f in self.series["Consumo amplio"][z])
        self.assertAlmostEqual(t9 - t7, quitado, places=9)

    def test_m10_total_es_suma_de_zonas(self):
        """M10 Total horario del hogar = suma de zonas; no hay lectura extra."""
        s = self.series["Consumo familiar"]
        tot = total_hogar(s)
        self.assertEqual(len(tot), 720)
        for k in (INI, INI + 100, FIN - 1):
            self.assertAlmostEqual(tot[k], math.fsum(dict((a, d) for a, _, _, d in f)[k] for f in s.values()), places=12)

    def test_m11_reproducibilidad_y_hashseed(self):
        """M11 Misma entrada => resultado idéntico, también con distinto PYTHONHASHSEED (validez 5, CT10)."""
        a = simular_hogar(HOGAR9, self.perfiles["Consumo intermedio"], INI, INI + 48)
        b = simular_hogar(HOGAR9, self.perfiles["Consumo intermedio"], INI, INI + 48)
        self.assertEqual(a, b)
        otro = dict(HOGAR9, id=crear_hogar("otro", "duplex", TODAS)["id"])
        self.assertNotEqual(a, simular_hogar(otro, self.perfiles["Consumo intermedio"], INI, INI + 48))
        guion = ("import sys,json,hashlib; sys.path[:0]=[%r,%r];"
                 "from apoyo import perfil; from test_modelo import HOGAR9,INI;"
                 "from zentheris_sim.simulador import simular_hogar;"
                 "s=simular_hogar(HOGAR9, perfil('Consumo amplio'), INI, INI+72);"
                 "print(hashlib.sha256(json.dumps(s,sort_keys=True).encode()).hexdigest())"
                 % (str(RAIZ / "codigo"), str(RAIZ / "pruebas")))
        hs = set()
        for semilla in ("0", "1", "12345", "random"):
            env = dict(os.environ, PYTHONHASHSEED=semilla)
            hs.add(subprocess.run([sys.executable, "-c", guion], env=env, capture_output=True,
                                  text=True, check=True).stdout.strip())
        self.assertEqual(len(hs), 1, hs)

    def test_m12_semilla_canonica(self):
        """M12 Semilla SHA-256 canónica: dominios y zonas separados; valor de referencia fijo."""
        h, d, v = HOGAR9["id"], date(2026, 9, 1), "zentheris-4.3-ref-1"
        s = {derivar_semilla(h, d, v, z, "ruido") for z in TODAS}
        self.assertEqual(len(s), 9)
        self.assertNotEqual(derivar_semilla(h, d, v, "cocina", "ruido"), derivar_semilla(h, d, v, "cocina", "eventos"))
        self.assertEqual(derivar_semilla(h.upper(), d, v, "sala", "ruido"), derivar_semilla(h, d, v, "sala", "ruido"))
        ref = hashlib.sha256(b'{"dominio":"humor","fecha":"2026-09-01","hogar_id":"00000000-0000-4000-8000-000000000001",'
                             b'"version":"zentheris-4.3-ref-1","zona":null}').hexdigest()
        self.assertEqual(serializacion_canonica("00000000-0000-4000-8000-000000000001", d, v, None, "humor"),
                         json.dumps({"dominio": "humor", "fecha": "2026-09-01",
                                     "hogar_id": "00000000-0000-4000-8000-000000000001",
                                     "version": "zentheris-4.3-ref-1", "zona": None},
                                    separators=(",", ":")).encode())
        self.assertEqual(derivar_semilla("00000000-0000-4000-8000-000000000001", d, v, None, "humor"), int(ref, 16))

    def test_m13_degenerada(self):
        """M13 Σw' <= 0 se detecta y rechaza; con σ/(1−φ)<1 nunca ocurre (A08, CT05)."""
        w = [1.0] + [0.0] * 23
        with self.assertRaises(RealizacionDegenerada):
            calcular_q(w, [-1.0] + [0.0] * 23, 0.0, 1.0)
        rng = random.Random(7)
        for _ in range(3000):
            phi, sig = rng.uniform(0, 0.95), 0.0
            sig = rng.uniform(0, 0.999) * (1 - phi)
            eps = [rng.choice((-1.0, 1.0)) for _ in range(24)]
            q, n = calcular_q(perfil()["curva_horaria"]["base"], eps, phi, sig)
            self.assertTrue(all(abs(x) < 1 for x in n))
            self.assertTrue(all(x > 0 for x in q))

    def test_m14_probabilidad_cero_y_uno(self):
        """M14 p=0 no genera eventos; p=1 genera exactamente uno por hora."""
        p = perfil(); p["picos_config"]["cocina"]["probabilidad"] = 0.0
        self.assertEqual(eventos_dia(HOGAR9["id"], date(2026, 9, 2), "cocina", p), [])
        p["picos_config"]["cocina"]["probabilidad"] = 0.5   # ×2 en 18–21 => p=1 allí
        evs = eventos_dia(HOGAR9["id"], date(2026, 9, 2), "cocina", p)
        horas = [(e.inicio_min % 1440) // 60 for e in evs]
        self.assertTrue({18, 19, 20} <= set(horas))
        p["picos_config"]["cocina"]["probabilidad"] = 1.0; p["picos_config"]["cocina"]["franjas"] = []
        self.assertEqual(len(eventos_dia(HOGAR9["id"], date(2026, 9, 2), "cocina", p)), 24)

    def test_m15_numeros_comunes(self):
        """M15 Cambiar picos no altera humor ni ruido: el componente regular es idéntico."""
        p1 = perfil(); p2 = perfil(); p2["picos_config"]["cocina"]["probabilidad"] = 0.3
        a = simular_zona(HOGAR9["id"], p1, "cocina", INI, INI + 96, INI)
        b = simular_zona(HOGAR9["id"], p2, "cocina", INI, INI + 96, INI)
        self.assertEqual([x[1] for x in a], [x[1] for x in b])
        self.assertNotEqual([x[2] for x in a], [x[2] for x in b])

    def test_m16_incremental_igual_backfill(self):
        """M16 Generar hora a hora da lo mismo que el lote (A09/A11)."""
        p = self.perfiles["Consumo amplio"]
        lote = simular_zona(HOGAR9["id"], p, "lavanderia", INI, INI + 96, INI)
        for k, r, e, L in lote:
            u = simular_zona(HOGAR9["id"], p, "lavanderia", k, k + 1, INI)[0]
            self.assertEqual(u[1], r)
            self.assertAlmostEqual(u[3], L, places=13)

    def test_m17_recuperacion_e_idempotencia(self):
        """M17 Rellena huecos y horas pendientes; no duplica ni reescribe (RN-IV-05, A13, CT11)."""
        p = self.perfiles["Consumo familiar"]
        hogar = crear_hogar("recuperacion", "apartamento", ("cocina", "sala", "dormitorio", "bano", "oficina", "lavanderia"))
        al = AlmacenMemoria()
        ahora = dt(2026, 10, 20, 8, 15)
        fin = idx(2026, 10, 20, 7) + 1
        ini = fin - 720
        self.assertEqual(generar_y_guardar(al, hogar, p, ini, fin, ini), 720 * 6)
        sid = hogar["sensores"]["cocina"]
        rng = random.Random(3)
        huecos = rng.sample(range(ini + 1, fin), 15)
        from zentheris_sim.simulador import hora_desde_indice
        for k in huecos:
            del al.filas[(sid, hora_desde_indice(k))]
        manipulada = (hogar["sensores"]["sala"], hora_desde_indice(ini + 5))
        al.filas[manipulada]["consumo_kwh"] = Decimal("9.9999")
        ahora2 = ahora + timedelta(hours=6)
        n = recuperar(al, hogar, p, ahora2)
        self.assertEqual(n, 15 + 6 * 6)
        self.assertEqual(al.filas[manipulada]["consumo_kwh"], Decimal("9.9999"))
        fin2 = fin + 6
        ref = simular_zona(hogar["id"], p, "cocina", ini, fin2, ini)
        for k, _, _, L in ref:
            from zentheris_sim.simulador import redondear_kwh
            self.assertEqual(al.filas[(sid, hora_desde_indice(k))]["consumo_kwh"], redondear_kwh(L))
        self.assertEqual(recuperar(al, hogar, p, ahora2), 0)
        self.assertEqual(len(al.filas), 6 * (720 + 6))
        self.assertEqual(generar_y_guardar(al, hogar, p, ini, fin2, ini), 0)

    def test_m18_redondeo_y_filas(self):
        """M18 NUMERIC(12,4): error <= 0,00005 por lectura y <= 0,036 por 720; calidad 'simulada';
        fecha_hora en America/Bogota (−05:00), una por hora (CT12, A12)."""
        s = self.series["Consumo amplio"]
        filas = a_filas_lectura({z: f"s-{z}" for z in s}, s)
        self.assertEqual(len(filas), 720 * 9)
        for z, fz in s.items():
            err_tot = 0.0
            for (k, _, _, L), fila in zip(fz, [f for f in filas if f["sensor_id"] == f"s-{z}"]):
                e = abs(float(fila["consumo_kwh"]) - L)
                self.assertLessEqual(e, 0.00005 + 1e-12)
                self.assertEqual(fila["consumo_kwh"].as_tuple().exponent, -4)
                err_tot += e
            self.assertLessEqual(err_tot, 0.036)
        self.assertEqual({f["calidad"] for f in filas}, {"simulada"})
        self.assertEqual({f["fecha_hora"].utcoffset() for f in filas}, {timedelta(hours=-5)})
        self.assertEqual({f["fecha_hora"].tzinfo for f in filas}, {ZONA_HORARIA})
        hs = sorted({f["fecha_hora"] for f in filas})
        self.assertEqual(len(hs), 720)
        self.assertTrue(all(b - a == timedelta(hours=1) for a, b in zip(hs, hs[1:])))

    def test_m19_ultima_hora_completa(self):
        """M19 El backfill termina en la última hora completa (RN-XI-01) y tiene 720 horas."""
        hogar = crear_hogar("ultima", "apartamento", ("cocina", "sala", "dormitorio", "bano"))
        s = backfill(hogar, perfil(), dt(2026, 10, 28, 15, 23))
        ks = [k for k, *_ in s["sala"]]
        self.assertEqual(len(ks), 720)
        self.assertEqual(ks[-1], idx(2026, 10, 28, 14))
        s2 = backfill(hogar, perfil(), dt(2026, 10, 28, 15, 0))
        self.assertEqual(s2["sala"][-1][0], idx(2026, 10, 28, 14))

    def test_m20_eventos_trazables(self):
        """M20 Toda energía adicional proviene de eventos sorteados (validez 4, A16)."""
        p = self.perfiles["Consumo amplio"]
        filas, _, evs = simular_zona(HOGAR9["id"], p, "lavanderia", INI, FIN, INI, detalle=True)
        rec = {}
        for e in evs:
            for k, v in reparto_evento(e).items():
                if INI <= k < FIN:
                    rec[k] = rec.get(k, 0.0) + v
        for k, _, ev, _ in filas:
            self.assertAlmostEqual(ev, rec.get(k, 0.0), places=12)
        sin = perfil("Consumo amplio"); sin["picos_config"] = {}
        self.assertTrue(all(f[2] == 0.0 for f in simular_zona(HOGAR9["id"], sin, "lavanderia", INI, FIN, INI)))


if __name__ == "__main__":
    unittest.main()
