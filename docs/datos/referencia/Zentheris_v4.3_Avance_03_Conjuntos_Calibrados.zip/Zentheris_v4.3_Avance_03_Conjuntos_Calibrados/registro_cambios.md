# Registro de cambios y fallos (Avance 03)

## Discrepancias de insumos
- **I01.** El v4.3 adjuntado difiere de la copia del Avance 01 solo en la línea 1143 (redacción de la decisión 25 de la sección 9). No afecta fórmula, tablas, catálogos ni RN-X-04. Se usa el adjuntado como fuente (`insumos/`).
- **I02.** Entorno: Python 3.12.3 (los avances previos declararon 3.14.8). Los scripts de ambos avances se reejecutaron aquí y reprodujeron sus archivos byte a byte.

## Fallos detectados y corregidos
- **F01 (implementación).** `test_m05` falló: el reparto de energía de eventos tenía un error de 1,09 × 10⁻⁹ kWh (tolerancia 10⁻¹⁰). Causa: minutos absolutos (~10⁹) sumados a una duración fraccionaria pierden precisión. Corrección: calcular solapamientos relativos a la hora de inicio. No se cambió la tolerancia. Suite reejecutada: aprobada.
- **F02 (cobertura de pruebas).** La mutación «incluir eventos anteriores a la frontera» no fue detectada por la suite: las pruebas solo usaban fronteras a medianoche. Se añadió `test_m21` (frontera a las 15 h). La mutación queda detectada (8/8).
- **F03 (construcción).** La primera construcción de A1 no reproducía la razón congelada (4,7334 frente a 4,7413 kWh/día laborales): faltaba recalcular la luz de lavandería con el mismo método del Avance 02. Se corrigió antes de producir archivos; ningún candidato quedó generado con el error.

## Calibración
- Los conjuntos derivados del balance pasaron todas las etapas con el grupo de calibración sin ajustes numéricos. Por eso el grupo de validación (`val-000..val-099`) sigue siendo ciego: no se modificó nada después de verlo.
- No hay candidatos descartados (`candidatos_descartados/` queda vacío a propósito).

## Revisión final (etapa G)
- **F04 (prueba incorrecta).** La primera revisión marcó «datos sensibles» falsos: el patrón de teléfono coincidía con dígitos de las curvas (p. ej. «0,3256971810»), y el detector de credenciales encontraba sus propios patrones en `validacion.py` y `test_estructura.py`. Se corrigió el patrón (no puede ir precedido de punto o dígito) y se excluyen solo esos archivos. Resultado: sin hallazgos.
- Cadena completa reejecutada con `codigo/ejecutar_todo.py`: suite 59/59, calibración sin ajustes, 47/47 criterios, 8/8 mutaciones, JSON reconstruidos idénticos byte a byte, informe coherente con los CSV.

## Prueba en PostgreSQL local (ejecutada por el equipo)
- Fecha: 2026-10-29. Entorno: Windows, PostgreSQL 16 local, Python 3.14.3, psycopg 3.3.6.
- Resultado: 16 de 16 comprobaciones aprobadas (`resultados/prueba_postgres_local.csv`). Cubre carga no destructiva (conserva id), ida y vuelta de los cinco perfiles, 720 lecturas por zona y valores iguales antes y después de guardar.
- Alcance: PostgreSQL local. No cubre Supabase, el módulo real del backend ni `sql/02_verificacion.sql`.
- Hallazgo I03: `requirements.txt` fija `psycopg[binary]==3.2.3`, que no tiene paquete para Python 3.14. Debe cambiarse a `psycopg[binary]==3.3.6`.
- Limpieza: contraseña temporal eliminada del equipo; base y usuario de prueba eliminados.
