-- Zentheris v4.3 · DDL DE PRUEBA AISLADO (no es el esquema real ni una migración).
-- Solo las tablas que necesita la prueba punta a punta del simulador, con los tipos y
-- restricciones de las tablas 8–12 del diccionario v4.3. Se crea en un esquema propio
-- para no tocar nada existente. Uso exclusivo en PostgreSQL local de pruebas.
-- Estado: NO EJECUTADO en esta entrega (el entorno no tenía PostgreSQL).

CREATE SCHEMA IF NOT EXISTS zentheris_prueba;
SET search_path TO zentheris_prueba;

CREATE TABLE IF NOT EXISTS perfiles_simulacion (
    id                            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nombre                        TEXT NOT NULL UNIQUE,
    activo                        BOOLEAN NOT NULL DEFAULT true,
    base_cocina_kwh_dia           NUMERIC(10,4) NOT NULL CHECK (base_cocina_kwh_dia >= 0),
    base_sala_kwh_dia             NUMERIC(10,4) NOT NULL CHECK (base_sala_kwh_dia >= 0),
    base_dormitorio_kwh_dia       NUMERIC(10,4) NOT NULL CHECK (base_dormitorio_kwh_dia >= 0),
    base_bano_kwh_dia             NUMERIC(10,4) NOT NULL CHECK (base_bano_kwh_dia >= 0),
    base_lavanderia_kwh_dia       NUMERIC(10,4) NOT NULL CHECK (base_lavanderia_kwh_dia >= 0),
    base_oficina_kwh_dia          NUMERIC(10,4) NOT NULL CHECK (base_oficina_kwh_dia >= 0),
    base_terraza_kwh_dia          NUMERIC(10,4) NOT NULL CHECK (base_terraza_kwh_dia >= 0),
    base_garaje_kwh_dia           NUMERIC(10,4) NOT NULL CHECK (base_garaje_kwh_dia >= 0),
    base_cuarto_servicio_kwh_dia  NUMERIC(10,4) NOT NULL CHECK (base_cuarto_servicio_kwh_dia >= 0),
    curva_horaria                 JSONB NOT NULL,
    humor_min                     NUMERIC(6,4) NOT NULL,
    humor_max                     NUMERIC(6,4) NOT NULL,
    ruido_config                  JSONB NOT NULL,
    picos_config                  JSONB NOT NULL,
    factor_fin_semana             NUMERIC(6,4) NOT NULL CHECK (factor_fin_semana > 0),
    created_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Mínimo de hogares para la prueba (el real tiene más campos: tabla 4 del diccionario).
CREATE TABLE IF NOT EXISTS hogares (
    id                     UUID PRIMARY KEY,
    nombre                 TEXT NOT NULL,
    tipo_vivienda          TEXT NOT NULL CHECK (tipo_vivienda IN ('apartamento','casa','apartaestudio','duplex','casa_campestre')),
    perfil_simulacion_id   UUID NOT NULL REFERENCES perfiles_simulacion(id)
);

CREATE TABLE IF NOT EXISTS zonas (
    id        UUID PRIMARY KEY,
    hogar_id  UUID NOT NULL REFERENCES hogares(id),
    nombre    TEXT NOT NULL,
    tipo      TEXT NOT NULL CHECK (tipo IN ('cocina','sala','dormitorio','bano','lavanderia','oficina','terraza','garaje','cuarto_servicio')),
    estado    TEXT NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa','inactiva')),
    UNIQUE (hogar_id, nombre)
);

CREATE TABLE IF NOT EXISTS fuentes_principales (
    id        UUID PRIMARY KEY,
    hogar_id  UUID NOT NULL UNIQUE REFERENCES hogares(id),
    nombre    TEXT NOT NULL,
    estado    TEXT NOT NULL DEFAULT 'activa' CHECK (estado IN ('activa','inactiva'))
);

CREATE TABLE IF NOT EXISTS sensores_zona (
    id                   UUID PRIMARY KEY,
    zona_id              UUID NOT NULL UNIQUE REFERENCES zonas(id),
    fuente_principal_id  UUID NOT NULL REFERENCES fuentes_principales(id),
    estado               TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','pausado'))
);

CREATE TABLE IF NOT EXISTS lecturas (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sensor_id    UUID NOT NULL REFERENCES sensores_zona(id),
    fecha_hora   TIMESTAMPTZ NOT NULL,
    consumo_kwh  NUMERIC(12,4) NOT NULL CHECK (consumo_kwh >= 0),
    calidad      TEXT NOT NULL CHECK (calidad IN ('simulada','estimada','real')),
    UNIQUE (sensor_id, fecha_hora)
);
