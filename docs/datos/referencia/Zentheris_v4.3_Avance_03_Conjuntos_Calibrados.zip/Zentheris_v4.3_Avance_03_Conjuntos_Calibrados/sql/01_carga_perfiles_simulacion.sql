-- Zentheris v4.3 · carga NO destructiva de perfiles_simulacion (generado).
-- Versión del modelo de referencia: zentheris-4.3-ref-1
-- Fuente: parametros_finales/*.json; SHA-256:
--   consumo_compacto.json 5b753d74c569ded1be73592bb00089b263ba53029dd9ee4c9baf1c71675ebc12
--   consumo_eficiente.json 1b3ee380a4cbf52621830f6f1f27be4b31787e8666babe9735b56dacf8405dcc
--   consumo_intermedio.json 5bd93608a2c6017097388c2c4b3e51373cf732c8d522cf43dbf5b95d1c3bd1e8
--   consumo_familiar.json 2ac80e2772fc62dc55a0e143010d781cbd594c8f6ef8e04a31f839e2f699f452
--   consumo_amplio.json 328e44959c38ccc2f9ac9a342b1c1c6734ef0291866d4bb2c878e4bd47cc2ae6
-- Requiere la restricción UNIQUE(nombre) de la tabla 12. No borra filas ni cambia id/created_at.
-- Ajuste search_path al esquema destino antes de ejecutar (p. ej. zentheris_prueba).
-- Estado: NO EJECUTADO en esta entrega.
BEGIN;
INSERT INTO perfiles_simulacion (nombre, activo, base_cocina_kwh_dia, base_sala_kwh_dia, base_dormitorio_kwh_dia, base_bano_kwh_dia, base_oficina_kwh_dia, base_lavanderia_kwh_dia, base_terraza_kwh_dia, base_garaje_kwh_dia, base_cuarto_servicio_kwh_dia, curva_horaria, humor_min, humor_max, ruido_config, picos_config, factor_fin_semana)
VALUES (
    'Consumo compacto',
    true,
    0.7678,
    0.316,
    0.0589,
    0.0047,
    0.0933,
    0.0786,
    0.0,
    0.0,
    0.0,
    $zj${"base":[0.0325697181,0.0325697181,0.0325697181,0.0325697181,0.0325697181,0.0352599568,0.037516431,0.0333059939,0.0340971084,0.0333608326,0.0325697181,0.0325697181,0.0359517324,0.0359517324,0.0325697181,0.0338283093,0.0338283093,0.0338283093,0.0354015483,0.0991918943,0.0836760123,0.0901367804,0.0515375864,0.0325697181],"cocina":[0.0375207482,0.0375207482,0.0375207482,0.0375207482,0.0375207482,0.0390019232,0.0449131884,0.0381132182,0.0392954712,0.0387030012,0.0375207482,0.0375207482,0.0425748799,0.0425748799,0.0375207482,0.0375207482,0.0375207482,0.0375207482,0.0375207482,0.1144914668,0.0375207482,0.0375207482,0.0375207482,0.0375207482],"sala":[0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0270985679,0.0373819317,0.0819921433,0.1641611179,0.1641611169,0.0374309001,0.0270985679],"dormitorio":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0245098039,0.0245098039,0.0245098039,0.0,0.0,0.2573529412,0.3860294118,0.2830882353,0.0],"bano":[0.0,0.0,0.0,0.0,0.0,0.4132653062,0.0,0.0826530612,0.0826530612,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0357142857,0.0,0.3857142857,0.0],"oficina":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0299277606,0.0299277606,0.0299277606,0.0,0.0,0.0,0.0,0.0,0.3034055726,0.3034055728,0.3034055728,0.0,0.0,0.0],"lavanderia":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.1398985838,0.4431626106,0.1398985838,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.1385201109,0.1385201109,0.0,0.0,0.0]}$zj$::jsonb,
    0.9,
    1.1,
    $zj${"memoria":0.6,"intensidad":0.1}$zj$::jsonb,
    $zj${"sala":{"probabilidad":0.025,"franjas":[{"desde":0,"hasta":21,"multiplicador":0.0},{"desde":23,"hasta":24,"multiplicador":0.0}],"potencia_w":[35.0,55.0],"duracion_min":[60.0,60.0],"minuto_inicio":[0,59],"fraccion_uso":[0.988888888888889,0.988888888888889]}}$zj$::jsonb,
    0.9621
)
ON CONFLICT (nombre) DO UPDATE SET
    activo = EXCLUDED.activo,
    base_cocina_kwh_dia = EXCLUDED.base_cocina_kwh_dia,
    base_sala_kwh_dia = EXCLUDED.base_sala_kwh_dia,
    base_dormitorio_kwh_dia = EXCLUDED.base_dormitorio_kwh_dia,
    base_bano_kwh_dia = EXCLUDED.base_bano_kwh_dia,
    base_oficina_kwh_dia = EXCLUDED.base_oficina_kwh_dia,
    base_lavanderia_kwh_dia = EXCLUDED.base_lavanderia_kwh_dia,
    base_terraza_kwh_dia = EXCLUDED.base_terraza_kwh_dia,
    base_garaje_kwh_dia = EXCLUDED.base_garaje_kwh_dia,
    base_cuarto_servicio_kwh_dia = EXCLUDED.base_cuarto_servicio_kwh_dia,
    curva_horaria = EXCLUDED.curva_horaria,
    humor_min = EXCLUDED.humor_min,
    humor_max = EXCLUDED.humor_max,
    ruido_config = EXCLUDED.ruido_config,
    picos_config = EXCLUDED.picos_config,
    factor_fin_semana = EXCLUDED.factor_fin_semana,
    updated_at = now();
INSERT INTO perfiles_simulacion (nombre, activo, base_cocina_kwh_dia, base_sala_kwh_dia, base_dormitorio_kwh_dia, base_bano_kwh_dia, base_oficina_kwh_dia, base_lavanderia_kwh_dia, base_terraza_kwh_dia, base_garaje_kwh_dia, base_cuarto_servicio_kwh_dia, curva_horaria, humor_min, humor_max, ruido_config, picos_config, factor_fin_semana)
VALUES (
    'Consumo eficiente',
    true,
    1.3087,
    0.3903,
    0.0882,
    0.0579,
    0.0892,
    0.0751,
    0.1391,
    0.0865,
    0.1522,
    $zj${"base":[0.0245857848,0.0245857848,0.0245857848,0.0245857848,0.0245857848,0.04185571,0.0632945326,0.0266054924,0.0361206308,0.0416290539,0.0399384126,0.0399384126,0.0421487635,0.0296814324,0.0245857848,0.0292735013,0.0292735013,0.029004207,0.0345833376,0.1131740448,0.1104811012,0.0828019876,0.0380953848,0.0245857848],"cocina":[0.0284188575,0.0284188575,0.0284188575,0.0284188575,0.0284188575,0.0363589049,0.0665853243,0.0295578852,0.0372604844,0.0461657925,0.0500644009,0.0500644009,0.0531807565,0.0356031691,0.0284188575,0.0284188575,0.0284188575,0.0284188575,0.0284188575,0.1392232481,0.0864904857,0.0284188575,0.0284188575,0.0284188575],"sala":[0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0209364686,0.0336663131,0.0336663131,0.0323933286,0.068196016,0.068196016,0.2039810239,0.2039810231,0.0209364686,0.0209364686],"dormitorio":[0.0,0.0,0.0,0.0,0.0,0.0422535211,0.0422535211,0.0169014085,0.0169014085,0.0,0.0,0.0,0.0,0.0,0.0,0.0417318727,0.0417318727,0.0417318727,0.0,0.0,0.1251956182,0.3782472613,0.2530516432,0.0],"bano":[0.0,0.0,0.0,0.0,0.0,0.3065156933,0.3065156933,0.0128724672,0.1419944378,0.1419944378,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0450536353,0.0450536353,0.0],"oficina":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0299277606,0.0299277606,0.0299277606,0.0,0.0,0.0,0.0,0.0,0.3034055726,0.3034055728,0.3034055728,0.0,0.0,0.0],"lavanderia":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.1398985838,0.4431626106,0.1398985838,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.1385201109,0.1385201109,0.0,0.0,0.0],"terraza":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.25,0.25,0.25,0.25,0.0,0.0],"garaje":[0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0806329417,0.0567082248,0.0334480834,0.0334480834,0.0523220267,0.0427521399,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0827595825,0.0827595832,0.0334480834,0.0334480834,0.0334480834,0.0334480834],"cuarto_servicio":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.4170444243,0.4456029012,0.0,0.0,0.0,0.0543970988,0.0543970988,0.0,0.0,0.0,0.0285584769,0.0,0.0,0.0,0.0]}$zj$::jsonb,
    0.9,
    1.1,
    $zj${"memoria":0.6,"intensidad":0.06}$zj$::jsonb,
    $zj${"cocina":{"probabilidad":0.03333333333333333,"franjas":[{"desde":0,"hasta":19,"multiplicador":0.0},{"desde":21,"hasta":24,"multiplicador":0.0}],"potencia_w":[1366.0,1500.0],"duracion_min":[5.0,5.0],"minuto_inicio":[0,59],"fraccion_uso":[0.9993021632937892,0.9993021632937892]}}$zj$::jsonb,
    1.1227
)
ON CONFLICT (nombre) DO UPDATE SET
    activo = EXCLUDED.activo,
    base_cocina_kwh_dia = EXCLUDED.base_cocina_kwh_dia,
    base_sala_kwh_dia = EXCLUDED.base_sala_kwh_dia,
    base_dormitorio_kwh_dia = EXCLUDED.base_dormitorio_kwh_dia,
    base_bano_kwh_dia = EXCLUDED.base_bano_kwh_dia,
    base_oficina_kwh_dia = EXCLUDED.base_oficina_kwh_dia,
    base_lavanderia_kwh_dia = EXCLUDED.base_lavanderia_kwh_dia,
    base_terraza_kwh_dia = EXCLUDED.base_terraza_kwh_dia,
    base_garaje_kwh_dia = EXCLUDED.base_garaje_kwh_dia,
    base_cuarto_servicio_kwh_dia = EXCLUDED.base_cuarto_servicio_kwh_dia,
    curva_horaria = EXCLUDED.curva_horaria,
    humor_min = EXCLUDED.humor_min,
    humor_max = EXCLUDED.humor_max,
    ruido_config = EXCLUDED.ruido_config,
    picos_config = EXCLUDED.picos_config,
    factor_fin_semana = EXCLUDED.factor_fin_semana,
    updated_at = now();
INSERT INTO perfiles_simulacion (nombre, activo, base_cocina_kwh_dia, base_sala_kwh_dia, base_dormitorio_kwh_dia, base_bano_kwh_dia, base_oficina_kwh_dia, base_lavanderia_kwh_dia, base_terraza_kwh_dia, base_garaje_kwh_dia, base_cuarto_servicio_kwh_dia, curva_horaria, humor_min, humor_max, ruido_config, picos_config, factor_fin_semana)
VALUES (
    'Consumo intermedio',
    true,
    1.4593,
    0.5493,
    0.1104,
    0.0768,
    0.2931,
    0.1258,
    0.1439,
    0.0895,
    0.0,
    $zj${"base":[0.01974238,0.01974238,0.01974238,0.01974238,0.01974238,0.01974238,0.0579079472,0.0326034569,0.0458781834,0.0481196949,0.056093534,0.0401324753,0.0681311486,0.0354824687,0.0313736908,0.0354940743,0.0634790394,0.0439627744,0.0646725552,0.0739774837,0.0745434798,0.0543730984,0.0295569974,0.0257636176],"cocina":[0.0263536869,0.0263536869,0.0263536869,0.0263536869,0.0263536869,0.0263536869,0.0599130196,0.0438730033,0.0387211262,0.0437324669,0.0625648152,0.0356684466,0.1088831559,0.0333614135,0.0263536869,0.0263536869,0.0356684466,0.0356684466,0.0817851232,0.0724703635,0.057799617,0.0263536869,0.0263536869,0.0263536869],"sala":[0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.017152914,0.0288462371,0.0288462371,0.017152914,0.017152914,0.017152914,0.035823872,0.1308701723,0.0918924282,0.0539868818,0.1241468205,0.1241468205,0.1241468205,0.017152914,0.017152914],"dormitorio":[0.0,0.0,0.0,0.0,0.0,0.0,0.078539108,0.0157078216,0.0157078216,0.0,0.0161603103,0.0161603103,0.0,0.0,0.0,0.0,0.0,0.0161603103,0.0969618617,0.0808015514,0.085520362,0.2212669682,0.2212669683,0.1357466063],"bano":[0.0,0.0,0.0,0.0,0.0,0.0,0.4860681116,0.0111455108,0.2123839009,0.2123839009,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0390092879,0.0390092879,0.0,0.0],"oficina":[0.0042905036,0.0042905036,0.0042905036,0.0042905036,0.0042905036,0.0042905036,0.0042905036,0.0174377413,0.1030554749,0.1030554749,0.1046785906,0.1030554749,0.0042905036,0.1030554749,0.1030554749,0.1030554749,0.1162027128,0.0174377413,0.0042905036,0.0042905036,0.0701338178,0.0042905036,0.0042905036,0.0042905036],"lavanderia":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0865435249,0.0865435249,0.3984485764,0.0865435249,0.0,0.0,0.1139736163,0.1139736163,0.1139736163,0.0,0.0,0.0,0.0,0.0,0.0,0.0],"terraza":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.25,0.25,0.25,0.25,0.0,0.0],"garaje":[0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0806329417,0.0567082248,0.0334480834,0.0334480834,0.0523220267,0.0427521399,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0827595825,0.0827595832,0.0334480834,0.0334480834,0.0334480834,0.0334480834]}$zj$::jsonb,
    0.88,
    1.12,
    $zj${"memoria":0.6,"intensidad":0.1}$zj$::jsonb,
    $zj${"cocina":{"probabilidad":0.03333333333333333,"franjas":[{"desde":0,"hasta":19,"multiplicador":0.0},{"desde":21,"hasta":24,"multiplicador":0.0}],"potencia_w":[1366.0,1500.0],"duracion_min":[5.0,5.0],"minuto_inicio":[0,59],"fraccion_uso":[0.9993021632937892,0.9993021632937892]},"oficina":{"probabilidad":0.016666666666666666,"franjas":[{"desde":0,"hasta":17,"multiplicador":0.0},{"desde":19,"hasta":24,"multiplicador":0.0}],"potencia_w":[25.0,55.0],"duracion_min":[120.0,120.0],"minuto_inicio":[0,59],"fraccion_uso":[1.0,1.0]}}$zj$::jsonb,
    1.0032
)
ON CONFLICT (nombre) DO UPDATE SET
    activo = EXCLUDED.activo,
    base_cocina_kwh_dia = EXCLUDED.base_cocina_kwh_dia,
    base_sala_kwh_dia = EXCLUDED.base_sala_kwh_dia,
    base_dormitorio_kwh_dia = EXCLUDED.base_dormitorio_kwh_dia,
    base_bano_kwh_dia = EXCLUDED.base_bano_kwh_dia,
    base_oficina_kwh_dia = EXCLUDED.base_oficina_kwh_dia,
    base_lavanderia_kwh_dia = EXCLUDED.base_lavanderia_kwh_dia,
    base_terraza_kwh_dia = EXCLUDED.base_terraza_kwh_dia,
    base_garaje_kwh_dia = EXCLUDED.base_garaje_kwh_dia,
    base_cuarto_servicio_kwh_dia = EXCLUDED.base_cuarto_servicio_kwh_dia,
    curva_horaria = EXCLUDED.curva_horaria,
    humor_min = EXCLUDED.humor_min,
    humor_max = EXCLUDED.humor_max,
    ruido_config = EXCLUDED.ruido_config,
    picos_config = EXCLUDED.picos_config,
    factor_fin_semana = EXCLUDED.factor_fin_semana,
    updated_at = now();
INSERT INTO perfiles_simulacion (nombre, activo, base_cocina_kwh_dia, base_sala_kwh_dia, base_dormitorio_kwh_dia, base_bano_kwh_dia, base_oficina_kwh_dia, base_lavanderia_kwh_dia, base_terraza_kwh_dia, base_garaje_kwh_dia, base_cuarto_servicio_kwh_dia, curva_horaria, humor_min, humor_max, ruido_config, picos_config, factor_fin_semana)
VALUES (
    'Consumo familiar',
    true,
    1.8169,
    0.8088,
    0.143,
    0.1245,
    0.5083,
    0.1906,
    0.1423,
    0.0885,
    0.1557,
    $zj${"base":[0.014914721,0.014914721,0.014914721,0.014914721,0.014914721,0.0421952664,0.0394101505,0.0158961428,0.0502013341,0.049644311,0.0438995388,0.043703058,0.0706288268,0.0346256785,0.0281987903,0.0390159024,0.073368331,0.051860837,0.0767049498,0.097138957,0.0637153211,0.0598685538,0.0249342613,0.0204161844],"cocina":[0.023424046,0.023424046,0.023424046,0.023424046,0.023424046,0.0552393145,0.0552393145,0.023424046,0.0356257526,0.0356257526,0.023424046,0.023424046,0.1335715263,0.0361300838,0.023424046,0.023424046,0.023424046,0.023424046,0.1191906424,0.1191906424,0.0588262809,0.023424046,0.023424046,0.023424046],"sala":[0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0114862035,0.0219579559,0.0219579559,0.0114862035,0.0114862035,0.0114862035,0.0595291077,0.1684689918,0.1056384777,0.0444722237,0.1352274116,0.1352274116,0.1352274116,0.0114862035,0.0114862035],"dormitorio":[0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0733563729,0.0033736526,0.0173701967,0.0173701967,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0033736526,0.0795770592,0.3955484241,0.2178145314,0.1416111248],"bano":[0.0,0.0,0.0,0.0,0.0,0.24234983,0.24234983,0.012240272,0.208689082,0.208689082,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.042840952,0.042840952,0.0],"oficina":[0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.1213233507,0.1213233507,0.0977172559,0.0963286621,0.0024458344,0.0963286621,0.0963286621,0.0963286621,0.1657583532,0.0718755251,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344,0.0024458344],"lavanderia":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0848265055,0.0848265055,0.2477420591,0.2477420592,0.0,0.0,0.0,0.0,0.0,0.1116209569,0.1116209569,0.1116209569,0.0,0.0,0.0,0.0],"terraza":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.25,0.25,0.25,0.25,0.0,0.0],"garaje":[0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0806329417,0.0567082248,0.0334480834,0.0334480834,0.0523220267,0.0427521399,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0827595825,0.0827595832,0.0334480834,0.0334480834,0.0334480834,0.0334480834],"cuarto_servicio":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.4170444243,0.4456029012,0.0,0.0,0.0,0.0543970988,0.0543970988,0.0,0.0,0.0,0.0285584769,0.0,0.0,0.0,0.0]}$zj$::jsonb,
    0.88,
    1.12,
    $zj${"memoria":0.6,"intensidad":0.12}$zj$::jsonb,
    $zj${"cocina":{"probabilidad":0.03333333333333333,"franjas":[{"desde":0,"hasta":18,"multiplicador":0.0},{"desde":20,"hasta":24,"multiplicador":0.0}],"potencia_w":[1500.0,1500.0],"duracion_min":[20.0,20.0],"minuto_inicio":[0,59],"fraccion_uso":[0.5,0.8999999999999999]}}$zj$::jsonb,
    1.0423
)
ON CONFLICT (nombre) DO UPDATE SET
    activo = EXCLUDED.activo,
    base_cocina_kwh_dia = EXCLUDED.base_cocina_kwh_dia,
    base_sala_kwh_dia = EXCLUDED.base_sala_kwh_dia,
    base_dormitorio_kwh_dia = EXCLUDED.base_dormitorio_kwh_dia,
    base_bano_kwh_dia = EXCLUDED.base_bano_kwh_dia,
    base_oficina_kwh_dia = EXCLUDED.base_oficina_kwh_dia,
    base_lavanderia_kwh_dia = EXCLUDED.base_lavanderia_kwh_dia,
    base_terraza_kwh_dia = EXCLUDED.base_terraza_kwh_dia,
    base_garaje_kwh_dia = EXCLUDED.base_garaje_kwh_dia,
    base_cuarto_servicio_kwh_dia = EXCLUDED.base_cuarto_servicio_kwh_dia,
    curva_horaria = EXCLUDED.curva_horaria,
    humor_min = EXCLUDED.humor_min,
    humor_max = EXCLUDED.humor_max,
    ruido_config = EXCLUDED.ruido_config,
    picos_config = EXCLUDED.picos_config,
    factor_fin_semana = EXCLUDED.factor_fin_semana,
    updated_at = now();
INSERT INTO perfiles_simulacion (nombre, activo, base_cocina_kwh_dia, base_sala_kwh_dia, base_dormitorio_kwh_dia, base_bano_kwh_dia, base_oficina_kwh_dia, base_lavanderia_kwh_dia, base_terraza_kwh_dia, base_garaje_kwh_dia, base_cuarto_servicio_kwh_dia, curva_horaria, humor_min, humor_max, ruido_config, picos_config, factor_fin_semana)
VALUES (
    'Consumo amplio',
    true,
    1.862,
    0.9866,
    0.3542,
    0.1829,
    0.6009,
    1.1315,
    0.1381,
    0.0859,
    1.0269,
    $zj${"base":[0.0113245699,0.0113245699,0.0113245699,0.0113245699,0.0113245699,0.0123646874,0.0400704555,0.0333193226,0.0235134466,0.0311112571,0.0705321566,0.0835666446,0.0967484486,0.0701279416,0.024847129,0.0203879005,0.0328767396,0.0328767396,0.0751422778,0.0907440399,0.0612316696,0.0618995599,0.056514785,0.025501949],"cocina":[0.0221815724,0.0221815724,0.0221815724,0.0221815724,0.0221815724,0.0221815724,0.0586974447,0.0479074451,0.0346299214,0.0346299214,0.0221815724,0.0221815724,0.0951667239,0.0516603418,0.0221815724,0.0221815724,0.0221815724,0.0221815724,0.1447486114,0.1447486114,0.0550873929,0.0221815724,0.0221815724,0.0221815724],"sala":[0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0091061403,0.0479836899,0.0479836899,0.0202140117,0.0091061403,0.0091061403,0.0489595958,0.1089778048,0.1089778048,0.0451893661,0.1201674979,0.1201674974,0.1201674974,0.0928317204,0.0091061403],"dormitorio":[0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0430039959,0.009593323,0.009593323,0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0012406548,0.0115525909,0.0115525909,0.0115525909,0.0012406548,0.0012406548,0.0894850477,0.2518980407,0.3534061615,0.1909931683],"bano":[0.0,0.0,0.0,0.0,0.0,0.0269595607,0.2703444833,0.2811283076,0.1730404393,0.1730404393,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0377433849,0.0377433849,0.0],"oficina":[0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.131055008,0.1310550084,0.1120583077,0.1105385717,0.0020066215,0.1105385717,0.1105385717,0.1105385717,0.1310550084,0.0225230582,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215,0.0020066215],"lavanderia":[8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,0.0345339268,0.2128407128,0.2681832648,0.2282328602,0.1979674018,0.0567444496,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05,8.3188e-05],"terraza":[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.25,0.25,0.25,0.25,0.0,0.0],"garaje":[0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0806329417,0.0567082248,0.0334480834,0.0334480834,0.0523220267,0.0427521399,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0334480834,0.0827595825,0.0827595832,0.0334480834,0.0334480834,0.0334480834,0.0334480834],"cuarto_servicio":[0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0728133754,0.1484058869,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0350171195,0.0434212282,0.0350171195,0.0350171195,0.0350171195,0.0350171195]}$zj$::jsonb,
    0.85,
    1.15,
    $zj${"memoria":0.6,"intensidad":0.15}$zj$::jsonb,
    $zj${"cocina":{"probabilidad":0.03333333333333333,"franjas":[{"desde":0,"hasta":12,"multiplicador":0.0},{"desde":14,"hasta":24,"multiplicador":0.0}],"potencia_w":[1500.0,1500.0],"duracion_min":[30.0,30.0],"minuto_inicio":[0,59],"fraccion_uso":[0.5000000000000001,0.9000000000000001]},"lavanderia":{"probabilidad":0.005555555555555556,"franjas":[{"desde":0,"hasta":10,"multiplicador":0.0},{"desde":16,"hasta":24,"multiplicador":0.0}],"potencia_w":[2075.675675675676,2075.675675675676],"duracion_min":[70.0,115.0],"minuto_inicio":[0,59],"fraccion_uso":[0.9999518229166665,0.9999518229166665]},"terraza":{"probabilidad":0.06666666666666667,"franjas":[{"desde":0,"hasta":22,"multiplicador":0.0},{"desde":23,"hasta":24,"multiplicador":0.0}],"potencia_w":[28.0,44.0],"duracion_min":[60.0,60.0],"minuto_inicio":[0,59],"fraccion_uso":[1.0,1.0]}}$zj$::jsonb,
    1.15
)
ON CONFLICT (nombre) DO UPDATE SET
    activo = EXCLUDED.activo,
    base_cocina_kwh_dia = EXCLUDED.base_cocina_kwh_dia,
    base_sala_kwh_dia = EXCLUDED.base_sala_kwh_dia,
    base_dormitorio_kwh_dia = EXCLUDED.base_dormitorio_kwh_dia,
    base_bano_kwh_dia = EXCLUDED.base_bano_kwh_dia,
    base_oficina_kwh_dia = EXCLUDED.base_oficina_kwh_dia,
    base_lavanderia_kwh_dia = EXCLUDED.base_lavanderia_kwh_dia,
    base_terraza_kwh_dia = EXCLUDED.base_terraza_kwh_dia,
    base_garaje_kwh_dia = EXCLUDED.base_garaje_kwh_dia,
    base_cuarto_servicio_kwh_dia = EXCLUDED.base_cuarto_servicio_kwh_dia,
    curva_horaria = EXCLUDED.curva_horaria,
    humor_min = EXCLUDED.humor_min,
    humor_max = EXCLUDED.humor_max,
    ruido_config = EXCLUDED.ruido_config,
    picos_config = EXCLUDED.picos_config,
    factor_fin_semana = EXCLUDED.factor_fin_semana,
    updated_at = now();
COMMIT;
