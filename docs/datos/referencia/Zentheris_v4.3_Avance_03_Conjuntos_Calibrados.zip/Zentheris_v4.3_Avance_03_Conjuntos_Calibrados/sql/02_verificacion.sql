-- Zentheris v4.3 · consultas de verificación tras cargar perfiles y lecturas de prueba.
-- Estado: NO EJECUTADO en esta entrega. Ajuste search_path al esquema de prueba.

-- 1. Exactamente cinco perfiles con los nombres del contrato
SELECT count(*) AS perfiles,
       bool_and(nombre IN ('Consumo compacto','Consumo eficiente','Consumo intermedio','Consumo familiar','Consumo amplio')) AS nombres_ok
FROM perfiles_simulacion;

-- 2. Curvas: 24 valores y suma 1 (tolerancia 1e-10) por cada clave
SELECT p.nombre, c.key AS curva, jsonb_array_length(c.value) AS n,
       (SELECT sum(x::numeric) FROM jsonb_array_elements_text(c.value) x) AS suma
FROM perfiles_simulacion p, jsonb_each(p.curva_horaria) c
WHERE jsonb_array_length(c.value) <> 24
   OR abs((SELECT sum(x::numeric) FROM jsonb_array_elements_text(c.value) x) - 1) > 1e-10;   -- debe devolver 0 filas

-- 3. Ruido común con solo memoria e intensidad y margen σ/(1-φ) < 1
SELECT nombre FROM perfiles_simulacion
WHERE (SELECT array_agg(k ORDER BY k) FROM jsonb_object_keys(ruido_config) k) <> ARRAY['intensidad','memoria']
   OR (ruido_config->>'intensidad')::numeric / (1 - (ruido_config->>'memoria')::numeric) >= 1;   -- 0 filas

-- 4. Backfill: 720 lecturas por sensor, simuladas, sin duplicados
SELECT s.id AS sensor_id, count(l.*) AS lecturas, bool_and(l.calidad = 'simulada') AS simuladas
FROM sensores_zona s LEFT JOIN lecturas l ON l.sensor_id = s.id
GROUP BY s.id HAVING count(l.*) <> 720 OR NOT bool_and(l.calidad = 'simulada');   -- 0 filas

SELECT sensor_id, fecha_hora, count(*) FROM lecturas GROUP BY 1, 2 HAVING count(*) > 1;   -- 0 filas

-- 5. Horas contiguas en hora de Bogotá, alineadas al inicio de hora
SELECT sensor_id, min(fecha_hora AT TIME ZONE 'America/Bogota') AS primera,
       max(fecha_hora AT TIME ZONE 'America/Bogota') AS ultima,
       bool_and(date_trunc('hour', fecha_hora AT TIME ZONE 'America/Bogota') = fecha_hora AT TIME ZONE 'America/Bogota') AS alineadas
FROM lecturas GROUP BY sensor_id;

-- 6. Relaciones hogar → zona → sensor → fuente coherentes
SELECT z.hogar_id, z.tipo FROM zonas z
JOIN sensores_zona s ON s.zona_id = z.id
JOIN fuentes_principales f ON f.id = s.fuente_principal_id
WHERE f.hogar_id <> z.hogar_id;   -- 0 filas
